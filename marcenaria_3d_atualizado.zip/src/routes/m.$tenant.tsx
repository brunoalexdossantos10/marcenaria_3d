import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getTenant, client } from "@/lib/saas/api";
import { TenantContext } from "@/lib/saas/context";
import { ConfiguradorPage } from "@/components/configurator/ConfiguratorPage";
import { useEffect, useState } from "react";
import type { FurnitureConfig } from "@/lib/furniture/types";
import { fetchGuestProject, getGuestProjectRef } from "@/lib/saas/guestProjects";
interface LoadedProject {
  config: FurnitureConfig;
  id: string;
  code: string;
  created_at: string;
  project_name: string | null;
  preview_image?: string | null | undefined;
}
export const Route = createFileRoute("/m/$tenant")({
  validateSearch: (search: Record<string, unknown>) => ({
    ...(typeof search["project"] === "string" ? { project: search["project"] } : {}),
    ...(typeof search["c"] === "string" ? { c: search["c"] } : {}),
  }),
  ssr: false,
  head: () => ({ meta: [{ title: "Configure seu móvel · Modelador 3D" }] }),
  component: TenantPage,
});
function TenantPage() {
  const { tenant } = Route.useParams();
  const { project: projectId, c: sharedConfig } = Route.useSearch();
  const q = useQuery({
    queryKey: ["tenant", tenant],
    queryFn: () => getTenant(tenant),
    retry: false,
    staleTime: 0,
  });
  const [project, setProject] = useState<LoadedProject | null>(null);
  const [projectError, setProjectError] = useState("");
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setProject(null);
    setProjectError("");
    setLoading(false);
    if (!q.data) return;
    let alive = true;
    const id = projectId;
    if (!id) return;
    setLoading(true);
    const load = async () => {
      try {
        const ref = getGuestProjectRef(id);
        if (ref?.tenantSlug === tenant) {
          const guest = await fetchGuestProject(ref);
          if (!alive) return;
          setProject({
            config: guest.config,
            id: guest.id,
            code: guest.code,
            created_at: guest.created_at,
            project_name: guest.project_name,
            preview_image: guest.preview_image,
          });
          return;
        }
        const { data, error } = await client()
          .from("projects")
          .select("id,code,project_name,created_at,config,preview_image")
          .eq("id", id)
          .eq("organization_id", q.data!.organization.id)
          .single();
        if (error) throw error;
        if (!alive) return;
        setProject(data as LoadedProject);
      } catch (error) {
        if (!alive) return;
        setProjectError(
          getGuestProjectRef(id)
            ? "Não foi possível confirmar a credencial deste projeto."
            : "Entre com uma conta da marcenaria para abrir este projeto.",
        );
      } finally {
        if (alive) setLoading(false);
      }
    };
    void load();
    return () => {
      alive = false;
    };
  }, [q.data, projectId, tenant]);
  useEffect(() => {
    if (q.data) document.title = `${q.data.organization.name} · Configure seu móvel`;
  }, [q.data]);
  if (
    q.isPending ||
    loading ||
    (typeof window !== "undefined" && projectId && !project && !projectError && !q.error)
  )
    return (
      <main className="flex min-h-screen items-center justify-center">
        Preparando seu configurador…
      </main>
    );
  if (q.error || projectError)
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-4 px-6 text-center">
        <h1 className="font-display text-3xl">Configurador indisponível</h1>
        <p>
          {projectError ||
            ("message" in q.error!
              ? String(q.error!.message)
              : "Não foi possível carregar a marcenaria.")}
        </p>
        <Link to="/" className="btn-primary">
          Voltar ao início
        </Link>
      </main>
    );
  const models = q.data?.catalog.filter((entry) => entry.kind === "model") ?? [];
  const materials = q.data?.catalog.filter((entry) => entry.kind === "material") ?? [];
  if (
    (models.length && !models.some((entry) => entry.active)) ||
    (materials.length && !materials.some((entry) => entry.active))
  )
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-6">
        <h1 className="font-display text-3xl">{q.data?.organization.name}</h1>
        <p>O catálogo está sendo atualizado. Volte em breve.</p>
      </main>
    );
  return (
    <TenantContext.Provider value={q.data!}>
      <ConfiguradorPage
        key={`${tenant}-${projectId ?? sharedConfig ?? "new"}-${project ? "loaded" : "draft"}`}
        {...(project ? { projectConfig: project.config } : {})}
        {...(project
          ? {
              projectInfo: {
                id: project.id,
                code: project.code,
                createdAt: project.created_at,
                ...(project.project_name ? { projectName: project.project_name } : {}),
                organizationId: q.data!.organization.id,
                ...(project.preview_image ? { previewImage: project.preview_image } : {}),
              },
            }
          : {})}
      />
    </TenantContext.Provider>
  );
}
