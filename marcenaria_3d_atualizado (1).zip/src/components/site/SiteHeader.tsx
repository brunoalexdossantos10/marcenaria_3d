import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import movaLogo from "@/assets/mova-logo-transparent.png";
import movaLogoWhite from "@/assets/mova-logo-white.png";
import { LANDING_SECTION_NAVIGATION, PRIMARY_NAVIGATION } from "./siteNavigation";

export function SiteHeader({
  variant = "default",
  showSectionLinks = false,
}: {
  variant?: "default" | "overlay";
  showSectionLinks?: boolean;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const overlay = variant === "overlay";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const primaryLinkClass = overlay
    ? "mova-nav-link whitespace-nowrap text-[10px] uppercase tracking-[0.14em] text-white/75 hover:text-white"
    : "nav-link";
  const sectionLinkClass = overlay
    ? "mova-nav-link whitespace-nowrap text-[10px] uppercase tracking-[0.14em] text-white/65 hover:text-white"
    : "nav-link";

  return (
    <header
      className={
        overlay
          ? "absolute inset-x-0 top-0 z-40 border-b border-white/20 text-white"
          : `sticky top-0 z-40 border-b transition-all duration-300 ${
              scrolled
                ? "border-[#26231f]/15 bg-[#f2efe8]/95 backdrop-blur-md"
                : "border-[#26231f]/10 bg-[#f2efe8]"
            } text-[#26231f]`
      }
    >
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-5 px-5 py-4 lg:px-10">
        <Link to="/" className="group flex shrink-0 items-center" aria-label="MOVA — início">
          <img
            src={overlay ? movaLogoWhite : movaLogo}
            alt="MOVA"
            className="mova-site-logo transition-transform duration-300 group-hover:scale-[1.03]"
          />
        </Link>

        <nav aria-label="Navegação principal" className="hidden items-center gap-4 xl:flex">
          {PRIMARY_NAVIGATION.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={primaryLinkClass}
              {...(!overlay ? { activeProps: { className: "nav-link nav-link-active" } } : {})}
            >
              {item.label}
            </Link>
          ))}
          {showSectionLinks &&
            LANDING_SECTION_NAVIGATION.map((item) => (
              <a key={item.href} href={item.href} className={sectionLinkClass}>
                {item.label}
              </a>
            ))}
        </nav>

        <div className="hidden shrink-0 items-center gap-3 xl:flex">
          <Link to="/configurador" className={overlay ? "mova-header-cta" : "mova-interior-cta"}>
            Explorar o modelador
          </Link>
        </div>

        <button
          type="button"
          className={
            overlay
              ? "grid size-10 place-items-center border border-white/35 text-white xl:hidden"
              : "step-btn xl:hidden"
          }
          onClick={() => setOpen((value) => !value)}
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          aria-controls="site-mobile-navigation"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      <div
        id="site-mobile-navigation"
        className={`overflow-hidden transition-[max-height,opacity] duration-300 xl:hidden ${
          overlay
            ? "border-white/15 bg-[#26231f]/95 text-white backdrop-blur"
            : "border-[#26231f]/10 bg-[#f2efe8]/98 text-[#26231f] backdrop-blur"
        } ${open ? "max-h-[32rem] border-t opacity-100" : "max-h-0 opacity-0"}`}
      >
        <nav
          aria-label="Navegação móvel"
          className="mx-auto flex max-w-[1440px] flex-col gap-1 px-5 py-4 lg:px-10"
        >
          {PRIMARY_NAVIGATION.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              className={
                overlay
                  ? "py-2.5 text-sm uppercase tracking-[0.12em] text-white/85"
                  : "nav-link py-2.5 text-base"
              }
            >
              {item.label}
            </Link>
          ))}
          {showSectionLinks &&
            LANDING_SECTION_NAVIGATION.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="py-2.5 text-sm uppercase tracking-[0.12em] text-white/65"
              >
                {item.label}
              </a>
            ))}
          <Link
            to="/configurador"
            onClick={() => setOpen(false)}
            className={overlay ? "mova-button-light mt-3 justify-center" : "btn-primary mt-3"}
          >
            Explorar o modelador
          </Link>
        </nav>
      </div>
    </header>
  );
}

export default SiteHeader;
