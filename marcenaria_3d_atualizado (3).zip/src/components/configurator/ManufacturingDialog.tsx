import { useMemo, useState } from "react";
import {
  X,
  Download,
  Copy,
  ClipboardList,
  Ruler,
  Layers3,
  FileText,
  Package,
  AlertTriangle,
} from "lucide-react";
import { nextProjectCode } from "@/lib/furniture/store";
import { MATERIALS } from "@/lib/furniture/materials";
import { typeDef } from "@/lib/furniture/types";
import {
  buildFabricationDocument,
  applyFabricationPieceOverrides,
  calculatePanelCutPlan,
  createZipBytes,
  cutPlanSvg,
  fabricationDrawingSvg,
  fabricationPiecesCsv,
  manufacturingSummary,
  textBytes,
  validationCounts,
  type CutPlanParameters,
  type CutPlanResult,
  type DrawingView,
  type FabricationMetadata,
  type FabricationEdge,
  type FabricationPieceOverrides,
  edgeBandingLengthCm,
} from "@/lib/furniture/manufacturing";
import { createManufacturingPdf } from "@/lib/furniture/manufacturingPdf";
import type { Configurator } from "@/lib/furniture/store";

const TABS = [
  ["project", "Projeto"],
  ["drawings", "Desenhos"],
  ["pieces", "Peças"],
  ["materials", "Materiais"],
  ["cut", "Plano de corte"],
  ["checks", "Validação"],
  ["export", "Exportar"],
] as const;
type Tab = (typeof TABS)[number][0];
const VIEWS: { id: DrawingView; label: string }[] = [
  { id: "front", label: "Frente" },
  { id: "side", label: "Lateral" },
  { id: "top", label: "Superior" },
  { id: "exploded", label: "Explodida" },
];

function filename(value: string) {
  return (
    value
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, "-")
      .replace(/^-+|-+$/g, "") || "projeto"
  );
}
function saveFile(data: BlobPart, name: string, type: string) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function groupKey(materialId: string, thickness: number) {
  return `${materialId}:${thickness.toFixed(3)}`;
}
function statusStyle(severity: string) {
  if (severity === "critical") return "border-red-300 bg-red-50 text-red-950";
  if (severity === "pending") return "border-amber-300 bg-amber-50 text-amber-950";
  if (severity === "warning") return "border-blue-200 bg-blue-50 text-blue-950";
  return "border-emerald-200 bg-emerald-50 text-emerald-950";
}

export function ManufacturingDialog({
  c,
  onClose,
  captureImage,
}: {
  c: Configurator;
  onClose: () => void;
  captureImage?: () => string | null;
}) {
  const [tab, setTab] = useState<Tab>("project");
  const [view, setView] = useState<DrawingView>("front");
  const [metadata, setMetadata] = useState<FabricationMetadata>(() => ({
    projectName: typeDef(c.config.type).label,
    projectCode: nextProjectCode(),
    revision: "1",
    customerName: "",
    workshopName: "",
    recipient: "",
  }));
  const [pieceOverrides, setPieceOverrides] = useState<FabricationPieceOverrides>({});
  const [planInputs, setPlanInputs] = useState<Record<string, Partial<CutPlanParameters>>>({});
  const [cutPlans, setCutPlans] = useState<Record<string, CutPlanResult>>({});
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const sourceDocument = useMemo(
    () => buildFabricationDocument(c.config, metadata, c.parts),
    [c.config, c.parts, metadata],
  );
  const document = useMemo(
    () => applyFabricationPieceOverrides(sourceDocument, pieceOverrides),
    [sourceDocument, pieceOverrides],
  );
  const counts = validationCounts(document.issues);
  const bandingLengthM = edgeBandingLengthCm(document.pieces) / 100;
  const activeSvg = useMemo(() => fabricationDrawingSvg(document, view), [document, view]);
  const projectFileName = filename(metadata.projectCode || metadata.projectName || "projeto-mova");
  const projectLabel = metadata.projectName || typeDef(c.config.type).label;
  const pieceLookup = useMemo(
    () => new Map(document.pieces.map((piece) => [piece.code, piece])),
    [document.pieces],
  );

  const updateMetadata = (key: keyof FabricationMetadata, value: string) => {
    setMetadata((current) => ({ ...current, [key]: value }));
    setMessage("");
    setError("");
  };
  const updatePlanInput = (
    key: string,
    input: keyof CutPlanParameters,
    value: number | boolean | undefined,
  ) => {
    setPlanInputs((current) => ({ ...current, [key]: { ...current[key], [input]: value } }));
    setCutPlans((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
    setError("");
  };

  const updatePiece = (partId: string, patch: NonNullable<FabricationPieceOverrides[string]>) => {
    setPieceOverrides((current) => {
      const merged = Object.fromEntries(
        Object.entries({ ...current[partId], ...patch }).filter(([, value]) => value !== undefined),
      ) as FabricationPieceOverrides[string];
      const next = { ...current };
      if (Object.keys(merged).length === 0) delete next[partId];
      else next[partId] = merged;
      return next;
    });
    setCutPlans({});
    setMessage("");
    setError("");
  };

  const clearPieceOverride = (
    partId: string,
    field: keyof NonNullable<FabricationPieceOverrides[string]>,
  ) => {
    setPieceOverrides((current) => {
      const pieceOverride = current[partId];
      if (!pieceOverride) return current;
      const cleaned = { ...pieceOverride };
      delete cleaned[field];
      const next = { ...current };
      if (Object.keys(cleaned).length === 0) delete next[partId];
      else next[partId] = cleaned;
      return next;
    });
    setCutPlans({});
    setMessage("");
    setError("");
  };

  const addDrawings = (
    files: { name: string; data: Uint8Array }[],
    targetDocument: typeof document,
  ) => {
    for (const drawing of VIEWS) {
      files.push({
        name: `desenhos/${drawing.id}.svg`,
        data: textBytes(fabricationDrawingSvg(targetDocument, drawing.id)),
      });
    }
  };
  const buildPackageEntries = async (targetDocument: typeof document) => {
    const preview = captureImage?.() ?? null;
    const pdf = await createManufacturingPdf(
      targetDocument,
      preview,
      Object.fromEntries(
        targetDocument.materialGroups.flatMap((group) => {
          const key = groupKey(group.materialId, group.thicknessCm);
          return cutPlans[key]
            ? [[key, { materialName: group.materialName, plan: cutPlans[key]! }]]
            : [];
        }),
      ),
    );
    const files: { name: string; data: Uint8Array }[] = [
      { name: "projeto-tecnico.pdf", data: pdf },
      { name: "lista-de-pecas.csv", data: textBytes(fabricationPiecesCsv(targetDocument)) },
      {
        name: "projeto.json",
        data: textBytes(
          JSON.stringify(
            {
              exportedAt: targetDocument.generatedAt,
              document: targetDocument,
              pieceOverrides,
              cutPlans,
              visibleModelParts: c.parts.map((part) => ({
                id: part.id,
                label: part.label,
                kind: part.kind,
                positionCm: part.pos,
                boundingSizeCm: part.size,
                materialId: part.material ?? null,
                shape: part.shape ?? null,
                geometry: part.geometry ?? null,
                parent: part.parent ?? null,
              })),
            },
            null,
            2,
          ),
        ),
      },
      {
        name: "validacao.json",
        data: textBytes(
          JSON.stringify(
            {
              generatedAt: targetDocument.generatedAt,
              projectCode: targetDocument.metadata.projectCode,
              revision: targetDocument.metadata.revision,
              readyForManufacture: false,
              counts: validationCounts(targetDocument.issues),
              issues: targetDocument.issues,
            },
            null,
            2,
          ),
        ),
      },
      {
        name: "LEIA-ANTES.txt",
        data: textBytes(
          `PACOTE TÉCNICO PRELIMINAR — NÃO LIBERADO PARA PRODUÇÃO\nProjeto: ${targetDocument.metadata.projectName}\nCódigo: ${targetDocument.metadata.projectCode} · Revisão: ${targetDocument.metadata.revision} · Gerado: ${targetDocument.generatedAt}\n\nAs peças e os desenhos refletem os volumes do configurador MOVA, não um CAD/CAM completo. Confirme medidas, materiais comerciais, veio, fitas, ferragens, folgas, usinagens e montagem com a marcenaria. O plano de chapa é uma heurística e só aparece quando as dimensões comerciais e parâmetros foram informados.\n\nA revisão do pacote não é um histórico de revisão persistido pelo MOVA.\n`,
        ),
      },
    ];
    addDrawings(files, targetDocument);
    for (const group of targetDocument.materialGroups) {
      const key = groupKey(group.materialId, group.thicknessCm);
      const plan = cutPlans[key];
      if (!plan) continue;
      plan.sheets.forEach((sheet, index) => {
        files.push({
          name: `plano-de-corte/${filename(group.materialName)}-${group.thicknessCm.toFixed(2)}cm-chapa-${sheet.number}.svg`,
          data: textBytes(
            cutPlanSvg(
              plan,
              pieceLookup,
              index,
              targetDocument.metadata,
              targetDocument.generatedAt,
            ),
          ),
        });
      });
    }
    return files;
  };

  const downloadPdf = async () => {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const exportDocument = { ...document, generatedAt: new Date().toISOString() };
      const pdf = await createManufacturingPdf(
        exportDocument,
        captureImage?.() ?? null,
        Object.fromEntries(
          exportDocument.materialGroups.flatMap((group) => {
            const key = groupKey(group.materialId, group.thicknessCm);
            return cutPlans[key]
              ? [[key, { materialName: group.materialName, plan: cutPlans[key]! }]]
              : [];
          }),
        ),
      );
      saveFile(pdf, `${projectFileName}-tecnico.pdf`, "application/pdf");
      setMessage(
        "PDF técnico preliminar gerado. Confira as pendências antes de encaminhar para produção.",
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível gerar o PDF técnico.");
    } finally {
      setBusy(false);
    }
  };

  const downloadZip = async (share = false) => {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const exportDocument = { ...document, generatedAt: new Date().toISOString() };
      const files = await buildPackageEntries(exportDocument);
      const bytes = createZipBytes(files);
      const name = `${projectFileName}-fabricacao.zip`;
      if (share) {
        const shareApi = navigator as Navigator & {
          share?: (data: ShareData) => Promise<void>;
          canShare?: (data: ShareData) => boolean;
        };
        const packageFile = new File([bytes], name, { type: "application/zip" });
        if (shareApi.share && shareApi.canShare?.({ files: [packageFile] })) {
          await shareApi.share({
            files: [packageFile],
            title: `${projectLabel} · pacote técnico`,
            text: manufacturingSummary(exportDocument),
          });
          setMessage(
            "O pacote foi entregue ao menu de compartilhamento do dispositivo. Confirme o destinatário e a revisão no aplicativo de destino.",
          );
        } else {
          saveFile(bytes, name, "application/zip");
          setMessage(
            "Este navegador não compartilha arquivos diretamente; o ZIP foi baixado para envio manual.",
          );
        }
      } else {
        saveFile(bytes, name, "application/zip");
        setMessage("Pacote ZIP gerado com PDF, CSV, desenhos, modelo JSON e validação.");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível criar o pacote ZIP.");
    } finally {
      setBusy(false);
    }
  };

  const copySummary = async () => {
    setError("");
    try {
      await navigator.clipboard.writeText(
        manufacturingSummary({ ...document, generatedAt: new Date().toISOString() }),
      );
      setMessage("Resumo copiado. Nenhum destinatário foi contatado.");
    } catch {
      setError("Não foi possível acessar a área de transferência neste navegador.");
    }
  };

  const generateCutPlan = (group: (typeof document.materialGroups)[number]) => {
    const key = groupKey(group.materialId, group.thicknessCm);
    const raw = planInputs[key] ?? {};
    const params: CutPlanParameters = {
      sheetWidthCm: Number(raw.sheetWidthCm),
      sheetHeightCm: Number(raw.sheetHeightCm),
      kerfCm: Number(raw.kerfCm),
      marginCm: Number(raw.marginCm),
      allowRotation: Boolean(raw.allowRotation),
    };
    try {
      const groupPieces = document.pieces.filter(
        (piece) =>
          piece.materialId === group.materialId &&
          Math.abs(piece.thicknessCm - group.thicknessCm) < 0.0005,
      );
      const plan = calculatePanelCutPlan(groupPieces, params);
      setCutPlans((current) => ({ ...current, [key]: plan }));
      setError("");
      setMessage(
        `Plano heurístico calculado para ${group.materialName}, ${group.thicknessCm.toFixed(2)} cm.`,
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Informe todos os parâmetros da chapa.");
    }
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center bg-foreground/50 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      role="presentation"
    >
      <section
        className="flex max-h-[96vh] w-full max-w-6xl flex-col overflow-hidden rounded-t-2xl border border-border bg-background shadow-2xl sm:max-h-[92vh] sm:rounded-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="manufacturing-title"
      >
        <header className="flex shrink-0 items-start justify-between gap-4 border-b border-border px-5 py-4 sm:px-7">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">
              MOVA · fabricação
            </p>
            <h2 id="manufacturing-title" className="mt-1 font-display text-xl sm:text-2xl">
              Projeto técnico preliminar
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Derivado do móvel ativo · não liberado para produção
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar projeto técnico"
            className="step-btn shrink-0"
          >
            <X className="size-4" />
          </button>
        </header>

        <div className="shrink-0 overflow-x-auto border-b border-border px-3 sm:px-6">
          <div
            className="flex min-w-max gap-1"
            role="tablist"
            aria-label="Seções do projeto técnico"
          >
            {TABS.map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={tab === id}
                onClick={() => setTab(id)}
                className={`border-b-2 px-3 py-3 text-xs font-semibold ${tab === id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-7 sm:py-6">
          {tab === "project" && (
            <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="space-y-4">
                <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-950">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                    <div>
                      <strong>Documento preliminar — não cortar material ainda.</strong>
                      <p className="mt-1 text-xs leading-5">
                        A cena atual foi construída para visualização paramétrica. A lista é
                        restrita aos painéis retangulares reconhecidos no modelo e não inventa
                        ferragens, fitas, veio, folgas ou usinagens ausentes.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {(
                    [
                      ["projectName", "Nome do projeto", 120],
                      ["projectCode", "Código do pacote", 40],
                      ["revision", "Revisão deste pacote", 20],
                      ["customerName", "Cliente", 120],
                      ["workshopName", "Marcenaria", 120],
                      ["recipient", "Destinatário pretendido", 120],
                    ] as const
                  ).map(([key, label, maxLength]) => (
                    <label key={key} className="block text-xs text-muted-foreground">
                      {label}
                      <input
                        value={metadata[key]}
                        maxLength={maxLength}
                        onChange={(event) => updateMetadata(key, event.target.value)}
                        className="mt-1 h-10 w-full rounded-lg border border-border bg-card px-3 text-sm text-foreground outline-none focus:border-ring"
                      />
                    </label>
                  ))}
                </div>
                <div className="rounded-xl border border-border bg-card p-4">
                  <h3 className="flex items-center gap-2 text-sm font-semibold">
                    <Ruler className="size-4" />
                    Dimensões nominais do configurador
                  </h3>
                  <p className="mt-2 font-display text-2xl tabular-nums">
                    {c.config.width} × {c.config.height} × {c.config.depth}{" "}
                    <span className="text-base">cm</span>
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Largura × altura × profundidade · posição de instalação no cômodo não altera a
                    peça.
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="rounded-xl border border-border p-4">
                  <h3 className="flex items-center gap-2 text-sm font-semibold">
                    <ClipboardList className="size-4" />
                    Resumo do modelo
                  </h3>
                  <dl className="mt-3 divide-y divide-border text-sm">
                    <div className="flex justify-between gap-3 py-2">
                      <dt className="text-muted-foreground">Tipo</dt>
                      <dd className="text-right">{typeDef(c.config.type).label}</dd>
                    </div>
                    <div className="flex justify-between gap-3 py-2">
                      <dt className="text-muted-foreground">Volumes na cena</dt>
                      <dd>{document.visiblePartCount}</dd>
                    </div>
                    <div className="flex justify-between gap-3 py-2">
                      <dt className="text-muted-foreground">Placas retangulares identificadas</dt>
                      <dd>{document.pieces.length}</dd>
                    </div>
                    <div className="flex justify-between gap-3 py-2">
                      <dt className="text-muted-foreground">Materiais/espessuras</dt>
                      <dd>{document.materialGroups.length} grupo(s)</dd>
                    </div>
                  </dl>
                </div>
                <div className="grid grid-cols-2 gap-2 text-center text-xs">
                  <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-red-900">
                    <strong className="block text-xl">{counts.critical}</strong>crítico(s)
                  </div>
                  <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-amber-950">
                    <strong className="block text-xl">{counts.pending}</strong>pendência(s)
                  </div>
                </div>
                <p className="text-xs leading-5 text-muted-foreground">
                  Código, revisão e contato ficam gravados nos arquivos exportados. Nesta versão,
                  não são persistidos como histórico do projeto no banco do MOVA.
                </p>
              </div>
            </div>
          )}

          {tab === "drawings" && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1" role="group" aria-label="Vistas do desenho">
                  {VIEWS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setView(item.id)}
                      className={`chip text-xs ${view === item.id ? "chip-active" : ""}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  className="btn-ghost h-9 text-xs"
                  onClick={() =>
                    saveFile(
                      textBytes(
                        fabricationDrawingSvg(
                          { ...document, generatedAt: new Date().toISOString() },
                          view,
                        ),
                      ),
                      `${projectFileName}-${view}.svg`,
                      "image/svg+xml;charset=utf-8",
                    )
                  }
                >
                  <Download className="mr-1.5 size-3.5" />
                  Baixar esta vista SVG
                </button>
              </div>
              <div
                className="overflow-hidden rounded-xl border border-border bg-white"
                dangerouslySetInnerHTML={{ __html: activeSvg }}
              />
              <p className="text-xs leading-5 text-muted-foreground">
                As cotas nominais vêm do projeto; os retângulos são envelopes das geometrias atuais.
                O desenho não representa furos, encaixes, usinagens ou contornos especiais. A vista
                explodida só desloca esquematicamente os componentes existentes e não define
                sequência de montagem.
              </p>
            </div>
          )}

          {tab === "pieces" && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs leading-5 text-blue-950">
                <Layers3 className="size-4 shrink-0" />A lista parte dos componentes retangulares e
                dos materiais do construtor. Edite as medidas por peça, material, veio e arestas
                aqui; os ajustes valem para este pacote, não alteram o modelo 3D salvo. Geometria
                especial e tolerâncias continuam pendentes.
              </div>
              {document.pieces.length ? (
                <div className="overflow-x-auto rounded-xl border border-border">
                  <table className="w-full min-w-[920px] text-left text-xs">
                    <thead className="bg-card text-muted-foreground">
                      <tr>
                        {[
                          "Código",
                          "Componente MOVA",
                          "Descrição",
                          "Qtd.",
                          "Comp. cm",
                          "Larg. cm",
                          "Esp. cm",
                          "Material",
                          "Veio / bordas",
                        ].map((label) => (
                          <th key={label} className="px-3 py-2.5 font-semibold">
                            {label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {document.pieces.map((piece) => (
                        <tr key={piece.partId} className="align-top">
                          <td className="px-3 py-2.5 font-semibold">{piece.code}</td>
                          <td className="px-3 py-2.5 font-mono">{piece.partId}</td>
                          <td className="px-3 py-2.5">
                            {piece.name}
                            <p className="mt-1 max-w-64 text-[10px] text-muted-foreground">
                              {piece.observation}
                            </p>
                          </td>
                          <td className="px-3 py-2.5">{piece.quantity}</td>
                          {(
                            [
                              ["lengthCm", piece.lengthCm],
                              ["widthCm", piece.widthCm],
                              ["thicknessCm", piece.thicknessCm],
                            ] as const
                          ).map(([field, value]) => (
                            <td key={field} className="px-3 py-2.5">
                              <input
                                aria-label={`${piece.name}: ${field}`}
                                type="number"
                                min="0.1"
                                max="1000"
                                step="0.1"
                                value={pieceOverrides[piece.partId]?.[field] ?? value}
                                onChange={(event) => {
                                  if (event.target.value === "")
                                    clearPieceOverride(piece.partId, field);
                                  else
                                    updatePiece(piece.partId, {
                                      [field]: Number(event.target.value),
                                    });
                                }}
                                className="h-8 w-20 rounded-md border border-border bg-card px-2 text-right tabular-nums text-foreground"
                              />
                            </td>
                          ))}
                          <td className="px-3 py-2.5">
                            <select
                              aria-label={`${piece.name}: material`}
                              value={piece.materialId}
                              onChange={(event) =>
                                updatePiece(piece.partId, { materialId: event.target.value })
                              }
                              className="h-8 max-w-40 rounded-md border border-border bg-card px-2 text-foreground"
                            >
                              {MATERIALS.filter(
                                (item) => item.finish !== "vidro" && item.finish !== "espelho",
                              ).map((item) => (
                                <option key={item.id} value={item.id}>
                                  {item.label}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="min-w-64 px-3 py-2.5">
                            <label className="sr-only" htmlFor={`grain-${piece.partId}`}>
                              Direção do veio para {piece.name}
                            </label>
                            <select
                              id={`grain-${piece.partId}`}
                              value={piece.grainDirection ?? ""}
                              onChange={(event) => {
                                if (!event.target.value)
                                  clearPieceOverride(piece.partId, "grainDirection");
                                else
                                  updatePiece(piece.partId, {
                                    grainDirection: event.target.value as
                                      "length" | "width" | "none",
                                  });
                              }}
                              className="mb-2 h-8 w-full rounded-md border border-border bg-card px-2 text-foreground"
                            >
                              <option value="">Veio: selecionar…</option>
                              <option value="length">Paralelo ao comprimento</option>
                              <option value="width">Paralelo à largura</option>
                              <option value="none">Sem veio obrigatório</option>
                            </select>
                            <div className="grid grid-cols-3 gap-x-2 gap-y-1 text-[10px]">
                              <label className="flex items-center gap-1">
                                <input
                                  type="checkbox"
                                  checked={piece.edgeBanding?.length === 0}
                                  onChange={(event) => {
                                    if (event.target.checked)
                                      updatePiece(piece.partId, { edgeBanding: [] });
                                    else clearPieceOverride(piece.partId, "edgeBanding");
                                  }}
                                />
                                Sem fita
                              </label>
                              {(["L1", "L2", "C1", "C2"] as FabricationEdge[]).map((edge) => (
                                <label
                                  key={edge}
                                  className="flex items-center gap-1"
                                  title={
                                    edge.startsWith("L")
                                      ? "Aresta ao longo do comprimento"
                                      : "Aresta ao longo da largura"
                                  }
                                >
                                  <input
                                    type="checkbox"
                                    checked={piece.edgeBanding?.includes(edge) ?? false}
                                    onChange={(event) => {
                                      const selected = new Set(piece.edgeBanding ?? []);
                                      if (event.target.checked) selected.add(edge);
                                      else selected.delete(edge);
                                      updatePiece(piece.partId, { edgeBanding: [...selected] });
                                    }}
                                  />
                                  {edge}
                                </label>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="rounded-xl border border-border p-6 text-sm text-muted-foreground">
                  Nenhuma peça pode ser listada com o perfil disponível. A validação explica o
                  motivo; não será criada uma lista genérica.
                </div>
              )}
            </div>
          )}

          {tab === "materials" && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {document.materialGroups.map((group) => (
                  <article
                    key={groupKey(group.materialId, group.thicknessCm)}
                    className="rounded-xl border border-border bg-card p-4"
                  >
                    <p className="font-semibold">{group.materialName}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Acabamento cadastrado: {group.finish} · espessura geométrica:{" "}
                      {group.thicknessCm.toFixed(2)} cm
                    </p>
                    <div className="mt-4 flex items-end justify-between">
                      <span className="text-xs text-muted-foreground">Peças mapeadas</span>
                      <strong className="text-xl">{group.pieceCount}</strong>
                    </div>
                    <div className="mt-2 flex items-end justify-between">
                      <span className="text-xs text-muted-foreground">Área líquida das faces</span>
                      <strong>{group.netAreaM2.toFixed(3)} m²</strong>
                    </div>
                    <p className="mt-2 text-[10px] leading-4 text-muted-foreground">
                      Não inclui refilo, defeitos, perdas, bordas, aproveitamento da chapa ou
                      componentes omitidos.
                    </p>
                  </article>
                ))}
              </div>
              {bandingLengthM > 0 && (
                <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs leading-5 text-amber-950">
                  <strong>
                    Fita selecionada: {bandingLengthM.toFixed(2)} m lineares geométricos.
                  </strong>
                  <p>
                    É a soma das arestas marcadas nas peças; confirme tipo, espessura, cor, emendas
                    e perdas antes da compra.
                  </p>
                </div>
              )}
              <section className="rounded-xl border border-border p-4">
                <h3 className="text-sm font-semibold">Componentes e ferragens vistos no modelo</h3>
                <ul className="mt-2 space-y-2 text-xs leading-5 text-muted-foreground">
                  <li>
                    Frentes de porta no construtor:{" "}
                    <strong className="text-foreground">
                      {c.parts.filter((part) => part.kind === "porta").length}
                    </strong>
                    . Quantidade/tipo de dobradiças, trilhos, parafusos e furação:{" "}
                    <strong className="text-amber-800">não especificados</strong>.
                  </li>
                  <li>
                    Frentes de gaveta no construtor:{" "}
                    <strong className="text-foreground">
                      {c.parts.filter((part) => part.kind === "gaveta").length}
                    </strong>
                    . Caixas, corrediças e folgas:{" "}
                    <strong className="text-red-800">não representadas</strong>.
                  </li>
                  <li>
                    Puxadores visíveis:{" "}
                    <strong className="text-foreground">
                      {c.parts.filter((part) => part.kind === "puxador").length}
                    </strong>
                    . Código comercial, furação e parafusos:{" "}
                    <strong className="text-amber-800">pendentes</strong>.
                  </li>
                </ul>
              </section>
            </div>
          )}

          {tab === "cut" && (
            <div className="space-y-5">
              <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs leading-5 text-amber-950">
                <strong>Sem padrão de chapa presumido.</strong> Informe largura/altura comercial,
                refilo, espessura de corte e se o veio permite girar cada peça. O resultado é uma
                heurística de encaixe por faixas; não é plano otimizado de serra/CNC.
              </div>
              {document.materialGroups.length ? (
                document.materialGroups.map((group) => {
                  const key = groupKey(group.materialId, group.thicknessCm);
                  const values = planInputs[key] ?? {};
                  const plan = cutPlans[key];
                  const groupPieces = document.pieces.filter(
                    (piece) =>
                      piece.materialId === group.materialId &&
                      Math.abs(piece.thicknessCm - group.thicknessCm) < 0.0005,
                  );
                  return (
                    <section key={key} className="space-y-3 rounded-xl border border-border p-4">
                      <div>
                        <h3 className="font-semibold">
                          {group.materialName} · {group.thicknessCm.toFixed(2)} cm
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          {groupPieces.length} peça(s) · área líquida {group.netAreaM2.toFixed(3)}{" "}
                          m²
                        </p>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-4">
                        {(["sheetWidthCm", "sheetHeightCm", "marginCm", "kerfCm"] as const).map(
                          (field) => {
                            const labels = {
                              sheetWidthCm: "Largura da chapa (cm)",
                              sheetHeightCm: "Altura da chapa (cm)",
                              marginCm: "Margem/refilo (cm)",
                              kerfCm: "Espessura de corte (cm)",
                            };
                            return (
                              <label key={field} className="text-xs text-muted-foreground">
                                {labels[field]}
                                <input
                                  type="number"
                                  min="0"
                                  step="0.1"
                                  value={values[field] ?? ""}
                                  onChange={(event) =>
                                    updatePlanInput(
                                      key,
                                      field,
                                      event.target.value === ""
                                        ? undefined
                                        : Number(event.target.value),
                                    )
                                  }
                                  className="mt-1 h-10 w-full rounded-lg border border-border bg-card px-3 text-sm text-foreground"
                                />
                              </label>
                            );
                          },
                        )}
                      </div>
                      <label className="flex items-start gap-2 text-xs leading-5">
                        <input
                          type="checkbox"
                          checked={Boolean(values.allowRotation)}
                          onChange={(event) =>
                            updatePlanInput(key, "allowRotation", event.target.checked)
                          }
                          className="mt-1"
                        />
                        <span>
                          Permitir giro de 90° apenas nas peças marcadas “sem veio obrigatório”.
                          Peças com veio pendente ou direcional ficam na orientação original.
                        </span>
                      </label>
                      <button
                        type="button"
                        onClick={() => generateCutPlan(group)}
                        className="btn-primary h-10 px-4 text-xs"
                      >
                        Calcular proposta heurística
                      </button>
                      {plan && (
                        <div className="space-y-3 border-t border-border pt-3">
                          <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-5">
                            <div>
                              <span className="text-muted-foreground">Chapas na heurística</span>
                              <strong className="block text-lg">{plan.sheets.length}</strong>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Área líquida</span>
                              <strong className="block">{plan.netAreaM2.toFixed(3)} m²</strong>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Área bruta</span>
                              <strong className="block">{plan.grossAreaM2.toFixed(3)} m²</strong>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Área não encaixada</span>
                              <strong className="block">{plan.unplacedAreaM2.toFixed(3)} m²</strong>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Perda bruta estimada</span>
                              <strong className="block">
                                {plan.wastePercent === null
                                  ? "—"
                                  : `${plan.wastePercent.toFixed(1)}%`}
                              </strong>
                            </div>
                          </div>
                          {plan.sheets.map((sheet, index) => (
                            <div
                              key={sheet.number}
                              className="overflow-hidden rounded-lg border border-border bg-white"
                              dangerouslySetInnerHTML={{
                                __html: cutPlanSvg(
                                  plan,
                                  pieceLookup,
                                  index,
                                  document.metadata,
                                  document.generatedAt,
                                ),
                              }}
                            />
                          ))}
                          {plan.unplaced.length > 0 && (
                            <div
                              role="alert"
                              className="rounded-lg border border-red-300 bg-red-50 p-3 text-xs text-red-950"
                            >
                              <strong>Peças sem encaixe:</strong>
                              <ul className="mt-1 list-inside list-disc">
                                {plan.unplaced.map((item) => (
                                  <li key={item.code}>
                                    {item.code}: {item.reason}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          <p className="text-[11px] leading-5 text-muted-foreground">
                            {plan.disclaimer}
                          </p>
                        </div>
                      )}
                    </section>
                  );
                })
              ) : (
                <p className="rounded-xl border border-border p-5 text-sm text-muted-foreground">
                  Sem placas mapeadas; o plano de corte não pode ser calculado.
                </p>
              )}
            </div>
          )}

          {tab === "checks" && (
            <div className="space-y-3">
              <p className="text-xs leading-5 text-muted-foreground">
                O status é construído a partir dos campos e componentes existentes no MOVA.
                Pendências e itens críticos permanecem visíveis no PDF e no ZIP; baixar o pacote não
                equivale a aprovar fabricação.
              </p>
              {document.issues.map((issue) => (
                <article
                  key={issue.id}
                  className={`rounded-lg border p-3 ${statusStyle(issue.severity)}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-sm font-semibold">{issue.title}</h3>
                    <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider">
                      {issue.severity === "critical"
                        ? "Crítico"
                        : issue.severity === "pending"
                          ? "Pendente"
                          : issue.severity === "warning"
                            ? "Aviso"
                            : "Verificado"}
                    </span>
                  </div>
                  <p className="mt-1 text-xs leading-5">{issue.detail}</p>
                </article>
              ))}
            </div>
          )}

          {tab === "export" && (
            <div className="mx-auto max-w-2xl space-y-4">
              <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-950">
                <strong>O material exportado é preliminar.</strong>
                <p className="mt-1 text-xs leading-5">
                  A exportação preserva pendências e não muda o status para liberado. Revise a lista
                  com a marcenaria e confira destinatário/revisão antes de compartilhar.
                </p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={downloadPdf}
                  className="btn-primary flex min-h-16 items-center justify-center gap-2"
                >
                  <FileText className="size-4" />
                  {busy ? "Preparando…" : "Baixar PDF técnico"}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    saveFile(
                      textBytes(
                        fabricationPiecesCsv({
                          ...document,
                          generatedAt: new Date().toISOString(),
                        }),
                      ),
                      `${projectFileName}-lista-pecas.csv`,
                      "text/csv;charset=utf-8",
                    )
                  }
                  className="btn-ghost flex min-h-16 items-center justify-center gap-2"
                >
                  <ClipboardList className="size-4" />
                  Baixar lista CSV
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => downloadZip(false)}
                  className="btn-ghost flex min-h-16 items-center justify-center gap-2"
                >
                  <Package className="size-4" />
                  {busy ? "Preparando ZIP…" : "Baixar pacote ZIP"}
                </button>
                <button
                  type="button"
                  onClick={copySummary}
                  className="btn-ghost flex min-h-16 items-center justify-center gap-2"
                >
                  <Copy className="size-4" />
                  Copiar resumo do projeto
                </button>
              </div>
              {typeof navigator !== "undefined" && "share" in navigator && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => downloadZip(true)}
                  className="btn-ghost flex w-full items-center justify-center gap-2"
                >
                  <Download className="size-4" />
                  Compartilhar pacote pelo dispositivo
                </button>
              )}
              <div className="rounded-xl border border-border p-4 text-xs leading-5 text-muted-foreground">
                <strong className="text-foreground">Conteúdo do ZIP:</strong> PDF técnico, CSV
                compatível com planilha, quatro desenhos SVG, dados JSON do projeto/modelo, estado
                de validação e planos heurísticos gerados. O pacote é montado localmente no
                navegador e não é enviado nem salvo no servidor pelo módulo.
              </div>
            </div>
          )}

          {(error || message) && (
            <div
              className={`mt-4 rounded-lg border p-3 text-xs ${error ? "border-red-300 bg-red-50 text-red-950" : "border-emerald-200 bg-emerald-50 text-emerald-950"}`}
              role={error ? "alert" : "status"}
            >
              {error || message}
            </div>
          )}
        </div>

        <footer className="flex shrink-0 items-center justify-between gap-3 border-t border-border bg-card/60 px-4 py-3 sm:px-7">
          <span className="hidden text-[10px] text-muted-foreground sm:inline">
            {projectLabel} · {metadata.projectCode} · revisão {metadata.revision}
          </span>
          <button type="button" onClick={onClose} className="btn-ghost ml-auto h-9 px-5 text-xs">
            Fechar
          </button>
        </footer>
      </section>
    </div>
  );
}

export default ManufacturingDialog;
