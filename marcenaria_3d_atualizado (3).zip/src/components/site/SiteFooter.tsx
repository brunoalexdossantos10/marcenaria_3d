import { Link } from "@tanstack/react-router";
import { MapPin, Phone } from "lucide-react";
import movaLogoWhite from "@/assets/mova-logo-white.png";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-[#26231f] text-[#f2efe8]">
      <div className="mx-auto grid max-w-[1440px] gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr] lg:px-10">
        <div>
          <Link to="/" className="inline-flex" aria-label="MOVA — início">
            <img src={movaLogoWhite} alt="MOVA" className="mova-footer-logo" />
          </Link>
          <p className="mt-4 max-w-md text-sm leading-6 text-white/60">
            Experiência de projeto 3D para móveis que pertencem ao seu espaço.
          </p>
        </div>

        <div className="md:justify-self-end">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/55">
            Informações
          </p>
          <ul className="mt-4 space-y-3 text-sm text-white/70">
            <li className="flex items-center gap-2">
              <Phone className="size-4 text-[#bca787]" /> (11) 4002-8922
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="size-4 text-[#bca787]" /> São Paulo · SP
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/15 px-5 py-5">
        <p className="mx-auto max-w-[1440px] text-xs text-white/45 lg:px-10">
          © {new Date().getFullYear()} MOVA. Estimativas geradas no configurador são aproximadas e
          confirmadas após visita técnica.
        </p>
      </div>
    </footer>
  );
}

export default SiteFooter;
