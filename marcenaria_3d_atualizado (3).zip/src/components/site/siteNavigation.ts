export const PRIMARY_NAVIGATION = [
  { to: "/portfolio", label: "Projetos" },
  { to: "/servicos", label: "Serviços" },
  { to: "/sobre", label: "Sobre" },
  { to: "/contato", label: "Contato" },
  { to: "/login", label: "Entrar" },
] as const;

export const LANDING_SECTION_NAVIGATION = [
  { href: "#processo", label: "O processo" },
  { href: "#valor", label: "O valor" },
  { to: "/configurador", label: "Modelador 3D" },
] as const;
