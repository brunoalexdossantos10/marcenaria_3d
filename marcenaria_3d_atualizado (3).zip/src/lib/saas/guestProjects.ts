import type { FurnitureConfig } from "@/lib/furniture/types";
import type { PriceBreakdown } from "@/lib/furniture/pricing";
import { supabase } from "@/lib/supabase";

export interface GuestProjectRef {
  projectId: string;
  tenantSlug: string;
  accessToken: string;
  code: string;
}
export interface GuestSavedProject {
  id: string;
  code: string;
  project_name: string | null;
  created_at: string;
  updated_at: string;
  config: FurnitureConfig;
  price: number;
  cost_breakdown: PriceBreakdown;
  preview_image?: string | null;
  status: string;
  organization_id: string;
}

const REF_KEY = "mova.guest-project-refs.v1";
const readRefs = (): GuestProjectRef[] => {
  if (typeof window === "undefined") return [];
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(REF_KEY) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (ref): ref is GuestProjectRef =>
        !!ref &&
        typeof ref.projectId === "string" &&
        typeof ref.tenantSlug === "string" &&
        typeof ref.accessToken === "string" &&
        /^[0-9a-f]{64}$/.test(ref.accessToken) &&
        typeof ref.code === "string",
    );
  } catch {
    return [];
  }
};
const writeRefs = (refs: GuestProjectRef[]) => {
  if (typeof window !== "undefined")
    window.localStorage.setItem(REF_KEY, JSON.stringify(refs.slice(0, 100)));
};

function newAccessToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function digestToken(token: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function invoke(body: Record<string, unknown>) {
  if (!supabase) throw new Error("A conexão com o Supabase não está configurada.");
  const { data, error } = await supabase.functions.invoke("tenant-project", { body });
  if (error) {
    if ("context" in error && error.context instanceof Response) {
      const details = await error.context.json().catch(() => null);
      if (details?.error) throw new Error(String(details.error));
    }
    throw error;
  }
  if (!data || typeof data !== "object") throw new Error("Resposta inválida ao salvar o projeto.");
  return data as Record<string, unknown>;
}

export async function saveGuestProject(
  tenantSlug: string,
  config: FurnitureConfig,
  existing?: GuestProjectRef,
  projectName = "",
  previewImage?: string,
) {
  const ref = existing ?? {
    projectId: "",
    tenantSlug,
    accessToken: newAccessToken(),
    code: "",
  };
  if (ref.tenantSlug !== tenantSlug) throw new Error("O projeto pertence a outra marcenaria.");
  const response = await invoke({
    action: existing ? "update" : "create",
    tenant_slug: tenantSlug,
    ...(existing ? { project_id: existing.projectId } : {}),
    access_token: ref.accessToken,
    configuration: config,
    project_name: projectName,
    preview_image: previewImage ?? null,
  });
  const project = response["project"] as Record<string, unknown> | undefined;
  if (!project || typeof project["id"] !== "string" || typeof project["code"] !== "string")
    throw new Error("O servidor não confirmou o salvamento do projeto.");
  const savedRef = {
    projectId: project["id"] as string,
    tenantSlug,
    accessToken: ref.accessToken,
    code: project["code"] as string,
  };
  writeRefs([savedRef, ...readRefs().filter((entry) => entry.projectId !== savedRef.projectId)]);
  return { project: project as unknown as GuestSavedProject, ref: savedRef };
}

export async function fetchGuestProject(ref: GuestProjectRef) {
  const response = await invoke({
    action: "read",
    tenant_slug: ref.tenantSlug,
    project_id: ref.projectId,
    access_token: ref.accessToken,
  });
  const project = response["project"] as Record<string, unknown> | undefined;
  if (!project || project["id"] !== ref.projectId)
    throw new Error("O projeto não foi confirmado pelo servidor.");
  return project as unknown as GuestSavedProject;
}

export async function listGuestProjects() {
  const refs = readRefs();
  return Promise.all(refs.map(async (ref) => ({ ref, project: await fetchGuestProject(ref) })));
}

export function getGuestProjectRef(projectId: string) {
  return readRefs().find((entry) => entry.projectId === projectId) ?? null;
}

export async function deleteGuestProject(ref: GuestProjectRef) {
  await invoke({
    action: "delete",
    tenant_slug: ref.tenantSlug,
    project_id: ref.projectId,
    access_token: ref.accessToken,
  });
  writeRefs(readRefs().filter((entry) => entry.projectId !== ref.projectId));
}

export async function claimGuestProject(ref: GuestProjectRef) {
  if (!supabase) throw new Error("A conexão com o Supabase não está configurada.");
  const { error } = await supabase.rpc("claim_guest_project", {
    p_tenant_slug: ref.tenantSlug,
    p_project_id: ref.projectId,
    p_token_hash: await digestToken(ref.accessToken),
  });
  if (error) throw error;
  forgetGuestProject(ref.projectId);
}

export async function claimGuestProjectsForCurrentUser() {
  if (!supabase) throw new Error("A conexão com o Supabase não está configurada.");
  const refs = readRefs();
  let claimed = 0;
  let failed = 0;
  for (const ref of refs) {
    try {
      const { data: tenant, error: tenantError } = await supabase.rpc("get_public_tenant", {
        tenant_slug: ref.tenantSlug,
      });
      if (tenantError || !tenant?.organization?.id) continue;
      const { data: userResult, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!userResult.user) break;
      const { data: membership, error: membershipError } = await supabase
        .from("organization_members")
        .select("role")
        .eq("organization_id", tenant.organization.id)
        .eq("user_id", userResult.user.id)
        .maybeSingle();
      if (membershipError) throw membershipError;
      if (membership?.role !== "CUSTOMER") continue;
      try {
        await claimGuestProject(ref);
        claimed += 1;
      } catch {
        failed += 1;
      }
    } catch {
      failed += 1;
    }
  }
  return { claimed, failed };
}

export function forgetGuestProject(projectId: string) {
  writeRefs(readRefs().filter((entry) => entry.projectId !== projectId));
}
