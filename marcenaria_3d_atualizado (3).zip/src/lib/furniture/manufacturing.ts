import { buildFurniture } from "./builder";
import { componentDef } from "./components";
import { material, MATERIALS } from "./materials";
import type { FurnitureConfig, Part } from "./types";
import { typeDef } from "./types";

export type ManufacturingSeverity = "critical" | "pending" | "warning" | "passed";
export interface ManufacturingIssue {
  id: string;
  severity: ManufacturingSeverity;
  title: string;
  detail: string;
}
export interface FabricationMetadata {
  projectName: string;
  projectCode: string;
  revision: string;
  customerName: string;
  workshopName: string;
  recipient: string;
}
export type FabricationGrainDirection = "length" | "width" | "none";
export type FabricationEdge = "L1" | "L2" | "C1" | "C2";
export interface FabricationPiece {
  code: string;
  partId: string;
  name: string;
  kind: Part["kind"];
  quantity: 1;
  lengthCm: number;
  widthCm: number;
  thicknessCm: number;
  materialId: string;
  materialName: string;
  finish: string;
  positionCm: [number, number, number];
  grainDirection: FabricationGrainDirection | null;
  edgeBanding: FabricationEdge[] | null;
  observation: string;
}
export type FabricationPieceOverrides = Record<
  string,
  Partial<
    Pick<
      FabricationPiece,
      "lengthCm" | "widthCm" | "thicknessCm" | "materialId" | "grainDirection" | "edgeBanding"
    >
  >
>;
export interface FabricationMaterialGroup {
  materialId: string;
  materialName: string;
  finish: string;
  thicknessCm: number;
  pieceCount: number;
  netAreaM2: number;
}
export interface FabricationDocument {
  schemaVersion: 1;
  generatedAt: string;
  metadata: FabricationMetadata;
  config: FurnitureConfig;
  modelParts: Part[];
  pieces: FabricationPiece[];
  materialGroups: FabricationMaterialGroup[];
  visiblePartCount: number;
  omittedPartCount: number;
  issues: ManufacturingIssue[];
  readyForManufacture: false;
  profileSupported: boolean;
}

const PANEL_KINDS = new Set<Part["kind"]>([
  "lateral",
  "tampo",
  "base",
  "fundo",
  "divisoria",
  "prateleira",
  "nicho",
  "porta",
  "gaveta",
  "painel",
]);
const NON_CARCASS_PROFILES = new Set([
  "mesa",
  "mesa-redonda",
  "mesa-oval",
  "mesa-organica",
  "mesa-jantar",
  "cadeira",
  "painel-tv",
  "banco",
  "banqueta",
  "aparador-organico",
]);

export const DEFAULT_FABRICATION_METADATA: FabricationMetadata = {
  projectName: "",
  projectCode: "",
  revision: "1",
  customerName: "",
  workshopName: "",
  recipient: "",
};

function groupFabricationPieces(pieces: FabricationPiece[]): FabricationMaterialGroup[] {
  const grouped = new Map<string, FabricationMaterialGroup>();
  for (const piece of pieces) {
    const key = `${piece.materialId}:${piece.thicknessCm.toFixed(3)}`;
    const group = grouped.get(key) ?? {
      materialId: piece.materialId,
      materialName: piece.materialName,
      finish: piece.finish,
      thicknessCm: piece.thicknessCm,
      pieceCount: 0,
      netAreaM2: 0,
    };
    group.pieceCount += piece.quantity;
    group.netAreaM2 += (piece.lengthCm * piece.widthCm * piece.quantity) / 10_000;
    grouped.set(key, group);
  }
  return [...grouped.values()].sort((a, b) =>
    `${a.materialName}:${a.thicknessCm}`.localeCompare(`${b.materialName}:${b.thicknessCm}`),
  );
}

export function edgeBandingLengthCm(pieces: FabricationPiece[]) {
  return pieces.reduce(
    (total, piece) =>
      total +
      (piece.edgeBanding ?? []).reduce(
        (sum, edge) => sum + (edge.startsWith("L") ? piece.lengthCm : piece.widthCm),
        0,
      ) *
        piece.quantity,
    0,
  );
}

export function applyFabricationPieceOverrides(
  document: FabricationDocument,
  overrides: FabricationPieceOverrides,
): FabricationDocument {
  const overrideIssues: ManufacturingIssue[] = [];
  let changedCount = 0;
  const pieces = document.pieces.map((piece) => {
    const override = overrides[piece.partId];
    if (!override || Object.keys(override).length === 0) return piece;
    const next = { ...piece };
    let changed = false;
    for (const field of ["lengthCm", "widthCm", "thicknessCm"] as const) {
      const value = override[field];
      if (value === undefined) continue;
      if (!Number.isFinite(value) || value <= 0 || value > 1000) {
        overrideIssues.push({
          id: `invalid-piece-override-${piece.partId}-${field}`,
          severity: "critical",
          title: `Medida inválida em ${piece.name}`,
          detail: `O campo ${field} precisa estar entre 0 e 1000 cm. A medida geométrica original foi mantida no pacote.`,
        });
        continue;
      }
      next[field] = value;
      changed = true;
    }
    if (override.materialId !== undefined) {
      const materialDef = MATERIALS.find((entry) => entry.id === override.materialId);
      if (!materialDef || materialDef.finish === "vidro" || materialDef.finish === "espelho") {
        overrideIssues.push({
          id: `invalid-piece-material-${piece.partId}`,
          severity: "critical",
          title: `Material de placa inválido em ${piece.name}`,
          detail:
            "Selecione um material de placa cadastrado; vidro e espelho exigem uma ficha de compra/processamento própria.",
        });
      } else {
        next.materialId = materialDef.id;
        next.materialName = materialDef.label;
        next.finish = materialDef.finish ?? "não especificado";
        changed = true;
      }
    }
    if (override.grainDirection !== undefined) {
      next.grainDirection = override.grainDirection;
      changed = true;
    }
    if (override.edgeBanding !== undefined) {
      next.edgeBanding = [...new Set(override.edgeBanding)];
      changed = true;
    }
    if (changed) {
      changedCount += 1;
      next.observation = `${piece.observation} Dados complementados/ajustados manualmente neste pacote; validar antes da produção.`;
    }
    return next;
  });

  const issues = document.issues.filter(
    (issue) => issue.id !== "edge-banding" && issue.id !== "grain-direction",
  );
  if (pieces.some((piece) => piece.edgeBanding === null))
    issues.push({
      id: "edge-banding",
      severity: "pending",
      title: "Fita de borda não definida para todas as peças",
      detail:
        "Marque L1/L2 (arestas longas) e C1/C2 (arestas curtas). Ainda há peças sem definição de fita.",
    });
  const bandedLength = edgeBandingLengthCm(pieces);
  if (bandedLength > 0)
    issues.push({
      id: "edge-tape-specification",
      severity: "pending",
      title: "Tipo/espessura da fita de borda pendentes",
      detail: `${(bandedLength / 100).toFixed(2)} m lineares geométricos estão selecionados. Confirme material, espessura, cor e perdas da fita; o MOVA não presume uma referência comercial.`,
    });
  if (pieces.some((piece) => piece.grainDirection === null))
    issues.push({
      id: "grain-direction",
      severity: "pending",
      title: "Orientação do veio não definida para todas as peças",
      detail:
        "Informe veio paralelo ao comprimento, à largura ou sem direção obrigatória para cada peça.",
    });
  if (changedCount > 0)
    issues.push({
      id: "manual-piece-overrides",
      severity: "pending",
      title: "Há dados de fabricação complementados manualmente",
      detail: `${changedCount} peça(s) receberam alterações/complementos neste pacote. Confira a origem dessas especificações; elas não alteram nem ficam salvas no modelo 3D original.`,
    });
  issues.push(...overrideIssues);
  const piecesByPartId = new Map(pieces.map((piece) => [piece.partId, piece]));
  const modelParts = document.modelParts.map((part) => {
    const piece = piecesByPartId.get(part.id);
    if (!piece) return part;
    const [lengthAxis, widthAxis] = faceAxes(part.kind);
    const thickness = thicknessAxis(part.kind);
    const size = [...part.size] as [number, number, number];
    size[lengthAxis] = piece.lengthCm;
    size[widthAxis] = piece.widthCm;
    size[thickness] = piece.thicknessCm;
    return { ...part, size };
  });
  return {
    ...document,
    modelParts,
    pieces,
    materialGroups: groupFabricationPieces(pieces),
    issues,
    readyForManufacture: false,
  };
}

function hasCabinetProfile(config: FurnitureConfig) {
  const baseType = typeDef(config.type).baseType ?? config.type;
  return !NON_CARCASS_PROFILES.has(baseType);
}

function thicknessAxis(kind: Part["kind"]): 0 | 1 | 2 {
  if (kind === "lateral" || kind === "divisoria") return 0;
  if (kind === "fundo" || kind === "porta" || kind === "gaveta" || kind === "painel") return 2;
  return 1;
}

function faceAxes(kind: Part["kind"]): [0 | 1 | 2, 0 | 1 | 2] {
  if (kind === "lateral" || kind === "divisoria") return [1, 2];
  if (kind === "fundo" || kind === "porta" || kind === "gaveta" || kind === "painel") return [0, 1];
  return [0, 2];
}

function finiteBox(part: Part) {
  return part.size.length === 3 && part.size.every((n) => Number.isFinite(n) && n > 0);
}

function isVisualOnlyPart(part: Part) {
  return (
    !PANEL_KINDS.has(part.kind) ||
    part.kind === "espelho" ||
    part.kind === "puxador" ||
    part.kind === "cabide" ||
    part.kind === "cabideiro" ||
    part.kind === "led" ||
    part.id.startsWith("acc-") ||
    part.id.startsWith("mod-") ||
    part.id.startsWith("espelho") ||
    part.id.startsWith("puxador") ||
    (part.geometry !== undefined && part.geometry !== "rounded")
  );
}

export function buildFabricationDocument(
  config: FurnitureConfig,
  metadata: Partial<FabricationMetadata> = {},
  parts: Part[] = buildFurniture(config),
  generatedAt = new Date().toISOString(),
): FabricationDocument {
  const profileSupported = hasCabinetProfile(config);
  const issues: ManufacturingIssue[] = [];
  const addIssue = (id: string, severity: ManufacturingSeverity, title: string, detail: string) =>
    issues.push({ id, severity, title, detail });
  const validDimensions = [config.width, config.height, config.depth].every(
    (value) => Number.isFinite(value) && value > 0,
  );
  if (!validDimensions)
    addIssue(
      "invalid-external-dimensions",
      "critical",
      "Dimensões externas inválidas",
      "Confira largura, altura e profundidade no configurador antes de exportar.",
    );
  else
    addIssue(
      "external-dimensions",
      "passed",
      "Dimensões externas lidas do configurador",
      `${config.width} × ${config.height} × ${config.depth} cm. São as dimensões nominais informadas pelo configurador.`,
    );

  const invalidModelParts = parts.filter(
    (part) => !finiteBox(part) || !part.pos.every((value) => Number.isFinite(value)),
  );
  if (invalidModelParts.length > 0)
    addIssue(
      "invalid-model-volumes",
      "critical",
      "Há volumes sem dimensões/posições finitas",
      `${invalidModelParts.length} componente(s) do modelo têm caixa ou posição inválida. Nenhuma lista baseada nesses volumes pode ser considerada completa.`,
    );
  else
    addIssue(
      "model-volume-dimensions",
      "passed",
      "Volumes do construtor têm dimensões e posições finitas",
      "Verificação numérica dos volumes 3D atuais; não verifica folgas, colisões de montagem ou tolerâncias de usinagem.",
    );

  if (validDimensions && invalidModelParts.length === 0 && parts.length > 0) {
    const envelopeParts = parts.filter((part) => !isVisualOnlyPart(part));
    const axes = [
      { name: "largura", axis: 0, min: -config.width / 2, max: config.width / 2 },
      { name: "altura", axis: 1, min: 0, max: config.height },
      { name: "profundidade", axis: 2, min: -config.depth / 2, max: config.depth / 2 },
    ] as const;
    const divergences = axes.flatMap(({ name, axis, min, max }) => {
      const modelMin = Math.min(
        ...envelopeParts.map((part) => part.pos[axis] - part.size[axis] / 2),
      );
      const modelMax = Math.max(
        ...envelopeParts.map((part) => part.pos[axis] + part.size[axis] / 2),
      );
      const under = Math.max(0, min - modelMin);
      const over = Math.max(0, modelMax - max);
      return under > 0.1 || over > 0.1
        ? [
            `${name}: envelope 3D de ${modelMin.toFixed(1)} a ${modelMax.toFixed(1)} cm; nominal de ${min.toFixed(1)} a ${max.toFixed(1)} cm`,
          ]
        : [];
    });
    if (divergences.length > 0)
      addIssue(
        "nominal-envelope-divergence",
        "warning",
        "Envelope do modelo difere das dimensões nominais",
        `Há painel(is) que ultrapassam as dimensões externas configuradas (tolerância de 0,1 cm): ${divergences.join("; ")}. Acessórios visuais sem regra de fabricação não entram nessa comparação. Revise no configurador antes de liberar a fabricação.`,
      );
    else
      addIssue(
        "nominal-envelope-match",
        "passed",
        "Envelope do modelo compatível com as dimensões nominais",
        "Os volumes ficam dentro das dimensões externas configuradas, com tolerância de 0,1 cm; essa verificação não certifica encaixes ou folgas.",
      );
  }

  const unknownModelMaterials = parts.filter(
    (part) => part.material && !MATERIALS.some((entry) => entry.id === part.material),
  );
  if (unknownModelMaterials.length > 0)
    addIssue(
      "unknown-model-materials",
      "critical",
      "Há componentes com material fora do catálogo",
      `${unknownModelMaterials.length} componente(s) usam material não cadastrado. Nenhum equivalente foi presumido.`,
    );

  if (!profileSupported) {
    addIssue(
      "unsupported-fabrication-profile",
      "critical",
      "Modelo sem perfil de fabricação",
      "Este tipo usa geometrias especiais (mesa, assento ou aparador orgânico). O MOVA ainda não guarda contornos, seções ou operações de fabricação suficientes para gerar uma lista de corte confiável.",
    );
  }

  const pieces: FabricationPiece[] = [];
  if (profileSupported) {
    for (const part of parts) {
      if (!PANEL_KINDS.has(part.kind) || isVisualOnlyPart(part)) continue;
      if (!finiteBox(part)) {
        addIssue(
          `invalid-part-${part.id}`,
          "critical",
          `Peça ${part.label} sem dimensões válidas`,
          "A geometria do componente não tem três dimensões positivas e finitas; ele foi excluído da lista.",
        );
        continue;
      }
      const materialId = part.material;
      const materialDef = materialId
        ? MATERIALS.find((entry) => entry.id === materialId)
        : undefined;
      if (!materialId || !materialDef) {
        addIssue(
          `unknown-material-${part.id}`,
          "critical",
          `Material não identificado: ${part.label}`,
          "O componente não contém um material reconhecido no catálogo; ele foi excluído da lista de peças para evitar uma substituição presumida.",
        );
        continue;
      }
      if (
        part.face === "vidro" ||
        part.face === "espelho" ||
        materialDef.finish === "vidro" ||
        materialDef.finish === "espelho"
      ) {
        addIssue(
          `surface-spec-${part.id}`,
          "pending",
          `Especificação de superfície pendente: ${part.label}`,
          `O modelo informa o material “${materialDef.label}”, mas não possui espessura de compra, processamento de borda ou fornecedor. A caixa geométrica não foi convertida em dimensão de fabricação.`,
        );
        continue;
      }
      const axis = thicknessAxis(part.kind);
      const [a, b] = faceAxes(part.kind);
      const lengthCm = part.size[a];
      const widthCm = part.size[b];
      const thicknessCm = part.size[axis];
      if (![lengthCm, widthCm, thicknessCm].every((n) => Number.isFinite(n) && n > 0)) {
        addIssue(
          `invalid-panel-${part.id}`,
          "critical",
          `Orientação da placa não resolvida: ${part.label}`,
          "O construtor não forneceu uma face e uma espessura positivas para esta placa.",
        );
        continue;
      }
      pieces.push({
        code: `P${String(pieces.length + 1).padStart(3, "0")}`,
        partId: part.id,
        name: part.label,
        kind: part.kind,
        quantity: 1,
        lengthCm,
        widthCm,
        thicknessCm,
        materialId,
        materialName: materialDef.label,
        finish: materialDef.finish ?? "não especificado",
        positionCm: [...part.pos],
        grainDirection: null,
        edgeBanding: null,
        observation:
          "Dimensões do volume retangular do construtor; não incluem folgas, usinagens, fita de borda ou compensações adicionais.",
      });
    }
  }

  if (profileSupported && pieces.length === 0)
    addIssue(
      "no-cuttable-parts",
      "critical",
      "Nenhum painel retangular reconhecido",
      "Não há componentes do móvel que o perfil atual possa decompor com segurança em placas retangulares.",
    );
  if (pieces.length > 0) {
    addIssue(
      "model-derived-panels",
      "passed",
      `${pieces.length} placas retangulares mapeadas do modelo`,
      "As dimensões listadas vêm de posições e tamanhos reais produzidos por buildFurniture(); representam os volumes retangulares atuais, não um plano de usinagem.",
    );
    addIssue(
      "edge-banding",
      "pending",
      "Fita de borda não definida por peça",
      "O configurador não armazena quais arestas recebem fita, tipo ou espessura. Nenhuma fita foi acrescentada à lista como se estivesse confirmada.",
    );
    addIssue(
      "grain-direction",
      "pending",
      "Orientação do veio não definida",
      "O catálogo informa acabamento visual, mas não a direção do veio exigida na fabricação. A orientação de cada peça permanece pendente.",
    );
  }

  const unmappedPanelShapes = parts.filter(
    (part) => PANEL_KINDS.has(part.kind) && isVisualOnlyPart(part),
  );
  if (unmappedPanelShapes.length > 0)
    addIssue(
      "unmapped-panel-shapes",
      "pending",
      "Volumes com forma especial não entram como placas retangulares",
      `${unmappedPanelShapes.length} componente(s) classificados como painel, mas com forma/geometria sem perfil de corte, ficaram fora da lista.`,
    );

  const drawerFronts = parts.filter((part) => part.kind === "gaveta").length;
  const doors = parts.filter((part) => part.kind === "porta").length;
  if (drawerFronts > 0)
    addIssue(
      "drawer-box-not-modeled",
      "critical",
      "Caixas de gaveta não representadas",
      `Há ${drawerFronts} frente(s) de gaveta no modelo, mas laterais, traseiro, fundo, folgas e corrediças da caixa não são peças do construtor. A lista não representa o conjunto completo de gavetas.`,
    );
  if (doors > 0)
    addIssue(
      "door-hardware",
      "pending",
      "Ferragens das portas sem especificação de fabricação",
      `O modelo contém ${doors} folha(s) de porta, mas não especifica dobradiças, quantidade por folha, calços, trilhos ou parâmetros de furação. Nenhuma quantidade de ferragens foi inferida.`,
    );
  const handles = parts.filter((part) => part.kind === "puxador").length;
  if (handles > 0)
    addIssue(
      "handle-fixings",
      "pending",
      "Fixação dos puxadores pendente",
      `O modelo visual contém ${handles} puxador(es); parafusos, furação e código comercial não estão cadastrados.`,
    );

  const excluded = parts.filter((part) => !pieces.some((piece) => piece.partId === part.id));
  const unsupportedExtras = excluded.filter(
    (part) =>
      part.kind === "acessorio" ||
      part.kind === "cabideiro" ||
      part.kind === "cabide" ||
      part.kind === "espelho" ||
      part.kind === "led" ||
      part.id.startsWith("mod-") ||
      part.id.startsWith("acc-"),
  );
  if (unsupportedExtras.length > 0)
    addIssue(
      "visual-extras-omitted",
      "pending",
      "Componentes visuais fora da lista de placas",
      `${unsupportedExtras.length} componente(s) visual(is), acessório(s), espelho(s), LED(s) ou módulo(s) não possuem regra de fabricação específica e não foram convertidos em placas. Consulte o modelo antes de produzir.`,
    );
  if (config.componentInstances?.length)
    addIssue(
      "custom-components",
      "pending",
      "Componentes modulares precisam de validação manual",
      "O projeto contém componentes adicionados. Eles permanecem visíveis nos desenhos de envelope, mas não entram automaticamente na lista de placas.",
    );
  if (config.accessories?.length)
    addIssue(
      "accessory-specification",
      "pending",
      "Acessórios sem ficha de fabricação",
      "Um ou mais acessórios estão selecionados; o catálogo visual não contém ficha de corte, furação ou ferragens desses itens.",
    );
  if ((config.roomItems?.length ?? 0) > 0)
    addIssue(
      "room-items-excluded",
      "warning",
      "Exportação limitada ao móvel ativo",
      `${config.roomItems!.length} outro(s) móvel(is) do cômodo não são incluídos neste documento; exporte cada configuração separadamente.`,
    );
  addIssue(
    "shop-parameters",
    "pending",
    "Parâmetros da marcenaria necessários",
    "O configurador não mantém parâmetros de chapas, veio, folgas, refilos ou usinagens como dados verificados do projeto. O módulo permite inserir dimensões de chapa, serra e margem para uma heurística local, mas esses parâmetros do pacote ainda precisam ser confirmados pela marcenaria.",
  );
  addIssue(
    "assembly-and-joinery-review",
    "pending",
    "Encaixes e montagem requerem revisão técnica",
    "O modelo não descreve cavilhas, parafusos, rasgos, furos, folgas, ferragens completas ou uma árvore/sequência de montagem. A vista explodida é apenas esquemática e não substitui um desenho de montagem.",
  );
  addIssue(
    "collision-clearance-analysis",
    "pending",
    "Colisões e folgas não foram certificadas",
    "O MOVA fornece volumes de visualização, mas não classifica contatos intencionais, encaixes e zonas de montagem. Uma detecção genérica geraria falsos positivos; revise interferências e folgas no CAD de produção.",
  );
  addIssue(
    "revision-history",
    "pending",
    "Revisão informada somente neste pacote",
    "O armazenamento atual não mantém histórico/versionamento de revisões. O código e a revisão preenchidos identificam esta exportação, não um histórico imutável do projeto salvo.",
  );
  addIssue(
    "preliminary-document",
    "warning",
    "Documento preliminar, não liberado para produção",
    "O motor atual é um configurador visual paramétrico, não um CAD/CAM de marcenaria. Confirme lista, encaixes, bordas, folgas e ferragens com um responsável técnico antes de cortar material.",
  );

  const mergedMetadata = { ...DEFAULT_FABRICATION_METADATA, ...metadata };
  return {
    schemaVersion: 1,
    generatedAt,
    metadata: mergedMetadata,
    config,
    modelParts: parts.map((part) => ({
      ...part,
      pos: [...part.pos] as [number, number, number],
      size: [...part.size] as [number, number, number],
    })),
    pieces,
    materialGroups: groupFabricationPieces(pieces),
    visiblePartCount: parts.length,
    omittedPartCount: Math.max(0, parts.length - pieces.length),
    issues,
    readyForManufacture: false,
    profileSupported,
  };
}

export function validationCounts(issues: ManufacturingIssue[]) {
  return {
    critical: issues.filter((issue) => issue.severity === "critical").length,
    pending: issues.filter((issue) => issue.severity === "pending").length,
    warning: issues.filter((issue) => issue.severity === "warning").length,
    passed: issues.filter((issue) => issue.severity === "passed").length,
  };
}

function csvCell(value: string | number | null | undefined) {
  const text = value == null ? "" : String(value);
  return `"${text.replaceAll('"', '""')}"`;
}

export function fabricationPiecesCsv(document: FabricationDocument) {
  const header = [
    "Código",
    "ID do componente MOVA",
    "Descrição",
    "Quantidade",
    "Comprimento (cm)",
    "Largura (cm)",
    "Espessura (cm)",
    "Material",
    "Acabamento",
    "Veio",
    "Fita de borda",
    "Posição X (cm)",
    "Posição Y (cm)",
    "Posição Z (cm)",
    "Observações",
    "Projeto",
    "Código do projeto",
    "Revisão",
    "Data de geração (ISO)",
  ];
  const rows = document.pieces.map((piece) => [
    piece.code,
    piece.partId,
    piece.name,
    piece.quantity,
    piece.lengthCm,
    piece.widthCm,
    piece.thicknessCm,
    piece.materialName,
    piece.finish,
    piece.grainDirection === "length"
      ? "Paralelo ao comprimento"
      : piece.grainDirection === "width"
        ? "Paralelo à largura"
        : piece.grainDirection === "none"
          ? "Sem veio obrigatório"
          : "Pendente",
    piece.edgeBanding === null
      ? "Pendente"
      : piece.edgeBanding.length > 0
        ? piece.edgeBanding.join(", ")
        : "Nenhuma",
    ...piece.positionCm,
    piece.observation,
    document.metadata.projectName,
    document.metadata.projectCode,
    document.metadata.revision,
    document.generatedAt,
  ]);
  return `\uFEFF${[header, ...rows].map((row) => row.map(csvCell).join(";")).join("\r\n")}\r\n`;
}

export type DrawingView = "front" | "side" | "top" | "exploded";
const VIEW_TITLES: Record<DrawingView, string> = {
  front: "Vista frontal",
  side: "Vista lateral",
  top: "Vista superior",
  exploded: "Vista explodida esquemática",
};
const escapeXml = (text: string) =>
  text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");

export function fabricationDrawingSvg(document: FabricationDocument, view: DrawingView) {
  const width = 1000;
  const height = 640;
  const margin = 100;
  const axes: Record<Exclude<DrawingView, "exploded">, [0 | 1 | 2, 0 | 1 | 2]> = {
    front: [0, 1],
    side: [2, 1],
    top: [0, 2],
  };
  const [horizontal, vertical] = view === "exploded" ? axes.front : axes[view];
  const parts = document.modelParts;
  const bounds = parts.filter(finiteBox).map((part) => ({
    minX: part.pos[horizontal] - part.size[horizontal] / 2,
    maxX: part.pos[horizontal] + part.size[horizontal] / 2,
    minY: part.pos[vertical] - part.size[vertical] / 2,
    maxY: part.pos[vertical] + part.size[vertical] / 2,
  }));
  const nominalWidth = horizontal === 0 ? document.config.width : document.config.depth;
  const modelMinX = Math.min(-nominalWidth / 2, ...bounds.map((box) => box.minX));
  const modelMaxX = Math.max(nominalWidth / 2, ...bounds.map((box) => box.maxX));
  const nominalY =
    view === "side" || view === "front" || view === "exploded"
      ? document.config.height
      : document.config.depth;
  const modelMinY =
    view === "top"
      ? Math.min(-nominalY / 2, ...bounds.map((box) => box.minY))
      : Math.min(0, ...bounds.map((box) => box.minY));
  const modelMaxY =
    view === "top"
      ? Math.max(nominalY / 2, ...bounds.map((box) => box.maxY))
      : Math.max(nominalY, ...bounds.map((box) => box.maxY));
  const rangeX = Math.max(1, modelMaxX - modelMinX);
  const rangeY = Math.max(1, modelMaxY - modelMinY);
  const scale = Math.min((width - margin * 2) / rangeX, (height - margin * 2) / rangeY);
  const left = (width - rangeX * scale) / 2;
  const top = (height - rangeY * scale) / 2 + 20;
  const pieceById = new Map(document.pieces.map((piece) => [piece.partId, piece]));
  const shapes = parts
    .filter(finiteBox)
    .map((part) => {
      const xWorld = part.pos[horizontal] - part.size[horizontal] / 2;
      const yWorld = part.pos[vertical] - part.size[vertical] / 2;
      const w = Math.max(1, part.size[horizontal] * scale);
      const h = Math.max(1, part.size[vertical] * scale);
      const isPiece = pieceById.has(part.id);
      const explodeX =
        view === "exploded" ? (part.pos[0] / Math.max(document.config.width, 1)) * 36 : 0;
      const explodeY =
        view === "exploded"
          ? ((part.pos[1] - document.config.height / 2) / Math.max(document.config.height, 1)) * 44
          : 0;
      const x = left + (xWorld - modelMinX) * scale + explodeX;
      const y = top + (modelMaxY - yWorld - part.size[vertical]) * scale - explodeY;
      const code = pieceById.get(part.id)?.code ?? part.id;
      const fontSize = Math.max(9, Math.min(16, Math.min(w, h) * 0.16));
      const line = isPiece ? "#332820" : "#b66a25";
      const dash = isPiece ? "" : ' stroke-dasharray="7 5"';
      const label =
        w > 30 && h > 18
          ? `<text x="${x + w / 2}" y="${y + h / 2 + fontSize / 3}" text-anchor="middle" font-size="${fontSize}" fill="${line}">${escapeXml(code)}</text>`
          : "";
      const connector =
        view === "exploded" && (explodeX !== 0 || explodeY !== 0)
          ? `<line x1="${x - explodeX}" y1="${y + explodeY}" x2="${x + w / 2}" y2="${y + h / 2}" stroke="#b9afa4" stroke-width="1" stroke-dasharray="4 4"/>`
          : "";
      return `${connector}<rect data-part="${escapeXml(part.id)}" x="${x}" y="${y}" width="${w}" height="${h}" fill="${isPiece ? "#f4eee5" : "#fff7ec"}" fill-opacity="0.7" stroke="${line}" stroke-width="${isPiece ? 2 : 1.3}"${dash}/>${label}`;
    })
    .join("");
  const nominalHeight = view === "top" ? document.config.depth : document.config.height;
  const subtitle =
    "Envelope dos volumes do modelador · cotas nominais em cm · representação ajustada, não usar como desenho de usinagem";
  const projectInfo = [
    document.metadata.projectName || typeDef(document.config.type).label,
    document.metadata.projectCode || "Sem código",
    `Rev. ${document.metadata.revision || "—"}`,
    new Date(document.generatedAt).toLocaleDateString("pt-BR"),
  ]
    .join(" · ")
    .replace(/\s+/g, " ")
    .trim();
  const dimensionsLabel =
    view === "side"
      ? `L ${document.config.depth} cm · A ${document.config.height} cm`
      : view === "top"
        ? `L ${document.config.width} cm · P ${document.config.depth} cm`
        : `L ${document.config.width} cm · A ${document.config.height} cm · P ${document.config.depth} cm`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeXml(VIEW_TITLES[view])}"><rect width="100%" height="100%" fill="#fffdf9"/><text x="40" y="48" font-family="Arial,sans-serif" font-size="28" font-weight="700" fill="#48382e">${escapeXml(VIEW_TITLES[view])}</text><text x="40" y="75" font-family="Arial,sans-serif" font-size="13" fill="#6e6257">${escapeXml(projectInfo)}</text><text x="40" y="96" font-family="Arial,sans-serif" font-size="11" fill="#8a7868">${escapeXml(subtitle)}</text><g stroke-linecap="round" stroke-linejoin="round">${shapes}</g><text x="40" y="${height - 48}" font-family="Arial,sans-serif" font-size="18" fill="#48382e">${dimensionsLabel}</text><text x="40" y="${height - 24}" font-family="Arial,sans-serif" font-size="12" fill="#8a7868">Contorno tracejado: componente visível sem regra de fabricação mapeada. ${view === "exploded" ? "Esquemático; não indica furos, ferragens ou sequência de montagem." : ""}</text></svg>`;
}

export interface CutPlanParameters {
  sheetWidthCm: number;
  sheetHeightCm: number;
  kerfCm: number;
  marginCm: number;
  allowRotation: boolean;
}
export interface CutPlacement {
  code: string;
  xCm: number;
  yCm: number;
  widthCm: number;
  heightCm: number;
  rotated: boolean;
}
export interface CutSheet {
  number: number;
  placements: CutPlacement[];
}
export interface CutPlanResult {
  sheets: CutSheet[];
  unplaced: { code: string; reason: string }[];
  netAreaM2: number;
  unplacedAreaM2: number;
  grossAreaM2: number;
  wastePercent: number | null;
  input: CutPlanParameters;
  method: "first-fit-decreasing-shelf-heuristic";
  disclaimer: string;
}

interface SheetWorking extends CutSheet {
  rows: { y: number; height: number; usedWidth: number }[];
  nextY: number;
}

export function calculatePanelCutPlan(
  pieces: FabricationPiece[],
  input: CutPlanParameters,
): CutPlanResult {
  const valid =
    [input.sheetWidthCm, input.sheetHeightCm].every((n) => Number.isFinite(n) && n > 0) &&
    Number.isFinite(input.kerfCm) &&
    input.kerfCm >= 0 &&
    Number.isFinite(input.marginCm) &&
    input.marginCm >= 0 &&
    input.sheetWidthCm > 2 * input.marginCm &&
    input.sheetHeightCm > 2 * input.marginCm;
  if (!valid) throw new Error("Informe dimensões comerciais, margem e espessura de corte válidas.");

  const usableW = input.sheetWidthCm - 2 * input.marginCm;
  const usableH = input.sheetHeightCm - 2 * input.marginCm;
  const workSheets: SheetWorking[] = [];
  const unplaced: CutPlanResult["unplaced"] = [];
  const sorted = [...pieces].sort(
    (a, b) => b.lengthCm * b.widthCm - a.lengthCm * a.widthCm || b.lengthCm - a.lengthCm,
  );

  const tryPlace = (
    sheet: SheetWorking,
    piece: FabricationPiece,
    allowPieceRotation: boolean,
  ): CutPlacement | null => {
    const orientations = allowPieceRotation
      ? [
          { width: piece.lengthCm, height: piece.widthCm, rotated: false },
          { width: piece.widthCm, height: piece.lengthCm, rotated: true },
        ]
      : [{ width: piece.lengthCm, height: piece.widthCm, rotated: false }];
    for (const orientation of orientations) {
      if (orientation.width > usableW || orientation.height > usableH) continue;
      for (const row of sheet.rows) {
        const gap = row.usedWidth > 0 ? input.kerfCm : 0;
        if (
          orientation.height <= row.height &&
          row.usedWidth + gap + orientation.width <= usableW
        ) {
          const x = input.marginCm + row.usedWidth + gap;
          row.usedWidth += gap + orientation.width;
          return {
            code: piece.code,
            xCm: x,
            yCm: input.marginCm + row.y,
            widthCm: orientation.width,
            heightCm: orientation.height,
            rotated: orientation.rotated,
          };
        }
      }
      const gapY = sheet.rows.length > 0 ? input.kerfCm : 0;
      if (sheet.nextY + gapY + orientation.height <= usableH) {
        const y = sheet.nextY + gapY;
        sheet.rows.push({ y, height: orientation.height, usedWidth: orientation.width });
        sheet.nextY = y + orientation.height;
        return {
          code: piece.code,
          xCm: input.marginCm,
          yCm: input.marginCm + y,
          widthCm: orientation.width,
          heightCm: orientation.height,
          rotated: orientation.rotated,
        };
      }
    }
    return null;
  };

  for (const piece of sorted) {
    if (
      !Number.isFinite(piece.lengthCm) ||
      !Number.isFinite(piece.widthCm) ||
      piece.lengthCm <= 0 ||
      piece.widthCm <= 0
    ) {
      unplaced.push({ code: piece.code, reason: "Dimensões da peça inválidas." });
      continue;
    }
    const allowPieceRotation = input.allowRotation && piece.grainDirection === "none";
    let placement: CutPlacement | null = null;
    let sheetIndex = -1;
    for (let i = 0; i < workSheets.length && !placement; i++) {
      placement = tryPlace(workSheets[i]!, piece, allowPieceRotation);
      if (placement) sheetIndex = i;
    }
    if (!placement) {
      const fresh: SheetWorking = {
        number: workSheets.length + 1,
        placements: [],
        rows: [],
        nextY: 0,
      };
      placement = tryPlace(fresh, piece, allowPieceRotation);
      if (!placement) {
        unplaced.push({
          code: piece.code,
          reason: `A peça ${piece.lengthCm} × ${piece.widthCm} cm não cabe na área útil ${usableW} × ${usableH} cm${allowPieceRotation ? " mesmo com rotação" : " sem rotação (veio pendente/direcional ou rotação desativada)"}.`,
        });
        continue;
      }
      workSheets.push(fresh);
      sheetIndex = workSheets.length - 1;
    }
    workSheets[sheetIndex]!.placements.push(placement);
  }

  const placedCodes = new Set(
    workSheets.flatMap((sheet) => sheet.placements.map((placement) => placement.code)),
  );
  const netAreaM2 = pieces
    .filter((piece) => placedCodes.has(piece.code))
    .reduce((sum, piece) => sum + (piece.lengthCm * piece.widthCm) / 10_000, 0);
  const unplacedAreaM2 = pieces
    .filter((piece) => !placedCodes.has(piece.code))
    .reduce((sum, piece) => sum + (piece.lengthCm * piece.widthCm) / 10_000, 0);
  const grossAreaM2 = (workSheets.length * input.sheetWidthCm * input.sheetHeightCm) / 10_000;
  const wastePercent = grossAreaM2 > 0 ? Math.max(0, (1 - netAreaM2 / grossAreaM2) * 100) : null;
  return {
    sheets: workSheets.map(({ number, placements }) => ({ number, placements })),
    unplaced,
    netAreaM2,
    unplacedAreaM2,
    grossAreaM2,
    wastePercent,
    input,
    method: "first-fit-decreasing-shelf-heuristic",
    disclaimer:
      "Proposta heurística bidimensional para estudo. Só gira peças marcadas sem veio obrigatório e com rotação autorizada. Não é otimização, plano de serra/CNC, sequência de corte nem validação de veio, esquadro, refilo, defeitos ou máquina. Confirme os parâmetros e a distribuição com a marcenaria.",
  };
}

export function cutPlanSvg(
  result: CutPlanResult,
  pieceLookup: Map<string, FabricationPiece>,
  sheetIndex: number,
  metadata?: FabricationMetadata,
  generatedAt?: string,
) {
  const sheet = result.sheets[sheetIndex];
  if (!sheet) return "";
  const width = 1000;
  const height = 640;
  const padding = 80;
  const scale = Math.min(
    (width - padding * 2) / result.input.sheetWidthCm,
    (height - padding * 2) / result.input.sheetHeightCm,
  );
  const x0 = (width - result.input.sheetWidthCm * scale) / 2;
  const y0 = Math.max(105, (height - result.input.sheetHeightCm * scale) / 2);
  const projectInfo = metadata
    ? [
        metadata.projectName || "Projeto MOVA",
        metadata.projectCode || "Sem código",
        `Rev. ${metadata.revision || "—"}`,
        new Date(generatedAt ?? new Date().toISOString()).toLocaleDateString("pt-BR"),
      ]
        .join(" · ")
        .replace(/\s+/g, " ")
        .trim()
    : "";
  const rectangles = sheet.placements
    .map((placement) => {
      const x = x0 + placement.xCm * scale;
      const y = height - (y0 + (placement.yCm + placement.heightCm) * scale);
      const w = placement.widthCm * scale;
      const h = placement.heightCm * scale;
      const label = `${placement.code}${placement.rotated ? " ↻" : ""}`;
      const name = pieceLookup.get(placement.code)?.name ?? placement.code;
      return `<g><title>${escapeXml(name)} · ${escapeXml(label)}</title><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#efe4d6" stroke="#48382e" stroke-width="2"/><text x="${x + w / 2}" y="${y + h / 2}" text-anchor="middle" dominant-baseline="middle" font-family="Arial,sans-serif" font-size="14" fill="#332820">${escapeXml(label)}</text></g>`;
    })
    .join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Distribuição heurística da chapa ${sheet.number}"><rect width="100%" height="100%" fill="#fffdf9"/><text x="40" y="42" font-family="Arial,sans-serif" font-size="24" font-weight="700" fill="#48382e">Chapa ${sheet.number} · proposta heurística</text><text x="40" y="66" font-family="Arial,sans-serif" font-size="12" fill="#6e6257">${escapeXml(projectInfo)}</text><text x="40" y="86" font-family="Arial,sans-serif" font-size="12" fill="#6e6257">${result.input.sheetWidthCm} × ${result.input.sheetHeightCm} cm · margem ${result.input.marginCm} cm · serra ${result.input.kerfCm} cm</text><rect x="${x0}" y="${y0}" width="${result.input.sheetWidthCm * scale}" height="${result.input.sheetHeightCm * scale}" fill="#fff" stroke="#48382e" stroke-width="4"/>${rectangles}<text x="40" y="${height - 20}" font-family="Arial,sans-serif" font-size="12" fill="#8a7868">Não otimizado nem validado para máquina; confira orientação do veio e parâmetros.</text></svg>`;
}

export interface ZipEntry {
  name: string;
  data: Uint8Array;
}

function crc32(bytes: Uint8Array) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function u16(view: DataView, offset: number, value: number) {
  view.setUint16(offset, value, true);
}
function u32(view: DataView, offset: number, value: number) {
  view.setUint32(offset, value >>> 0, true);
}

/** Minimal ZIP writer using stored (uncompressed) entries and UTF-8 names. */
export function createZipBytes(entries: ZipEntry[]) {
  const encoder = new TextEncoder();
  const localChunks: Uint8Array[] = [];
  const directoryChunks: Uint8Array[] = [];
  let offset = 0;
  const now = new Date();
  const dosTime =
    (now.getHours() << 11) | (now.getMinutes() << 5) | Math.floor(now.getSeconds() / 2);
  const dosDate =
    ((Math.max(1980, now.getFullYear()) - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();

  for (const entry of entries) {
    const name = encoder.encode(entry.name.replace(/^\/+/, ""));
    const data = entry.data;
    const crc = crc32(data);
    const local = new Uint8Array(30 + name.length + data.length);
    const localView = new DataView(local.buffer);
    u32(localView, 0, 0x04034b50);
    u16(localView, 4, 20);
    u16(localView, 6, 0x0800);
    u16(localView, 8, 0);
    u16(localView, 10, dosTime);
    u16(localView, 12, dosDate);
    u32(localView, 14, crc);
    u32(localView, 18, data.length);
    u32(localView, 22, data.length);
    u16(localView, 26, name.length);
    u16(localView, 28, 0);
    local.set(name, 30);
    local.set(data, 30 + name.length);
    localChunks.push(local);

    const directory = new Uint8Array(46 + name.length);
    const directoryView = new DataView(directory.buffer);
    u32(directoryView, 0, 0x02014b50);
    u16(directoryView, 4, 20);
    u16(directoryView, 6, 20);
    u16(directoryView, 8, 0x0800);
    u16(directoryView, 10, 0);
    u16(directoryView, 12, dosTime);
    u16(directoryView, 14, dosDate);
    u32(directoryView, 16, crc);
    u32(directoryView, 20, data.length);
    u32(directoryView, 24, data.length);
    u16(directoryView, 28, name.length);
    u16(directoryView, 30, 0);
    u16(directoryView, 32, 0);
    u16(directoryView, 34, 0);
    u16(directoryView, 36, 0);
    u32(directoryView, 38, 0);
    u32(directoryView, 42, offset);
    directory.set(name, 46);
    directoryChunks.push(directory);
    offset += local.length;
  }

  const directoryBytes = directoryChunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);
  u32(endView, 0, 0x06054b50);
  u16(endView, 4, 0);
  u16(endView, 6, 0);
  u16(endView, 8, entries.length);
  u16(endView, 10, entries.length);
  u32(endView, 12, directoryBytes);
  u32(endView, 16, offset);
  u16(endView, 20, 0);
  const output = new Uint8Array(offset + directoryBytes + end.length);
  let cursor = 0;
  for (const chunk of [...localChunks, ...directoryChunks, end]) {
    output.set(chunk, cursor);
    cursor += chunk.length;
  }
  return output;
}

export function textBytes(value: string) {
  return new TextEncoder().encode(value);
}

export function materialDisplay(materialId: string) {
  return material(materialId);
}

export function modularComponentLabel(type: string) {
  return componentDef(type)?.label ?? type;
}

export function nominalMaterial(config: FurnitureConfig) {
  return ["estrutura", "portas", "interior", "fundo"]
    .map((key) => {
      const id = config.materials?.[key as keyof FurnitureConfig["materials"]];
      return id ? `${key}: ${materialDisplay(id).label}` : "";
    })
    .filter(Boolean);
}

export function manufacturingSummary(document: FabricationDocument) {
  const counts = validationCounts(document.issues);
  const lines = [
    `Projeto: ${document.metadata.projectName || typeDef(document.config.type).label}`,
    `Código: ${document.metadata.projectCode || "não informado"} · Revisão: ${document.metadata.revision || "não informada"}`,
    `Cliente: ${document.metadata.customerName || "não informado"}`,
    `Marcenaria: ${document.metadata.workshopName || "não informada"}`,
    `Destinatário pretendido: ${document.metadata.recipient || "não informado"}`,
    `Dimensões nominais: ${document.config.width} × ${document.config.height} × ${document.config.depth} cm`,
    `Placas mapeadas do modelo: ${document.pieces.length} · Itens visuais omitidos: ${document.omittedPartCount}`,
    `Validação: ${counts.critical} crítico(s), ${counts.pending} pendência(s), ${counts.warning} aviso(s). Documento não liberado para produção.`,
    `Gerado em: ${new Date(document.generatedAt).toLocaleString("pt-BR")}`,
  ];
  return lines.join("\n");
}
