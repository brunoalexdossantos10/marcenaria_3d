import {
  type CutPlanResult,
  type DrawingView,
  type FabricationDocument,
  validationCounts,
} from "./manufacturing";
import { typeDef } from "./types";
import type { jsPDF } from "jspdf";

const PAGE_MARGIN = 18;
const PAGE_W = 210;
const PAGE_H = 297;

function safeText(value: string | number | undefined | null) {
  return value == null || value === "" ? "—" : String(value).replace(/\s+/g, " ").trim();
}

function textLines(
  pdf: jsPDF,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight = 5,
) {
  const lines = pdf.splitTextToSize(text, maxWidth) as string[];
  pdf.text(lines, x, y);
  return y + lines.length * lineHeight;
}

function pageHeading(pdf: jsPDF, title: string, document: FabricationDocument) {
  pdf.setTextColor(55, 43, 34);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(19);
  pdf.text(title, PAGE_MARGIN, 24);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(110, 95, 82);
  pdf.text(
    `${safeText(document.metadata.projectCode)} · Rev. ${safeText(document.metadata.revision)} · ${new Date(document.generatedAt).toLocaleDateString("pt-BR")}`,
    PAGE_MARGIN,
    31,
  );
  pdf.setDrawColor(177, 162, 147);
  pdf.line(PAGE_MARGIN, 36, PAGE_W - PAGE_MARGIN, 36);
}

function projectionAxes(view: Exclude<DrawingView, "exploded">): [0 | 1 | 2, 0 | 1 | 2] {
  if (view === "front") return [0, 1];
  if (view === "side") return [2, 1];
  return [0, 2];
}

function drawProjection(
  pdf: jsPDF,
  document: FabricationDocument,
  view: Exclude<DrawingView, "exploded">,
) {
  const allParts = document.modelParts.filter((part) =>
    part.size.every((value) => Number.isFinite(value) && value > 0),
  );
  const [horizontal, vertical] = projectionAxes(view);
  const nominalWidth = horizontal === 0 ? document.config.width : document.config.depth;
  const minX = Math.min(
    -nominalWidth / 2,
    ...allParts.map((part) => part.pos[horizontal] - part.size[horizontal] / 2),
  );
  const maxX = Math.max(
    nominalWidth / 2,
    ...allParts.map((part) => part.pos[horizontal] + part.size[horizontal] / 2),
  );
  const nominalY = view === "top" ? document.config.depth : document.config.height;
  const minY =
    view === "top"
      ? Math.min(
          -nominalY / 2,
          ...allParts.map((part) => part.pos[vertical] - part.size[vertical] / 2),
        )
      : Math.min(0, ...allParts.map((part) => part.pos[vertical] - part.size[vertical] / 2));
  const maxY =
    view === "top"
      ? Math.max(
          nominalY / 2,
          ...allParts.map((part) => part.pos[vertical] + part.size[vertical] / 2),
        )
      : Math.max(nominalY, ...allParts.map((part) => part.pos[vertical] + part.size[vertical] / 2));
  const rangeX = Math.max(1, maxX - minX);
  const rangeY = Math.max(1, maxY - minY);
  const x = 22;
  const y = 52;
  const availableW = PAGE_W - 44;
  const availableH = 186;
  const scale = Math.min(availableW / rangeX, availableH / rangeY);
  const drawnW = rangeX * scale;
  const drawnH = rangeY * scale;
  const left = x + (availableW - drawnW) / 2;
  const top = y + (availableH - drawnH) / 2;
  const nominalMinX = -nominalWidth / 2;
  const nominalMaxX = nominalWidth / 2;
  const nominalMinY = view === "top" ? -nominalY / 2 : 0;
  const nominalMaxY = view === "top" ? nominalY / 2 : nominalY;
  const nominalLeft = left + (nominalMinX - minX) * scale;
  const nominalRight = left + (nominalMaxX - minX) * scale;
  const nominalTop = top + (maxY - nominalMaxY) * scale;
  const nominalBottom = top + (maxY - nominalMinY) * scale;
  const pieces = new Map(document.pieces.map((piece) => [piece.partId, piece]));

  for (const part of allParts) {
    const worldX = part.pos[horizontal] - part.size[horizontal] / 2;
    const worldY = part.pos[vertical] - part.size[vertical] / 2;
    const rectX = left + (worldX - minX) * scale;
    const rectY = top + (maxY - worldY - part.size[vertical]) * scale;
    const rectW = Math.max(0.5, part.size[horizontal] * scale);
    const rectH = Math.max(0.5, part.size[vertical] * scale);
    const isPiece = pieces.has(part.id);
    if (isPiece) {
      pdf.setDrawColor(65, 50, 39);
      pdf.setFillColor(245, 239, 230);
      pdf.setLineWidth(0.35);
    } else {
      pdf.setDrawColor(190, 111, 38);
      pdf.setFillColor(255, 249, 239);
      pdf.setLineWidth(0.25);
      pdf.setLineDashPattern([1.2, 1], 0);
    }
    pdf.rect(rectX, rectY, rectW, rectH, "FD");
    pdf.setLineDashPattern([], 0);
    const code = pieces.get(part.id)?.code;
    if (code && rectW > 13 && rectH > 7) {
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(Math.min(7, Math.max(4, Math.min(rectW, rectH) * 0.3)));
      pdf.setTextColor(65, 50, 39);
      pdf.text(code, rectX + rectW / 2, rectY + rectH / 2 + 1, { align: "center" });
    }
  }

  const horizontalDimensionY = nominalBottom + 5;
  const verticalDimensionX = nominalRight + 6;
  pdf.setDrawColor(125, 105, 88);
  pdf.setTextColor(91, 77, 64);
  pdf.setLineWidth(0.18);
  pdf.line(nominalLeft, nominalBottom, nominalLeft, horizontalDimensionY);
  pdf.line(nominalRight, nominalBottom, nominalRight, horizontalDimensionY);
  pdf.line(nominalLeft, horizontalDimensionY, nominalRight, horizontalDimensionY);
  pdf.line(nominalLeft, horizontalDimensionY, nominalLeft + 1.4, horizontalDimensionY - 0.8);
  pdf.line(nominalLeft, horizontalDimensionY, nominalLeft + 1.4, horizontalDimensionY + 0.8);
  pdf.line(nominalRight, horizontalDimensionY, nominalRight - 1.4, horizontalDimensionY - 0.8);
  pdf.line(nominalRight, horizontalDimensionY, nominalRight - 1.4, horizontalDimensionY + 0.8);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(6.5);
  pdf.text(
    `${nominalWidth.toFixed(1)} cm`,
    nominalLeft + (nominalRight - nominalLeft) / 2,
    horizontalDimensionY - 1.2,
    {
      align: "center",
    },
  );
  pdf.line(nominalRight, nominalTop, verticalDimensionX, nominalTop);
  pdf.line(nominalRight, nominalBottom, verticalDimensionX, nominalBottom);
  pdf.line(verticalDimensionX, nominalTop, verticalDimensionX, nominalBottom);
  pdf.line(verticalDimensionX, nominalTop, verticalDimensionX - 0.8, nominalTop + 1.4);
  pdf.line(verticalDimensionX, nominalTop, verticalDimensionX + 0.8, nominalTop + 1.4);
  pdf.line(verticalDimensionX, nominalBottom, verticalDimensionX - 0.8, nominalBottom - 1.4);
  pdf.line(verticalDimensionX, nominalBottom, verticalDimensionX + 0.8, nominalBottom - 1.4);
  pdf.text(
    `${nominalY.toFixed(1)} cm`,
    verticalDimensionX + 2,
    nominalTop + (nominalBottom - nominalTop) / 2,
    {
      angle: 90,
      align: "center",
    },
  );

  const label =
    view === "front" ? "Vista frontal" : view === "side" ? "Vista lateral" : "Vista superior";
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(11);
  pdf.setTextColor(55, 43, 34);
  pdf.text(label, PAGE_MARGIN, 45);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(91, 77, 64);
  const nominalHeight = view === "top" ? document.config.depth : document.config.height;
  const dimensionsLabel =
    view === "side"
      ? `L ${document.config.depth} cm · A ${document.config.height} cm`
      : view === "top"
        ? `L ${document.config.width} cm · P ${document.config.depth} cm`
        : `L ${document.config.width} cm · A ${document.config.height} cm · P ${document.config.depth} cm`;
  pdf.text(dimensionsLabel, PAGE_MARGIN, 257);
  const denominator = Math.max(1, Math.round(10 / scale));
  pdf.text(
    `Escala gráfica ajustada aproximadamente 1:${denominator}; cotas em centímetros.`,
    PAGE_MARGIN,
    263,
  );
  pdf.setDrawColor(85, 70, 56);
  pdf.line(PAGE_MARGIN, 270, PAGE_MARGIN + scale * 10, 270);
  pdf.line(PAGE_MARGIN, 267, PAGE_MARGIN, 273);
  pdf.line(PAGE_MARGIN + scale * 10, 267, PAGE_MARGIN + scale * 10, 273);
  pdf.text("10 cm", PAGE_MARGIN, 278);
  pdf.setTextColor(165, 92, 35);
  pdf.text(
    "Tracejado: componente visível sem regra de fabricação mapeada; contorno é apenas envelope.",
    PAGE_MARGIN,
    286,
  );
}

function drawCutPlanPage(
  pdf: jsPDF,
  result: CutPlanResult,
  sheet: CutPlanResult["sheets"][number],
  materialName: string,
) {
  pdf.addPage();
  pdf.setTextColor(55, 43, 34);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(17);
  pdf.text(`Plano heurístico · ${materialName}`, PAGE_MARGIN, 23);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.text(
    `Chapa ${sheet.number} · ${result.input.sheetWidthCm} × ${result.input.sheetHeightCm} cm · serra ${result.input.kerfCm} cm · margem ${result.input.marginCm} cm`,
    PAGE_MARGIN,
    31,
  );
  const availableW = PAGE_W - 42;
  const availableH = 205;
  const scale = Math.min(
    availableW / result.input.sheetWidthCm,
    availableH / result.input.sheetHeightCm,
  );
  const x0 = (PAGE_W - result.input.sheetWidthCm * scale) / 2;
  const y0 = 48;
  pdf.setDrawColor(70, 56, 44);
  pdf.setLineWidth(0.6);
  pdf.rect(x0, y0, result.input.sheetWidthCm * scale, result.input.sheetHeightCm * scale);
  for (const placement of sheet.placements) {
    const x = x0 + placement.xCm * scale;
    const y = y0 + placement.yCm * scale;
    const w = placement.widthCm * scale;
    const h = placement.heightCm * scale;
    pdf.setFillColor(241, 230, 215);
    pdf.setDrawColor(97, 71, 49);
    pdf.rect(x, y, w, h, "FD");
    if (w > 13 && h > 7) {
      pdf.setFontSize(7);
      pdf.text(`${placement.code}${placement.rotated ? " ↻" : ""}`, x + w / 2, y + h / 2, {
        align: "center",
      });
    }
  }
  const y = y0 + result.input.sheetHeightCm * scale + 14;
  pdf.setFontSize(8);
  pdf.setTextColor(140, 76, 33);
  textLines(pdf, result.disclaimer, PAGE_MARGIN, y, PAGE_W - PAGE_MARGIN * 2, 4);
}

export async function createManufacturingPdf(
  document: FabricationDocument,
  previewImage?: string | null,
  cutPlans: Record<string, { materialName: string; plan: CutPlanResult }> = {},
) {
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ unit: "mm", format: "a4", orientation: "portrait" });
  const counts = validationCounts(document.issues);
  pageHeading(pdf, "Projeto preliminar para fabricação", document);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(10);
  pdf.setTextColor(158, 71, 32);
  pdf.text("NÃO LIBERADO PARA PRODUÇÃO", PAGE_MARGIN, 47);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(55, 43, 34);
  let y = 57;
  const rows = [
    ["Projeto", safeText(document.metadata.projectName || typeDef(document.config.type).label)],
    [
      "Código / revisão",
      `${safeText(document.metadata.projectCode)} / ${safeText(document.metadata.revision)}`,
    ],
    ["Cliente", safeText(document.metadata.customerName)],
    ["Marcenaria", safeText(document.metadata.workshopName)],
    ["Destinatário", safeText(document.metadata.recipient)],
    [
      "Dimensões nominais",
      `${document.config.width} × ${document.config.height} × ${document.config.depth} cm`,
    ],
    ["Peças retangulares mapeadas", String(document.pieces.length)],
    ["Componentes visíveis no modelo", String(document.visiblePartCount)],
    ["Pendências críticas / em aberto", `${counts.critical} / ${counts.pending}`],
  ];
  for (const [label, value] of rows) {
    pdf.setFont("helvetica", "bold");
    pdf.text(`${label}:`, PAGE_MARGIN, y);
    pdf.setFont("helvetica", "normal");
    const valueBottom = textLines(pdf, safeText(value), 74, y, 55, 4.5);
    y = Math.max(y + 7, valueBottom) + 1;
  }
  y += 1;
  pdf.setFont("helvetica", "bold");
  pdf.text("Materiais mapeados a partir dos componentes", PAGE_MARGIN, y);
  y += 6;
  pdf.setFont("helvetica", "normal");
  for (const group of document.materialGroups.slice(0, 8)) {
    pdf.text(
      `${group.materialName} · ${group.thicknessCm.toFixed(2)} cm · ${group.pieceCount} peça(s) · área líquida geométrica ${group.netAreaM2.toFixed(3)} m²`,
      PAGE_MARGIN + 2,
      y,
    );
    y += 5;
  }
  y += 3;
  pdf.setFont("helvetica", "bold");
  pdf.setTextColor(158, 71, 32);
  pdf.text("Aviso técnico", PAGE_MARGIN, y);
  y += 5;
  pdf.setFont("helvetica", "normal");
  pdf.setTextColor(75, 62, 51);
  y = textLines(
    pdf,
    "Este documento representa os volumes geométricos do configurador. Veio e arestas com fita podem ser informados por peça, mas o tipo/espessura comercial da fita, perdas, tolerâncias, plano de usinagem, furos, folgas, ferragens completas, colisões e montagem não são certificados. O responsável técnico deve revisar todas as medidas e operações antes da fabricação.",
    PAGE_MARGIN,
    y,
    PAGE_W - PAGE_MARGIN * 2,
    4.5,
  );
  if (previewImage?.startsWith("data:image/")) {
    try {
      const imageFormat = previewImage.startsWith("data:image/jpeg") ? "JPEG" : "PNG";
      pdf.addImage(previewImage, imageFormat, 137, 52, 55, 42, undefined, "FAST");
      pdf.setFontSize(7);
      pdf.setTextColor(110, 95, 82);
      pdf.text("Captura do configurador; não é desenho técnico.", 137, 99);
    } catch {
      // Captures can be blocked by browser/WebGL; technical pages remain available.
    }
  }

  for (const view of ["front", "side", "top"] as const) {
    pdf.addPage();
    pageHeading(
      pdf,
      `Desenho de referência · ${view === "front" ? "frente" : view === "side" ? "lateral" : "planta"}`,
      document,
    );
    drawProjection(pdf, document, view);
  }

  pdf.addPage();
  pageHeading(pdf, "Lista preliminar de placas", document);
  pdf.setFontSize(7.5);
  pdf.setFont("helvetica", "bold");
  const columns = [18, 31, 78, 119, 137, 153, 171];
  const headers = ["Código", "ID MOVA", "Descrição", "Comp. cm", "Larg. cm", "Esp. cm", "Material"];
  headers.forEach((header, index) => pdf.text(header, columns[index]!, 44));
  pdf.setDrawColor(177, 162, 147);
  pdf.line(PAGE_MARGIN, 47, PAGE_W - PAGE_MARGIN, 47);
  let rowY = 53;
  pdf.setFont("helvetica", "normal");
  for (const piece of document.pieces) {
    if (rowY > PAGE_H - 27) {
      pdf.addPage();
      pageHeading(pdf, "Lista preliminar de placas · continuação", document);
      rowY = 44;
      pdf.setFont("helvetica", "bold");
      headers.forEach((header, index) => pdf.text(header, columns[index]!, rowY));
      pdf.line(PAGE_MARGIN, rowY + 3, PAGE_W - PAGE_MARGIN, rowY + 3);
      rowY += 10;
      pdf.setFont("helvetica", "normal");
    }
    const vals = [
      piece.code,
      piece.partId.slice(0, 12),
      piece.name.slice(0, 23),
      piece.lengthCm.toFixed(2),
      piece.widthCm.toFixed(2),
      piece.thicknessCm.toFixed(2),
      piece.materialName.slice(0, 12),
    ];
    vals.forEach((value, index) => pdf.text(value, columns[index]!, rowY));
    const grainText =
      piece.grainDirection === "length"
        ? "paralelo ao comprimento"
        : piece.grainDirection === "width"
          ? "paralelo à largura"
          : piece.grainDirection === "none"
            ? "sem veio obrigatório"
            : "pendente";
    const edgeText =
      piece.edgeBanding === null
        ? "pendente"
        : piece.edgeBanding.length > 0
          ? piece.edgeBanding.join(", ")
          : "nenhuma";
    const manualText = piece.observation.includes("manualmente") ? " · ajuste manual" : "";
    const positionText = piece.positionCm.map((n) => n.toFixed(1)).join(" / ");
    pdf.setFontSize(6);
    pdf.setTextColor(105, 92, 79);
    const detailBottom = textLines(
      pdf,
      `Veio: ${grainText} · Fita: ${edgeText} · Posição X/Y/Z: ${positionText} cm${manualText}`,
      columns[2]!,
      rowY + 3.5,
      PAGE_W - PAGE_MARGIN - columns[2]!,
      3,
    );
    pdf.setTextColor(55, 43, 34);
    pdf.setFontSize(7.5);
    rowY = Math.max(rowY + 11, detailBottom + 2);
  }
  if (document.pieces.length === 0) {
    pdf.setFontSize(9);
    pdf.text(
      "Nenhuma placa pôde ser gerada pelo perfil de fabricação disponível.",
      PAGE_MARGIN,
      56,
    );
  }
  pdf.setFontSize(7);
  pdf.setTextColor(135, 72, 34);
  textLines(
    pdf,
    "As medidas são envelopes retangulares cm do modelo; revisar encaixes, bordas e usinagens. Portas/caixas de gaveta podem estar incompletas.",
    PAGE_MARGIN,
    Math.min(rowY + 4, PAGE_H - 14),
    PAGE_W - PAGE_MARGIN * 2,
    4,
  );

  pdf.addPage();
  pageHeading(pdf, "Materiais, ferragens e parâmetros", document);
  let materialY = 46;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(10);
  pdf.text("Materiais e área líquida das peças mapeadas", PAGE_MARGIN, materialY);
  materialY += 8;
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  if (document.materialGroups.length === 0)
    pdf.text("Sem componentes com material de placa mapeados.", PAGE_MARGIN, materialY);
  for (const group of document.materialGroups) {
    pdf.text(
      `${group.materialName} · acabamento ${group.finish} · espessura ${group.thicknessCm.toFixed(2)} cm`,
      PAGE_MARGIN,
      materialY,
    );
    materialY += 5;
    pdf.text(
      `${group.pieceCount} peça(s) · área líquida geométrica ${group.netAreaM2.toFixed(3)} m²`,
      PAGE_MARGIN + 4,
      materialY,
    );
    materialY += 8;
  }
  materialY += 3;
  pdf.setFont("helvetica", "bold");
  pdf.text("Ferragens que exigem ficha/contagem da marcenaria", PAGE_MARGIN, materialY);
  materialY += 7;
  pdf.setFont("helvetica", "normal");
  const hardwareIssues = document.issues.filter((issue) =>
    /ferragem|puxador|gaveta/i.test(`${issue.title} ${issue.detail}`),
  );
  for (const issue of hardwareIssues) {
    materialY =
      textLines(
        pdf,
        `• ${issue.title}: ${issue.detail}`,
        PAGE_MARGIN,
        materialY,
        PAGE_W - PAGE_MARGIN * 2,
        4.5,
      ) + 2;
  }
  materialY += 4;
  pdf.setFont("helvetica", "bold");
  pdf.text("Pendências de validação", PAGE_MARGIN, materialY);
  materialY += 7;
  pdf.setFont("helvetica", "normal");
  for (const issue of document.issues.filter(
    (entry) => entry.severity === "critical" || entry.severity === "pending",
  )) {
    if (materialY > PAGE_H - 25) {
      pdf.addPage();
      pageHeading(pdf, "Pendências de fabricação · continuação", document);
      materialY = 44;
      pdf.setFont("helvetica", "normal");
    }
    const prefix = issue.severity === "critical" ? "CRÍTICO" : "PENDENTE";
    materialY =
      textLines(
        pdf,
        `${prefix} · ${issue.title} — ${issue.detail}`,
        PAGE_MARGIN,
        materialY,
        PAGE_W - PAGE_MARGIN * 2,
        4.5,
      ) + 2;
  }

  for (const [groupKey, entry] of Object.entries(cutPlans)) {
    for (const [index, sheet] of entry.plan.sheets.entries()) {
      drawCutPlanPage(pdf, entry.plan, sheet, entry.materialName || groupKey);
    }
    if (entry.plan.unplaced.length > 0) {
      pdf.addPage();
      pageHeading(pdf, `Peças não encaixadas · ${entry.materialName}`, document);
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(9);
      let y = 48;
      for (const item of entry.plan.unplaced) {
        y =
          textLines(
            pdf,
            `${item.code}: ${item.reason}`,
            PAGE_MARGIN,
            y,
            PAGE_W - PAGE_MARGIN * 2,
            5,
          ) + 2;
      }
    }
  }

  pdf.setProperties({
    title: `${safeText(document.metadata.projectName || typeDef(document.config.type).label)} · Projeto preliminar de fabricação`,
    subject: `Código ${safeText(document.metadata.projectCode)} · Revisão ${safeText(document.metadata.revision)}`,
    author: "MOVA · Configurador paramétrico",
    creator: "MOVA",
  });
  return new Uint8Array(pdf.output("arraybuffer"));
}
