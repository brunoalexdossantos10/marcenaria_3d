import { createFileRoute } from "@tanstack/react-router";
import { AuthPage } from "@/components/saas/AuthPage";
export const Route = createFileRoute("/cadastro")({
  ssr: false,
  head: () => ({ meta: [{ title: "Criar conta | MOVA" }] }),
  component: () => <AuthPage mode="cadastro" />,
});
