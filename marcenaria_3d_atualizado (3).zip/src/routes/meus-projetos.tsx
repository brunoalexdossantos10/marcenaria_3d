import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Copy, FileDown, FileText, Trash2 } from "lucide-react";
import SiteLayout, { PageHero } from "@/components/site/SiteLayout";
import Reveal from "@/components/site/Reveal";
import { fetchProjects, deleteProject, type SavedProject } from "@/lib/furniture/store";
import { encodeConfiguration } from "@/lib/furniture/configValidation";
import { ProjectAccount } from "@/components/site/ProjectAccount";
import { typeDef } from "@/lib/furniture/types";
import { material } from "@/lib/furniture/materials";
import { brl } from "@/lib/furniture/pricing";
import { computeScenePrice } from "@/lib/furniture/pricing";
import type { PriceBreakdown } from "@/lib/furniture/pricing";
import { getGuestProjectRef, saveGuestProject, deleteGuestProject } from "@/lib/saas/guestProjects";
import { getTenant } from "@/lib/saas/api";
import { nextProjectCode, persistProject } from "@/lib/furniture/store";

function resumeHref(project: SavedProject) {
  if (project.tenantSlug)
    return `/m/${project.tenantSlug}?project=${encodeURIComponent(project.id)}`;
  try {
    const params = new URLSearchParams({
      c: encodeConfiguration(project.config),
      projectId: project.id,
      projectCode: project.code,
      createdAt: project.createdAt,
      ...(project.projectName ? { projectName: project.projectName } : {}),
      ...(project.organizationId ? { organizationId: project.organizationId } : {}),
    });
    return `/configurador?${params.toString()}`;
  } catch {
    return null;
  }
}

export const Route = createFileRoute("/meus-projetos")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Meus projetos salvos | MOVA" },
      {
        name: "description",
        content:
          "Retome os móveis que você configurou no MOVA: medidas, acabamento, peças e estimativa de investimento salvos neste dispositivo.",
      },
      { property: "og:title", content: "Meus projetos salvos | MOVA" },
      {
        property: "og:description",
        content: "Seus móveis configurados em 3D, prontos para retomar ou enviar para orçamento.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MeusProjetosPage,
});

function MeusProjetosPage() {
  const [projects, setProjects] = useState<SavedProject[]>([]);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = useCallback(() => {
    fetchProjects()
      .then(setProjects)
      .catch((reason) => setError(reason.message));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const remove = async (id: string) => {
    if (!window.confirm("Excluir este projeto salvo? Esta ação não pode ser desfeita.")) return;
    setBusyId(id);
    try {
      const guestRef = getGuestProjectRef(id);
      if (guestRef) await deleteGuestProject(guestRef);
      else await deleteProject(id);
      setProjects((current) => current.filter((p) => p.id !== id));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível excluir.");
    } finally {
      setBusyId(null);
    }
  };

  const duplicate = async (project: SavedProject) => {
    setBusyId(project.id);
    setError("");
    try {
      const name = `${project.projectName || typeDef(project.config.type).label} (cópia)`.slice(
        0,
        120,
      );
      if (project.tenantSlug) {
        await saveGuestProject(
          project.tenantSlug,
          project.config,
          undefined,
          name,
          project.previewImage,
        );
      } else {
        await persistProject({
          id: crypto.randomUUID(),
          code: nextProjectCode(),
          createdAt: new Date().toISOString(),
          projectName: name,
          config: project.config,
          price: project.price,
          ...(project.costBreakdown ? { costBreakdown: project.costBreakdown } : {}),
          ...(project.previewImage ? { previewImage: project.previewImage } : {}),
          status: "Novo projeto",
        });
      }
      refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível duplicar o projeto.");
    } finally {
      setBusyId(null);
    }
  };

  const downloadPdf = async (project: SavedProject) => {
    setBusyId(project.id);
    setError("");
    try {
      const { createProposalPdf } = await import("@/lib/furniture/proposalPdf");
      const tenant = project.tenantSlug ? await getTenant(project.tenantSlug) : null;
      const identity = tenant
        ? {
            name: tenant.organization.name,
            primaryColor: tenant.organization.primary_color,
            ...(tenant.organization.logo ? { logo: tenant.organization.logo } : {}),
            ...(tenant.organization.phone ? { phone: tenant.organization.phone } : {}),
            ...(tenant.organization.whatsapp ? { whatsapp: tenant.organization.whatsapp } : {}),
            ...(tenant.organization.email ? { email: tenant.organization.email } : {}),
            ...(tenant.organization.website ? { website: tenant.organization.website } : {}),
          }
        : undefined;
      const pdf = await createProposalPdf({
        config: project.config,
        price:
          project.costBreakdown?.total === project.price
            ? (project.costBreakdown as PriceBreakdown)
            : computeScenePrice(project.config),
        code: project.code,
        projectName: project.projectName || typeDef(project.config.type).label,
        date: new Date(project.updatedAt ?? project.createdAt),
        ...(project.customer ? { customer: project.customer } : {}),
        ...(project.previewImage ? { image: project.previewImage } : {}),
        conditions: {},
        ...(identity ? { identity } : {}),
      });
      pdf.save(`${project.code.toLowerCase()}.pdf`);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível gerar o PDF.");
    } finally {
      setBusyId(null);
    }
  };

  const filtered = projects
    .filter((project) =>
      [
        project.projectName,
        project.code,
        typeDef(project.config.type).label,
        project.status,
        project.customer?.name,
        `${project.config.width} × ${project.config.height} × ${project.config.depth}`,
      ]
        .join(" ")
        .toLowerCase()
        .includes(query.trim().toLowerCase()),
    )
    .sort(
      (a, b) => Date.parse(b.updatedAt ?? b.createdAt) - Date.parse(a.updatedAt ?? a.createdAt),
    );

  const download = (p: SavedProject) => {
    const blob = new Blob([JSON.stringify(p, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${p.code.replace(/\W+/g, "-").toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Meus projetos"
        title="Seus móveis configurados"
        description="Entre por e-mail para guardar novos projetos na sua conta. Projetos anteriores deste navegador continuam disponíveis."
      />

      <section className="mx-auto max-w-6xl px-5 py-16">
        <ProjectAccount onChange={refresh} />
        <label className="mb-5 block max-w-xl text-sm text-muted-foreground">
          Buscar por nome, código, móvel, status, cliente ou medidas
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Ex.: cozinha, M3D-…, 240 × 220"
            className="mt-2 h-11 w-full rounded-lg border border-border bg-background px-3 text-foreground outline-none focus:border-ring"
          />
        </label>
        {error && (
          <p role="alert" className="mb-5 text-sm text-destructive">
            {error}
          </p>
        )}
        {filtered.length === 0 ? (
          <Reveal>
            <div className="rounded-3xl border border-dashed border-border bg-card p-12 text-center">
              <h2 className="text-2xl">Nenhum projeto salvo ainda</h2>
              <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
                Abra o configurador, ajuste as medidas do seu ambiente e clique em “Salvar projeto”.
              </p>
              <Link to="/configurador" className="btn-primary mt-7">
                Criar meu primeiro projeto <ArrowRight className="size-4" />
              </Link>
            </div>
          </Reveal>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p, i) => (
              <Reveal key={p.id} delay={i * 70}>
                <article className="card-lift flex h-full flex-col rounded-2xl border border-border bg-card p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-lg">{p.projectName || typeDef(p.config.type).label}</h2>
                      <p className="text-xs text-muted-foreground">
                        {p.code} · criado {new Date(p.createdAt).toLocaleDateString("pt-BR")} ·
                        atualizado{" "}
                        {new Date(p.updatedAt ?? p.createdAt).toLocaleDateString("pt-BR")} ·{" "}
                        {p.status}
                      </p>
                    </div>
                    <span
                      className="size-8 shrink-0 rounded-lg border border-black/10"
                      style={{ background: material(p.config.material).color }}
                    />
                  </div>

                  <p className="mt-4 text-sm">{typeDef(p.config.type).label}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.config.width} × {p.config.height} × {p.config.depth} cm ·{" "}
                    {material(p.config.material).label}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {p.config.doors} portas · {p.config.drawers} gavetas · {p.config.shelves}{" "}
                    prateleiras
                  </p>

                  <p className="mt-5 font-display text-2xl tabular-nums">{brl(p.price)}</p>

                  <div className="mt-5 flex flex-wrap gap-2 border-t border-border pt-4">
                    {resumeHref(p) ? (
                      <a href={resumeHref(p)!} className="chip">
                        Retomar
                      </a>
                    ) : (
                      <button
                        type="button"
                        className="chip"
                        onClick={() =>
                          setError(
                            "Este projeto é grande demais para retomar por link; baixe o JSON.",
                          )
                        }
                      >
                        Retomar
                      </button>
                    )}
                    <button type="button" onClick={() => download(p)} className="chip">
                      <FileDown className="mr-1.5 size-3.5" /> JSON
                    </button>
                    <button
                      type="button"
                      disabled={busyId === p.id}
                      onClick={() => void downloadPdf(p)}
                      className="chip disabled:opacity-50"
                    >
                      <FileText className="mr-1.5 size-3.5" /> PDF
                    </button>
                    <button
                      type="button"
                      disabled={busyId === p.id}
                      onClick={() => void duplicate(p)}
                      className="chip disabled:opacity-50"
                    >
                      <Copy className="mr-1.5 size-3.5" /> Duplicar
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(p.id)}
                      disabled={busyId === p.id}
                      className="chip text-destructive disabled:opacity-50"
                    >
                      <Trash2 className="mr-1.5 size-3.5" /> Excluir
                    </button>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
