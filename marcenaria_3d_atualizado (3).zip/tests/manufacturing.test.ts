import test from "node:test";
import assert from "node:assert/strict";
import { buildFurniture, normalizeConfig } from "../src/lib/furniture/builder.ts";
import {
  applyFabricationPieceOverrides,
  buildFabricationDocument,
  calculatePanelCutPlan,
  createZipBytes,
  cutPlanSvg,
  fabricationDrawingSvg,
  fabricationPiecesCsv,
  edgeBandingLengthCm,
  textBytes,
  type FabricationPiece,
} from "../src/lib/furniture/manufacturing.ts";
import { createManufacturingPdf } from "../src/lib/furniture/manufacturingPdf.ts";

const wardrobe = () => normalizeConfig({ type: "guarda-roupa", panelThickness: 1.8 });
const piece = (code: string, lengthCm: number, widthCm: number): FabricationPiece => ({
  code,
  partId: code,
  name: code,
  kind: "prateleira",
  quantity: 1,
  lengthCm,
  widthCm,
  thicknessCm: 1.8,
  materialId: "branco",
  materialName: "MDF Branco",
  finish: "mdf",
  positionCm: [0, 0, 0],
  grainDirection: null,
  edgeBanding: null,
  observation: "Teste",
});

test("manufacturing panels derive from actual cabinet builder boxes and preserve per-part thickness", () => {
  const config = wardrobe();
  const modelParts = buildFurniture(config);
  const document = buildFabricationDocument(config, { projectCode: "M3D-TEST" }, modelParts);
  const left = document.pieces.find((entry) => entry.partId === "lateral-esq");
  const back = document.pieces.find((entry) => entry.partId === "fundo");
  const top = document.pieces.find((entry) => entry.partId === "tampo");
  const leftPart = modelParts.find((entry) => entry.id === "lateral-esq")!;
  const backPart = modelParts.find((entry) => entry.id === "fundo")!;
  const topPart = modelParts.find((entry) => entry.id === "tampo")!;

  assert.ok(left && back && top);
  assert.deepEqual(
    [left.lengthCm, left.widthCm, left.thicknessCm],
    [leftPart.size[1], leftPart.size[2], leftPart.size[0]],
  );
  assert.deepEqual(
    [back.lengthCm, back.widthCm, back.thicknessCm],
    [backPart.size[0], backPart.size[1], backPart.size[2]],
  );
  assert.deepEqual(
    [top.lengthCm, top.widthCm, top.thicknessCm],
    [topPart.size[0], topPart.size[2], topPart.size[1]],
  );
  assert.equal(back.thicknessCm, 0.6);
  assert.equal(top.thicknessCm, config.panelThickness);
  assert.equal(document.readyForManufacture, false);
  assert.ok(document.issues.some((issue) => issue.id === "edge-banding"));
  assert.ok(document.issues.some((issue) => issue.id === "collision-clearance-analysis"));
});

test("panel volumes outside the configured envelope are reported as a warning", () => {
  const config = wardrobe();
  const moved = buildFurniture(config).map((part) =>
    part.id === "tampo"
      ? { ...part, pos: [config.width, part.pos[1], part.pos[2]] as [number, number, number] }
      : part,
  );
  const document = buildFabricationDocument(config, {}, moved);
  const issue = document.issues.find((entry) => entry.id === "nominal-envelope-divergence");
  assert.ok(issue);
  assert.equal(issue.severity, "warning");
  assert.match(issue.detail, /largura/);
});

test("unsupported organic furniture is not converted from a bounding box into a cut list", () => {
  const config = normalizeConfig({ type: "mesa-oval" });
  const document = buildFabricationDocument(config);
  assert.equal(document.profileSupported, false);
  assert.equal(document.pieces.length, 0);
  assert.ok(document.issues.some((issue) => issue.id === "unsupported-fabrication-profile"));
});

test("glass and mirror surfaces with no purchase thickness are not presented as cut panels", () => {
  const config = normalizeConfig({ type: "guarda-roupa", doors: 2, doorFace: "vidro" });
  const document = buildFabricationDocument(config);
  assert.equal(
    document.pieces.some((entry) => entry.kind === "porta"),
    false,
  );
  assert.ok(document.issues.some((issue) => issue.id.startsWith("surface-spec-porta-")));
});

test("drawer fronts do not imply drawer boxes and trigger a critical missing-components issue", () => {
  const config = normalizeConfig({ type: "guarda-roupa", drawers: 2 });
  const document = buildFabricationDocument(config);
  assert.equal(document.pieces.filter((entry) => entry.kind === "gaveta").length, 2);
  assert.ok(
    document.issues.some(
      (issue) => issue.id === "drawer-box-not-modeled" && issue.severity === "critical",
    ),
  );
});

test("room furniture and unclassified accessories are explicitly excluded", () => {
  const config = normalizeConfig({
    type: "guarda-roupa",
    accessories: ["sapateira"],
    roomItems: [
      {
        id: "second",
        position: [0, 0],
        config: normalizeConfig({ type: "rack" }),
      },
    ],
  });
  const document = buildFabricationDocument(config);
  assert.ok(document.issues.some((issue) => issue.id === "room-items-excluded"));
  assert.ok(document.issues.some((issue) => issue.id === "visual-extras-omitted"));
  assert.ok(document.issues.some((issue) => issue.id === "accessory-specification"));
});

test("CSV identifies each actual model part, reports unresolved grain and edge tape, and uses pt-BR separators", () => {
  const document = buildFabricationDocument(wardrobe(), {
    projectName: "Projeto; teste",
    projectCode: "M3D-CSV-1",
    revision: "4",
  });
  const csv = fabricationPiecesCsv(document);
  assert.ok(csv.startsWith("\uFEFF"));
  assert.ok(csv.includes("Código"));
  assert.ok(csv.includes("ID do componente MOVA"));
  assert.ok(csv.includes("Pendente"));
  assert.ok(csv.includes("M3D-CSV-1"));
  assert.ok(csv.includes("Data de geração (ISO)"));
  assert.ok(csv.includes('"Projeto; teste"'));
  assert.ok(csv.includes(";"));
});

test("manual piece details update the technical package, material groups, CSV and banding length", () => {
  const source = buildFabricationDocument(wardrobe());
  const first = source.pieces[0]!;
  const sourcePart = source.modelParts.find((entry) => entry.id === first.partId)!;
  const sourcePartSize = [...sourcePart.size];
  const sourceLength = first.lengthCm;
  const otherMaterial = source.pieces.find((entry) => entry.materialId !== first.materialId);
  assert.ok(otherMaterial, "fixture wardrobe should use more than one board material");
  const editedLength = sourceLength + 5;
  const document = applyFabricationPieceOverrides(source, {
    [first.partId]: {
      lengthCm: editedLength,
      materialId: otherMaterial.materialId,
      grainDirection: "length",
      edgeBanding: ["L1", "C1"],
    },
  });
  const edited = document.pieces.find((entry) => entry.partId === first.partId)!;
  assert.equal(first.lengthCm, sourceLength, "source document must remain immutable");
  assert.equal(edited.lengthCm, editedLength);
  assert.equal(edited.grainDirection, "length");
  assert.deepEqual(edited.edgeBanding, ["L1", "C1"]);
  assert.ok(document.materialGroups.some((group) => group.materialId === otherMaterial.materialId));
  const editedPart = document.modelParts.find((entry) => entry.id === first.partId)!;
  assert.notDeepEqual(editedPart.size, sourcePart.size);
  assert.deepEqual(sourcePart.size, sourcePartSize);
  assert.equal(edgeBandingLengthCm([edited]), editedLength + edited.widthCm);
  assert.ok(document.issues.some((issue) => issue.id === "manual-piece-overrides"));
  assert.ok(document.issues.some((issue) => issue.id === "edge-tape-specification"));
  const csv = fabricationPiecesCsv(document);
  assert.ok(csv.includes("Paralelo ao comprimento"));
  assert.ok(csv.includes("L1, C1"));
});

test("orthographic drawing names actual piece IDs and distinguishes unmapped model components", () => {
  const document = buildFabricationDocument(
    wardrobe(),
    { projectCode: "M3D-DWG-8", revision: "8" },
    undefined,
    "2026-10-10T12:00:00.000Z",
  );
  const svg = fabricationDrawingSvg(document, "front");
  assert.ok(svg.includes("Vista frontal"));
  assert.ok(svg.includes('data-part="lateral-esq"'));
  assert.ok(document.pieces.some((entry) => entry.code === "P001"));
  assert.ok(svg.includes("tracejado") || svg.includes("Tracejado"));
  assert.ok(svg.includes("cm"));
  assert.ok(svg.includes("M3D-DWG-8"));
  assert.ok(svg.includes("Rev. 8"));
  assert.ok(svg.includes("10/10/2026"));
});

test("cut plan requires explicit stock dimensions and keeps placements inside stock with no overlap", () => {
  const inputs = {
    sheetWidthCm: 120,
    sheetHeightCm: 240,
    kerfCm: 0.3,
    marginCm: 1,
    allowRotation: false,
  };
  const pieces = [piece("A", 80, 40), piece("B", 75, 35), piece("C", 60, 30), piece("D", 55, 25)];
  const plan = calculatePanelCutPlan(pieces, inputs);
  assert.equal(plan.unplaced.length, 0);
  assert.ok(plan.sheets.length >= 1);
  for (const sheet of plan.sheets) {
    for (const placement of sheet.placements) {
      assert.ok(placement.xCm >= inputs.marginCm);
      assert.ok(placement.yCm >= inputs.marginCm);
      assert.ok(placement.xCm + placement.widthCm <= inputs.sheetWidthCm - inputs.marginCm + 1e-8);
      assert.ok(
        placement.yCm + placement.heightCm <= inputs.sheetHeightCm - inputs.marginCm + 1e-8,
      );
    }
    for (let i = 0; i < sheet.placements.length; i++) {
      for (let j = i + 1; j < sheet.placements.length; j++) {
        const a = sheet.placements[i]!;
        const b = sheet.placements[j]!;
        const separated =
          a.xCm + a.widthCm <= b.xCm ||
          b.xCm + b.widthCm <= a.xCm ||
          a.yCm + a.heightCm <= b.yCm ||
          b.yCm + b.heightCm <= a.yCm;
        assert.ok(separated, `Peças ${a.code} e ${b.code} se sobrepõem`);
      }
    }
  }
  assert.match(plan.disclaimer, /heurística/i);
  const cutSvg = cutPlanSvg(
    plan,
    new Map(pieces.map((entry) => [entry.code, entry])),
    0,
    {
      projectName: "Corte de teste",
      projectCode: "M3D-CUT-1",
      revision: "5",
      customerName: "",
      workshopName: "",
      recipient: "",
    },
    "2026-10-10T12:00:00.000Z",
  );
  assert.ok(cutSvg.includes("M3D-CUT-1"));
  assert.ok(cutSvg.includes("Rev. 5"));
  assert.ok(cutSvg.includes("10/10/2026"));
  assert.throws(
    () => calculatePanelCutPlan(pieces, { ...inputs, sheetWidthCm: 0 }),
    /dimensões comerciais/i,
  );
});

test("pieces wider than the explicit stock are reported as unplaced, never silently dropped", () => {
  const plan = calculatePanelCutPlan([piece("BIG", 260, 40)], {
    sheetWidthCm: 120,
    sheetHeightCm: 240,
    kerfCm: 0.3,
    marginCm: 1,
    allowRotation: false,
  });
  assert.deepEqual(
    plan.unplaced.map((entry) => entry.code),
    ["BIG"],
  );
  assert.ok(plan.unplacedAreaM2 > 0);
  assert.equal(plan.sheets.length, 0);
});

test("cut-plan rotation is restricted to pieces explicitly marked without required grain", () => {
  const input = {
    sheetWidthCm: 60,
    sheetHeightCm: 120,
    kerfCm: 0,
    marginCm: 0,
    allowRotation: true,
  };
  const directional = { ...piece("GRAIN", 120, 60), grainDirection: "length" as const };
  const blocked = calculatePanelCutPlan([directional], input);
  assert.deepEqual(
    blocked.unplaced.map((entry) => entry.code),
    ["GRAIN"],
  );
  assert.match(blocked.unplaced[0]!.reason, /veio pendente\/direcional/);

  const unrestricted = { ...piece("FREE", 120, 60), grainDirection: "none" as const };
  const allowed = calculatePanelCutPlan([unrestricted], input);
  assert.equal(allowed.unplaced.length, 0);
  assert.equal(allowed.sheets[0]!.placements[0]!.rotated, true);
});

test("technical PDF is a readable PDF byte stream generated from the same document", async () => {
  const document = buildFabricationDocument(wardrobe(), {
    projectName: "Verificação do pacote",
    projectCode: "M3D-PDF-TEST",
    revision: "2",
  });
  const bytes = await createManufacturingPdf(document);
  assert.equal(new TextDecoder().decode(bytes.subarray(0, 4)), "%PDF");
  assert.ok(bytes.length > 10_000);
  assert.equal(document.readyForManufacture, false);
});

test("ZIP writer emits a readable minimal archive with UTF-8 filenames", () => {
  const bytes = createZipBytes([
    { name: "projeto/validacao.json", data: textBytes('{"ok":true}') },
    { name: "projeto/lista-pecas.csv", data: textBytes("código;descrição\n") },
  ]);
  assert.equal(
    new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(0, true),
    0x04034b50,
  );
  const raw = new TextDecoder().decode(bytes);
  assert.ok(raw.includes("validacao.json"));
  assert.ok(raw.includes("lista-pecas.csv"));
  assert.ok(raw.includes("descrição"));
});
