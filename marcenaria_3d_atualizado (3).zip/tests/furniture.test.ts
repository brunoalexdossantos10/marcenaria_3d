import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "three";
import { buildFurniture, normalizeConfig } from "../src/lib/furniture/builder.ts";
import { FURNITURE_TYPES } from "../src/lib/furniture/types.ts";
import { computePrice, computeScenePrice } from "../src/lib/furniture/pricing.ts";
import { constrainPosition } from "../src/lib/furniture/placement.ts";
import {
  parseFurnitureConfig,
  encodeConfiguration,
  decodeConfiguration,
  isConfigurationAllowed,
} from "../src/lib/furniture/configValidation.ts";
import {
  gestureMetrics,
  gestureTransform,
  INITIAL_TRANSFORM,
  cameraErrorMessage,
} from "../src/lib/furniture/arInteraction.ts";
import { createFurnitureScene } from "../src/lib/furniture/usdz.ts";
import type { Part } from "../src/lib/furniture/types.ts";

test("all 119 presets generate finite, positive parts and prices", () => {
  assert.equal(FURNITURE_TYPES.length, 119);
  for (const definition of FURNITURE_TYPES) {
    const config = normalizeConfig({
      type: definition.id,
      ...definition.defaults,
    });
    const parts = buildFurniture(config);
    assert.ok(parts.length > 0, definition.id);
    assert.ok(
      parts.every(
        (part) =>
          part.size.every((n) => Number.isFinite(n) && n > 0) && part.pos.every(Number.isFinite),
      ),
      definition.id,
    );
    assert.ok(Number.isFinite(computePrice(config, parts).total), definition.id);
  }
});
test("null dimensions, unknown materials and unbounded counters are rejected before rendering", () => {
  const config = normalizeConfig({ type: "guarda-roupa" });
  for (const change of [
    { width: null },
    { columns: 1e9 },
    { material: "invalid" },
    { handle: null },
    { componentOffsets: { x: [null, 0, 0] } },
  ]) {
    assert.throws(() => parseFurnitureConfig({ ...config, ...change }));
  }
  const safe = normalizeConfig({ ...config, columns: 1e9, shelves: 1e9 });
  assert.ok(safe.columns <= 12 && safe.shelves <= 60);
  assert.ok(buildFurniture(safe).length < 300);
});
test("glass is charged once, including glass shelves", () => {
  const config = normalizeConfig({ type: "guarda-roupa" });
  const glass: Part = {
    id: "porta-0",
    label: "Vidro",
    kind: "porta",
    pos: [0, 50, 0],
    size: [100, 100, 1],
    material: "vidro",
    face: "vidro",
  };
  const price = computePrice(config, [glass]);
  assert.equal(price.portas, 0);
  assert.equal(price.mdf, 0);
  assert.equal(price.vidro, 340);
  assert.equal(computePrice(config, [{ ...glass, kind: "prateleira" }]).mdf, 0);
});
test("scene pricing includes every cabinet with the same formula", () => {
  const config = normalizeConfig({
    type: "guarda-roupa",
    roomItems: [
      {
        id: "second",
        position: [300, 0],
        config: normalizeConfig({ type: "rack" }),
      },
    ],
  });
  assert.equal(
    computeScenePrice(config).total,
    computePrice(config, buildFurniture(config)).total +
      computePrice(config.roomItems![0].config, buildFurniture(config.roomItems![0].config)).total,
  );
});
test("an impossible drag interval keeps its base position", () => {
  const config = normalizeConfig({ type: "guarda-roupa" });
  const shelf: Part = {
    id: "prateleira-0",
    label: "Prateleira",
    kind: "prateleira",
    pos: [0, 50, 0],
    size: [50, 2, 40],
  };
  const drawer = (id: string, y: number): Part => ({
    id,
    label: id,
    kind: "gaveta",
    pos: [0, y, 0],
    size: [50, 12, 40],
  });
  assert.deepEqual(
    constrainPosition(
      config,
      [shelf, drawer("gaveta-0", 45), drawer("gaveta-1", 55)],
      shelf,
      [0, 52, 0],
    ),
    shelf.pos,
  );
});
test("shelf offsets survive material changes and are revalidated after resize", () => {
  const config = normalizeConfig({
    type: "guarda-roupa",
    shelves: 2,
    drawers: 0,
  });
  const shelf = buildFurniture(config).find((part) => part.kind === "prateleira")!;
  const changed = normalizeConfig({
    ...config,
    componentOffsets: { [shelf.id]: [0, 3, 0] },
  });
  const moved = buildFurniture(changed).find((part) => part.id === shelf.id)!;
  const materialChanged = buildFurniture(
    normalizeConfig({
      ...changed,
      material: "nogueira",
      materials: { ...changed.materials, interior: "nogueira" },
    }),
  ).find((part) => part.id === shelf.id)!;
  assert.notDeepEqual(moved.pos, shelf.pos);
  assert.deepEqual(materialChanged.pos, moved.pos);
  const resized = normalizeConfig({ ...changed, height: 160 });
  const part = buildFurniture(resized).find((p) => p.id === shelf.id)!;
  assert.ok(
    part.pos[1] - part.size[1] / 2 >= resized.panelThickness &&
      part.pos[1] + part.size[1] / 2 <= resized.height,
  );
});
test("shared links support Unicode and cannot bypass a disabled catalog option", () => {
  const config = normalizeConfig({
    type: "guarda-roupa",
    activeFurnitureId: "móvel",
  });
  assert.equal(decodeConfiguration(encodeConfiguration(config)).activeFurnitureId, "móvel");
  assert.equal(
    isConfigurationAllowed(config, [{ kind: "model", source_id: config.type, active: false }]),
    false,
  );
  assert.throws(() => encodeConfiguration({ data: "x".repeat(40000) }));
});

test("URL-encoded saved links recover the exact furniture configuration", () => {
  const config = normalizeConfig({
    type: "mesa",
    width: 180,
    material: "nogueira",
    materials: { estrutura: "nogueira", portas: "carvalho", interior: "branco", fundo: "branco" },
  });
  const encoded = encodeURIComponent(encodeConfiguration(config));
  const recovered = decodeConfiguration(new URLSearchParams(`c=${encoded}`).get("c")!);
  assert.equal(recovered.type, "mesa");
  assert.equal(recovered.width, 180);
  assert.equal(recovered.material, "nogueira");
});
test("one-finger pan and two-finger pinch/rotation use bounded transforms", () => {
  const start = gestureMetrics([
    { x: 0, y: 0 },
    { x: 100, y: 0 },
  ])!;
  const next = gestureMetrics([
    { x: 0, y: 0 },
    { x: 0, y: 200 },
  ])!;
  const transformed = gestureTransform(start, next, INITIAL_TRANSFORM);
  assert.equal(transformed.scale, 2);
  assert.equal(transformed.rotation, Math.PI / 2);
  assert.equal(gestureTransform(start, { ...next, distance: 10000 }, INITIAL_TRANSFORM).scale, 2.5);
  assert.match(
    cameraErrorMessage(new DOMException("denied", "NotAllowedError")),
    /Permita a câmera/,
  );
  assert.match(
    cameraErrorMessage(new DOMException("busy", "NotReadableError")),
    /outro aplicativo/,
  );
});

test("desk and TV panel use category-specific geometry instead of wardrobe carcass", () => {
  const desk = buildFurniture(normalizeConfig({ type: "mesa" }));
  const panel = buildFurniture(normalizeConfig({ type: "painel-tv" }));
  assert.ok(desk.some((part) => part.id === "perna-esq"));
  assert.ok(!desk.some((part) => part.id === "lateral-esq"));
  assert.ok(panel.some((part) => part.id === "painel-principal" && part.kind === "painel"));
  assert.ok(!panel.some((part) => part.id === "lateral-esq"));
});

test("camera scene is rebuilt from the active config and changes furniture identity", () => {
  const wardrobe = normalizeConfig({ type: "guarda-roupa" });
  const desk = normalizeConfig({ type: "mesa", width: 180, height: 75, depth: 70 });
  const rack = normalizeConfig({ type: "rack" });
  const wardrobeScene = createFurnitureScene(wardrobe);
  const deskScene = createFurnitureScene(desk);
  const rackScene = createFurnitureScene(rack);
  assert.ok(wardrobeScene.children.some((child) => child.name === "Lateral esquerda"));
  assert.ok(deskScene.children.some((child) => child.name === "Tampo da mesa"));
  assert.ok(!deskScene.children.some((child) => child.name === "Lateral esquerda"));
  assert.ok(deskScene.children.some((child) => child.name === "Perna esquerda"));
  const rackSize = new THREE.Box3().setFromObject(rackScene).getSize(new THREE.Vector3());
  assert.ok(rackSize.y < 1, "rack must remain a low piece in the camera scene");
  const tallerDesk = createFurnitureScene(normalizeConfig({ ...desk, height: 100 }));
  const deskSize = new THREE.Box3().setFromObject(deskScene).getSize(new THREE.Vector3());
  const tallerDeskSize = new THREE.Box3().setFromObject(tallerDesk).getSize(new THREE.Vector3());
  assert.ok(tallerDeskSize.y > deskSize.y, "dimension changes must rebuild the camera model");
});

test("specific families keep editable counters and modular components", () => {
  for (const type of ["mesa", "painel-tv"] as const) {
    const config = normalizeConfig({
      type,
      doors: 2,
      drawers: 2,
      shelves: 2,
      mirror: true,
      componentInstances: [{ id: "mod-prateleira", type: "prateleira", position: [0, 40, 0] }],
    });
    const parts = buildFurniture(config);
    assert.equal(parts.filter((part) => part.kind === "porta").length, 2, type);
    assert.equal(parts.filter((part) => part.kind === "gaveta").length, 2, type);
    assert.ok(
      parts.some((part) => part.id === "mod-prateleira"),
      type,
    );
    assert.ok(
      parts.some((part) => part.kind === "espelho"),
      type,
    );
  }
});

test("six diverse base models build real furniture geometry", () => {
  const models = [
    { type: "cadeira", required: ["assento", "encosto"] },
    { type: "mesa-jantar", required: ["tampo-jantar", "perna-jantar-1"] },
    { type: "mesa-organica", required: ["tampo-organico", "base-organica"] },
    { type: "mesa", required: ["tampo", "perna-esq"] },
    { type: "banco", required: ["assento", "pe-assento-1"] },
    {
      type: "aparador-organico",
      required: ["tampo-aparador-organico", "prateleira-aparador-organico"],
    },
  ] as const;
  for (const model of models) {
    const definition = FURNITURE_TYPES.find((entry) => entry.id === model.type);
    assert.ok(definition, model.type);
    const config = normalizeConfig({ type: model.type });
    const parts = buildFurniture(config);
    for (const id of model.required)
      assert.ok(
        parts.some((part) => part.id === id),
        `${model.type}:${id}`,
      );
    assert.ok(
      parts.some(
        (part) => part.geometry === "cylinder" || part.geometry === "oval" || part.kind === "tampo",
      ),
      model.type,
    );
  }
});

test("chairs and dining tables use rounded surfaces, tapered supports and connected rails", () => {
  const chair = buildFurniture(normalizeConfig({ type: "cadeira" }));
  assert.equal(chair.find((part) => part.id === "assento")?.geometry, "rounded");
  assert.equal(chair.find((part) => part.id === "encosto")?.geometry, "curved-panel");
  assert.equal(chair.find((part) => part.id === "pe-assento-1")?.geometry, "tapered");
  const back = chair.find((part) => part.id === "encosto")!;
  const rearLeg = chair.find((part) => part.id === "pe-assento-1")!;
  assert.ok(Math.abs(back.pos[2] - rearLeg.pos[2]) < (back.size[2] + rearLeg.size[2]) / 2);

  const table = buildFurniture(normalizeConfig({ type: "mesa-jantar" }));
  assert.equal(table.find((part) => part.id === "tampo-jantar")?.geometry, "rounded");
  const rails = table.filter((part) => part.id.startsWith("travessa-jantar-"));
  assert.equal(rails.length, 2);
  for (const rail of rails) {
    const xEnd = rail.size[0] / 2;
    assert.ok(xEnd > table.find((part) => part.id === "perna-jantar-1")!.pos[0]);
    assert.ok(xEnd > table.find((part) => part.id === "perna-jantar-2")!.pos[0]);
  }
  const oval = buildFurniture(normalizeConfig({ type: "mesa-oval" }));
  assert.equal(oval.find((part) => part.id === "tampo-organico")?.geometry, "oval");
});

test("furniture supports and contact positions recalculate when the overall size changes", () => {
  for (const [type, dimensions] of [
    ["cadeira", { width: 62, height: 102, depth: 64 }],
    ["mesa-jantar", { width: 220, height: 78, depth: 105 }],
  ] as const) {
    const config = normalizeConfig({ type, ...dimensions });
    const parts = buildFurniture(config);
    assert.ok(parts.every((part) => part.size.every((value) => value > 0)));
    if (type === "cadeira") {
      const back = parts.find((part) => part.id === "encosto")!;
      assert.ok(back.pos[1] + back.size[1] / 2 <= dimensions.height);
      assert.ok(back.size[0] < dimensions.width);
    } else {
      const top = parts.find((part) => part.id === "tampo-jantar")!;
      const rail = parts.find((part) => part.id === "travessa-jantar-frente")!;
      assert.equal(top.size[0], dimensions.width);
      assert.ok(rail.size[0] > dimensions.width * 0.6);
    }
  }
});
