import { normalizeConfig } from "../../../src/lib/furniture/builder.ts";
import {
  parseFurnitureConfig,
  isConfigurationAllowed,
} from "../../../src/lib/furniture/configValidation.ts";
import { computeScenePrice } from "../../../src/lib/furniture/pricing.ts";
import type { FurnitureConfig } from "../../../src/lib/furniture/types.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const reply = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });
const encoder = new TextEncoder();

async function digestToken(token: string) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(token));
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function serviceRpc(name: string, body: Record<string, unknown>, url: string, key: string) {
  const response = await fetch(`${url}/rest/v1/rpc/${name}`, {
    method: "POST",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const result = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      typeof result?.message === "string" ? result.message : "Não foi possível salvar o projeto.";
    throw new Error(message);
  }
  return result;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return reply({ error: "Método não permitido." }, 405);

  const apiKey = req.headers.get("apikey");
  if (!apiKey) return reply({ error: "Credencial do aplicativo ausente." }, 401);
  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Serviço temporariamente indisponível." }, 503);

  try {
    if (Number(req.headers.get("content-length")) > 850000)
      return reply({ error: "Projeto grande demais." }, 413);
    const reader = req.body?.getReader();
    if (!reader) return reply({ error: "Solicitação vazia." }, 400);
    const chunks: Uint8Array[] = [];
    let byteLength = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      byteLength += value.byteLength;
      if (byteLength > 850000) {
        await reader.cancel();
        return reply({ error: "Projeto grande demais." }, 413);
      }
      chunks.push(value);
    }
    const bytes = new Uint8Array(byteLength);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const body = JSON.parse(new TextDecoder().decode(bytes));
    const slug = body.tenant_slug;
    if (typeof slug !== "string" || !/^[a-z0-9][a-z0-9-]{2,63}$/.test(slug))
      return reply({ error: "Marcenaria inválida." }, 400);

    const token = body.access_token;
    if (typeof token !== "string" || !/^[0-9a-f]{64}$/.test(token))
      return reply({ error: "Código de recuperação inválido." }, 400);
    const tokenHash = await digestToken(token);
    const action = body.action;
    if (
      action !== "create" &&
      (typeof body.project_id !== "string" || !/^[0-9a-f-]{36}$/i.test(body.project_id))
    )
      return reply({ error: "Identificador do projeto inválido." }, 400);
    const common = {
      p_tenant_slug: slug,
      p_project_id: body.project_id,
      p_token_hash: tokenHash,
    };

    if (action === "read") {
      const project = await serviceRpc("read_guest_project", common, url, serviceKey);
      return reply({ project });
    }
    if (action === "delete") {
      await serviceRpc("delete_guest_project", common, url, serviceKey);
      return reply({ deleted: true });
    }
    if (action !== "create" && action !== "update") return reply({ error: "Ação inválida." }, 400);

    // Tenant identity and the public catalog are resolved by the server.
    const tenantResponse = await fetch(`${url}/rest/v1/rpc/get_public_tenant`, {
      method: "POST",
      headers: { apikey: apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({ tenant_slug: slug }),
      signal: AbortSignal.timeout(10000),
    });
    if (!tenantResponse.ok) return reply({ error: "Credencial do aplicativo inválida." }, 401);
    const tenant = await tenantResponse.json();
    if (!tenant) return reply({ error: "Marcenaria indisponível." }, 404);

    const config = normalizeConfig(parseFurnitureConfig(body.configuration) as FurnitureConfig);
    if (!isConfigurationAllowed(config, tenant.catalog))
      return reply({ error: "Uma opção deste projeto não está disponível nesta marcenaria." }, 400);
    const price = computeScenePrice(config);
    if (
      body.preview_image !== undefined &&
      body.preview_image !== null &&
      (typeof body.preview_image !== "string" ||
        body.preview_image.length > 700000 ||
        !body.preview_image.startsWith("data:image/jpeg;base64,"))
    )
      return reply({ error: "Imagem de pré-visualização inválida." }, 400);
    const previewImage = typeof body.preview_image === "string" ? body.preview_image : null;
    const projectName =
      typeof body.project_name === "string" ? body.project_name.trim().slice(0, 120) : "";

    if (action === "create") {
      const project = await serviceRpc(
        "create_guest_project",
        {
          p_tenant_slug: slug,
          p_project_name: projectName,
          p_configuration: config,
          p_estimated_price: price.total,
          p_cost_breakdown: price,
          p_preview_image: previewImage,
          p_token_hash: tokenHash,
        },
        url,
        serviceKey,
      );
      return reply({ project, access_token: token });
    }

    const project = await serviceRpc(
      "update_guest_project",
      {
        ...common,
        p_project_name: projectName,
        p_configuration: config,
        p_estimated_price: price.total,
        p_cost_breakdown: price,
        p_preview_image: previewImage,
      },
      url,
      serviceKey,
    );
    return reply({ project });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.name === "SyntaxError" || error.message.startsWith("Configuração inválida"))
    )
      return reply({ error: error.message }, 400);
    console.error("tenant-project failed", error instanceof Error ? error.name : "UnknownError");
    return reply(
      { error: error instanceof Error ? error.message : "Não foi possível acessar o projeto." },
      503,
    );
  }
});
