alter table public.projects
  add column if not exists project_name text,
  add column if not exists updated_at timestamptz not null default now(),
  add column if not exists cost_breakdown jsonb not null default '{}'::jsonb,
  add column if not exists preview_image text;

alter table public.projects drop constraint if exists projects_preview_image_check;
alter table public.projects add constraint projects_preview_image_check
  check (preview_image is null or (length(preview_image) <= 700000 and preview_image like 'data:image/jpeg;base64,%'));

alter table public.projects
  add column if not exists customer_name text generated always as (coalesce(customer->>'name','')) stored,
  add column if not exists customer_contact text generated always as (coalesce(customer->>'phone','') || ' ' || coalesce(customer->>'email','')) stored;

update public.projects set updated_at = created_at where updated_at is null;

alter table public.projects
  add constraint projects_cost_breakdown_object
  check (jsonb_typeof(cost_breakdown) = 'object');

create index if not exists projects_org_updated_idx
  on public.projects (organization_id, updated_at desc);
create index if not exists projects_user_updated_idx
  on public.projects (user_id, updated_at desc);
create index if not exists projects_org_customer_name_idx
  on public.projects (organization_id, lower(customer_name));
create index if not exists projects_org_customer_contact_idx
  on public.projects (organization_id, lower(customer_contact));

create table if not exists public.project_guest_tokens (
  project_id uuid primary key references public.projects(id) on delete cascade,
  token_hash text not null unique check (token_hash ~ '^[0-9a-f]{64}$'),
  created_at timestamptz not null default now()
);
alter table public.project_guest_tokens enable row level security;
revoke all on public.project_guest_tokens from public, anon, authenticated;
grant all on public.project_guest_tokens to service_role;

create table if not exists public.project_revisions (
  id bigint generated always as identity primary key,
  project_id uuid not null references public.projects(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete cascade,
  revision integer not null check (revision > 0),
  snapshot jsonb not null check (jsonb_typeof(snapshot) = 'object'),
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(project_id, revision)
);
create index if not exists project_revisions_project_date_idx
  on public.project_revisions(project_id, created_at desc);
alter table public.project_revisions enable row level security;
grant select on public.project_revisions to authenticated;
create policy project_revisions_read on public.project_revisions for select to authenticated
  using (exists (
    select 1 from public.projects p
    where p.id = project_id
      and ((p.organization_id is null and p.user_id = (select auth.uid()))
        or p.user_id = (select auth.uid())
        or app_private.member_role(p.organization_id) in ('OWNER','ADMIN','STAFF'))
  ));

create policy projects_customer_own on public.projects for all to authenticated
  using (organization_id is not null and user_id=(select auth.uid())
    and app_private.member_role(organization_id)='CUSTOMER')
  with check (organization_id is not null and user_id=(select auth.uid())
    and app_private.member_role(organization_id)='CUSTOMER');

create or replace function app_private.touch_project_updated()
returns trigger language plpgsql set search_path='' as $$
begin
  new.updated_at = now();
  return new;
end $$;
revoke all on function app_private.touch_project_updated() from public;
drop trigger if exists projects_touch_updated on public.projects;
create trigger projects_touch_updated before update on public.projects
  for each row execute function app_private.touch_project_updated();

create or replace function app_private.guard_project_integrity() returns trigger
language plpgsql security definer set search_path='' as $$
declare field text;
begin
  if new.preview_image is not null and (length(new.preview_image)>700000 or new.preview_image not like 'data:image/jpeg;base64,%') then
    raise exception 'Imagem de pré-visualização inválida' using errcode='22023';
  end if;
  if tg_op='UPDATE' and new.organization_id is distinct from old.organization_id then
    raise exception 'O vínculo do projeto com a marcenaria não pode ser alterado';
  end if;
  if tg_op='UPDATE' and new.user_id is distinct from old.user_id
     and not (old.user_id is null and new.user_id=(select auth.uid())
       and app_private.member_role(old.organization_id)='CUSTOMER') then
    raise exception 'O autor do projeto não pode ser alterado';
  end if;
  if tg_op='INSERT' or new.config is distinct from old.config then
    if not app_private.valid_furniture_configuration(new.config) then raise exception 'Configuração inválida'; end if;
  end if;
  if new.customer is not null and (tg_op='INSERT' or new.customer is distinct from old.customer) then
    if jsonb_typeof(new.customer)<>'object' or octet_length(new.customer::text)>10000 then raise exception 'Dados do cliente inválidos'; end if;
    foreach field in array array['name','phone','email','city','notes'] loop
      if new.customer ? field and jsonb_typeof(new.customer->field) is distinct from 'string' then raise exception 'Dados do cliente inválidos'; end if;
    end loop;
  end if;
  return new;
end $$;
revoke all on function app_private.guard_project_integrity() from public;

create or replace function app_private.capture_project_revision()
returns trigger language plpgsql security definer set search_path='' as $$
declare next_revision integer;
begin
  if tg_op = 'UPDATE'
     and new.config is not distinct from old.config
     and new.price is not distinct from old.price
     and new.cost_breakdown is not distinct from old.cost_breakdown
     and new.customer is not distinct from old.customer
     and new.status is not distinct from old.status
     and new.project_name is not distinct from old.project_name
     and new.preview_image is not distinct from old.preview_image then
    return new;
  end if;
  select coalesce(max(r.revision), 0) + 1 into next_revision
    from public.project_revisions r where r.project_id = new.id;
  insert into public.project_revisions(project_id, organization_id, revision, snapshot, changed_by)
  values (
    new.id,
    new.organization_id,
    next_revision,
    jsonb_build_object(
      'code', new.code,
      'project_name', new.project_name,
      'config', new.config,
      'price', new.price,
      'cost_breakdown', new.cost_breakdown,
      'customer', new.customer,
      'status', new.status,
      'preview_image', new.preview_image,
      'created_at', new.created_at,
      'updated_at', new.updated_at
    ),
    auth.uid()
  );
  return new;
end $$;
revoke all on function app_private.capture_project_revision() from public;
drop trigger if exists projects_capture_revision on public.projects;
create trigger projects_capture_revision after insert or update of config, price, cost_breakdown, customer, status, project_name, preview_image
  on public.projects for each row execute function app_private.capture_project_revision();

insert into public.project_revisions(project_id, organization_id, revision, snapshot, changed_by, created_at)
select p.id, p.organization_id, 1,
  jsonb_build_object(
    'code',p.code,'project_name',p.project_name,'config',p.config,'price',p.price,
    'cost_breakdown',p.cost_breakdown,'customer',p.customer,'status',p.status,'preview_image',p.preview_image,
    'created_at',p.created_at,'updated_at',p.updated_at
  ), null, coalesce(p.updated_at,p.created_at)
from public.projects p
where not exists (select 1 from public.project_revisions r where r.project_id=p.id);

-- Add the requested lifecycle without reinterpreting legacy lead states.
alter table public.leads drop constraint if exists leads_status_check;
alter table public.leads add constraint leads_status_check
  check (status in ('Novo pedido','Em análise','Proposta enviada','Aprovado','Recusado','Concluído',
                    'Novo','Em contato','Orçamento enviado','Fechado','Perdido'));
alter table public.leads alter column status set default 'Novo pedido';

-- The earlier validator predates several currently exposed furniture templates.
-- Change only its type allowlist; retain its dimension/material/component checks.
do $$
declare current_definition text; updated_definition text;
begin
  select pg_get_functiondef('app_private.valid_furniture_configuration(jsonb,integer)'::regprocedure)
    into current_definition;
  if position('''mesa-jantar-redonda''' in current_definition) = 0 then
    updated_definition := replace(
      current_definition,
      '''banco-baú-hall'''])) then return false; end if;',
      '''banco-baú-hall'',''mesa-redonda'',''mesa-jantar'',''mesa-oval'',''mesa-organica'',''cadeira'',''banco'',''banqueta'',''aparador-organico'',''ilha-gourmet'',''mesa-jantar-redonda'',''mesa-jantar-oval'',''mesa-centro-organica'',''cadeira-estofada'',''banco-linear'',''banqueta-ilha'''])) then return false; end if;'
    );
    if updated_definition = current_definition then
      raise exception 'Não foi possível localizar o fim da lista de modelos na validação SQL';
    end if;
    execute updated_definition;
  end if;
end $$;

-- Atomic, service-role-only operations for visitor projects. Raw access tokens never reach the DB.
create or replace function public.create_guest_project(
  p_tenant_slug text,
  p_project_name text,
  p_configuration jsonb,
  p_estimated_price numeric,
  p_cost_breakdown jsonb,
  p_preview_image text,
  p_token_hash text
) returns jsonb language plpgsql security definer set search_path='' as $$
declare org uuid; pid uuid := gen_random_uuid(); normalized_code text;
begin
  select id into org from public.organizations where slug=p_tenant_slug and published=true;
  if org is null then raise exception 'Marcenaria indisponível'; end if;
  if not app_private.valid_furniture_configuration(p_configuration) then raise exception 'Configuração inválida'; end if;
  if p_estimated_price is null or p_estimated_price not between 0 and 100000000 then raise exception 'Estimativa inválida'; end if;
  if p_cost_breakdown is null or jsonb_typeof(p_cost_breakdown) <> 'object' then raise exception 'Detalhamento de custos inválido'; end if;
  if p_preview_image is not null and (length(p_preview_image)>700000 or p_preview_image not like 'data:image/jpeg;base64,%') then raise exception 'Imagem de pré-visualização inválida'; end if;
  if p_token_hash is null or p_token_hash !~ '^[0-9a-f]{64}$' then raise exception 'Credencial inválida'; end if;
  perform pg_advisory_xact_lock(hashtextextended(org::text,0));
  if (select count(*) from public.projects where organization_id=org and status='Rascunho' and created_at>now()-interval '1 minute')>=50 then
    raise exception 'Muitas criações de projetos. Aguarde um minuto e tente novamente';
  end if;
  normalized_code := 'M3D-' || to_char(now(),'YYYY') || '-' || upper(substr(replace(pid::text,'-',''),1,12));
  insert into public.projects(id, organization_id, user_id, code, project_name, config, price, cost_breakdown, preview_image, status)
    values(pid, org, null, normalized_code, nullif(left(trim(coalesce(p_project_name,'')),120),''), p_configuration, p_estimated_price, p_cost_breakdown, p_preview_image, 'Rascunho');
  insert into public.project_guest_tokens(project_id, token_hash) values(pid, p_token_hash);
  return jsonb_build_object('id',pid,'code',normalized_code,'created_at',now(),'updated_at',now());
end $$;

create or replace function public.read_guest_project(
  p_tenant_slug text, p_project_id uuid, p_token_hash text
) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  select jsonb_build_object(
    'id',p.id,'code',p.code,'project_name',p.project_name,'created_at',p.created_at,'updated_at',p.updated_at,
    'config',p.config,'price',p.price,'cost_breakdown',p.cost_breakdown,'preview_image',p.preview_image,'status',p.status,'organization_id',p.organization_id
  ) into result
  from public.projects p
  join public.organizations o on o.id=p.organization_id
  join public.project_guest_tokens t on t.project_id=p.id
  where p.id=p_project_id and o.slug=p_tenant_slug and t.token_hash=p_token_hash
    and p.user_id is null;
  if result is null then raise exception 'Projeto não encontrado ou credencial inválida'; end if;
  return result;
end $$;

create or replace function public.update_guest_project(
  p_tenant_slug text, p_project_id uuid, p_token_hash text,
  p_project_name text, p_configuration jsonb, p_estimated_price numeric, p_cost_breakdown jsonb, p_preview_image text
) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if not app_private.valid_furniture_configuration(p_configuration) then raise exception 'Configuração inválida'; end if;
  if p_estimated_price is null or p_estimated_price not between 0 and 100000000 then raise exception 'Estimativa inválida'; end if;
  if p_cost_breakdown is null or jsonb_typeof(p_cost_breakdown) <> 'object' then raise exception 'Detalhamento de custos inválido'; end if;
  if p_preview_image is not null and (length(p_preview_image)>700000 or p_preview_image not like 'data:image/jpeg;base64,%') then raise exception 'Imagem de pré-visualização inválida'; end if;
  update public.projects p set
    project_name=nullif(left(trim(coalesce(p_project_name,'')),120),''),
    config=p_configuration, price=p_estimated_price, cost_breakdown=p_cost_breakdown,
    preview_image=coalesce(p_preview_image,p.preview_image)
  from public.organizations o, public.project_guest_tokens t
  where p.id=p_project_id and p.organization_id=o.id and o.slug=p_tenant_slug
    and t.project_id=p.id and t.token_hash=p_token_hash and p.user_id is null
  returning jsonb_build_object('id',p.id,'code',p.code,'created_at',p.created_at,'updated_at',p.updated_at,'preview_image',p.preview_image) into result;
  if result is null then raise exception 'Projeto não encontrado ou credencial inválida'; end if;
  return result;
end $$;

create or replace function public.delete_guest_project(
  p_tenant_slug text, p_project_id uuid, p_token_hash text
) returns boolean language plpgsql security definer set search_path='' as $$
declare deleted_id uuid;
begin
  delete from public.projects p using public.organizations o, public.project_guest_tokens t
  where p.id=p_project_id and p.organization_id=o.id and o.slug=p_tenant_slug
    and t.project_id=p.id and t.token_hash=p_token_hash and p.user_id is null
  returning p.id into deleted_id;
  if deleted_id is null then raise exception 'Projeto não encontrado ou credencial inválida'; end if;
  return true;
end $$;

-- The quote and its full server-computed cost breakdown are committed together.
create or replace function public.submit_tenant_quote_v2(
  tenant_slug text, configuration jsonb, estimated_price numeric,
  price_breakdown jsonb, customer_data jsonb, p_preview_image text
) returns jsonb language plpgsql security definer set search_path='' as $$
declare org uuid; pid uuid:=gen_random_uuid(); pcode text; cname text; cphone text;
begin
  select id into org from public.organizations where slug=tenant_slug and published=true;
  if org is null then raise exception 'Marcenaria indisponível'; end if;
  if customer_data is null or jsonb_typeof(customer_data)<>'object' or octet_length(customer_data::text)>10000 then raise exception 'Dados do cliente inválidos'; end if;
  cname:=trim(customer_data->>'name'); cphone:=regexp_replace(customer_data->>'phone','[^0-9]','','g');
  if cname is null or length(cname) not between 2 and 120 or cphone is null or length(cphone) not between 10 and 15 then raise exception 'Informe nome e telefone com DDD válidos'; end if;
  if length(cphone) in (10,11) then cphone:='55'||cphone; end if;
  if not app_private.valid_furniture_configuration(configuration) then raise exception 'Configuração inválida'; end if;
  if estimated_price is null or estimated_price not between 0 and 100000000 then raise exception 'Estimativa inválida'; end if;
  if price_breakdown is null or jsonb_typeof(price_breakdown)<>'object' or (price_breakdown->>'total')::numeric is distinct from estimated_price then raise exception 'Detalhamento de custos inválido'; end if;
  if p_preview_image is not null and (length(p_preview_image)>700000 or p_preview_image not like 'data:image/jpeg;base64,%') then raise exception 'Imagem de pré-visualização inválida'; end if;
  perform pg_advisory_xact_lock(hashtextextended(org::text,0));
  if (select count(*) from public.projects where organization_id=org and status='Orçamento' and created_at>now()-interval '1 minute')>=30 then raise exception 'Muitas solicitações. Aguarde um minuto e tente novamente'; end if;
  if (select count(*) from public.leads where organization_id=org and phone=cphone and created_at>now()-interval '10 minutes')>=5 then raise exception 'Você já enviou várias propostas. Aguarde alguns minutos'; end if;
  pcode:=customer_data->>'proposal_code';
  if pcode is null or pcode !~ '^M3D-[0-9]{4}-[A-F0-9]{12}$' then pcode:='M3D-'||to_char(now(),'YYYY')||'-'||upper(substr(replace(pid::text,'-',''),1,12)); end if;
  if exists(select 1 from public.projects where organization_id=org and code=pcode) then raise exception 'Esta proposta já foi enviada. Confira seus projetos'; end if;
  insert into public.projects(id,organization_id,user_id,code,config,price,cost_breakdown,customer,preview_image,status)
    values(pid,org,null,pcode,configuration,estimated_price,price_breakdown,(customer_data-'proposal_code')||jsonb_build_object('phone',cphone),p_preview_image,'Orçamento');
  insert into public.leads(organization_id,project_id,name,phone,email)
    values(org,pid,cname,cphone,left(customer_data->>'email',254));
  return jsonb_build_object('id',pid,'code',pcode,'price',estimated_price);
end $$;

create or replace function public.claim_guest_project(
  p_tenant_slug text, p_project_id uuid, p_token_hash text
) returns boolean language plpgsql security definer set search_path='' as $$
declare org uuid;
begin
  if auth.uid() is null then raise exception 'Autenticação necessária'; end if;
  select id into org from public.organizations where slug=p_tenant_slug;
  if org is null or app_private.member_role(org) <> 'CUSTOMER' then raise exception 'Conta de cliente não vinculada a esta marcenaria'; end if;
  update public.projects p set user_id=auth.uid()
    from public.project_guest_tokens t
    where p.id=p_project_id and p.organization_id=org and p.user_id is null
      and t.project_id=p.id and t.token_hash=p_token_hash;
  if not found then raise exception 'Projeto não encontrado ou credencial inválida'; end if;
  delete from public.project_guest_tokens where project_id=p_project_id;
  return true;
end $$;

revoke all on function public.create_guest_project(text,text,jsonb,numeric,jsonb,text,text) from public, anon, authenticated;
revoke all on function public.read_guest_project(text,uuid,text) from public, anon, authenticated;
revoke all on function public.update_guest_project(text,uuid,text,text,jsonb,numeric,jsonb,text) from public, anon, authenticated;
revoke all on function public.delete_guest_project(text,uuid,text) from public, anon, authenticated;
revoke all on function public.submit_tenant_quote_v2(text,jsonb,numeric,jsonb,jsonb,text) from public, anon, authenticated;
revoke all on function public.claim_guest_project(text,uuid,text) from public, anon;
grant execute on function public.create_guest_project(text,text,jsonb,numeric,jsonb,text,text) to service_role;
grant execute on function public.read_guest_project(text,uuid,text) to service_role;
grant execute on function public.update_guest_project(text,uuid,text,text,jsonb,numeric,jsonb,text) to service_role;
grant execute on function public.delete_guest_project(text,uuid,text) to service_role;
grant execute on function public.submit_tenant_quote_v2(text,jsonb,numeric,jsonb,jsonb,text) to service_role;
grant execute on function public.claim_guest_project(text,uuid,text) to authenticated;
