import type { AccessoryId, FurnitureConfig, MaterialSet, Part } from "./types";
import { typeDef } from "./types";

const BACK_T = 0.6;

export const DEFAULT_MATERIALS: MaterialSet = {
  estrutura: "carvalho",
  portas: "carvalho",
  interior: "branco",
  fundo: "branco",
};

/** Older saved projects only carry a subset of the config. Fill the gaps so the
 *  builder can always assume a complete object. */
export function normalizeConfig(cfg: Partial<FurnitureConfig> & { type: FurnitureConfig["type"] }): FurnitureConfig {
  const base = cfg.material ?? "carvalho";
  return {
    columns: 3,
    doors: 2,
    doorStyle: "simples",
    doorFace: "padrao",
    drawers: 0,
    drawerHeight: 0,
    drawerGlassFront: false,
    shelves: 0,
    shelfMaterial: "mdf",
    niches: 0,
    hanger: false,
    mirror: false,
    mirrorInside: false,
    width: 240,
    height: 220,
    depth: 60,
    panelThickness: 1.8,
    showDimensions: false,
    openDoors: false,
    material: base,
    accessories: [],
    handle: { model: "reto", finish: "preto", orientation: "vertical", size: 20 },
    led: { on: false, intensity: 1, temp: 3000 },
    ...cfg,
    materials: {
      estrutura: base,
      portas: base,
      interior: "branco",
      fundo: "branco",
      ...(cfg.materials ?? {}),
    },
  } as FurnitureConfig;
}

/**
 * Parametric furniture builder: turns a plain config object into a list of
 * physical parts (position + size in cm). Adding a new furniture type only
 * requires new rules here — the 3D layer just renders parts.
 */
export function buildFurniture(input: FurnitureConfig): Part[] {
  const cfg = input.materials ? input : normalizeConfig(input);
  const { width: W, height: H, depth: D, panelThickness: t } = cfg;
  const M = cfg.materials;
  const parts: Part[] = [];
  const push = (p: Part) => parts.push(p);
  const has = (a: AccessoryId) => cfg.accessories?.includes(a);

  // ---- carcass -------------------------------------------------------------
  push({
    id: "lateral-esq",
    kind: "lateral",
    label: "Lateral esquerda",
    pos: [-W / 2 + t / 2, H / 2, 0],
    size: [t, H, D],
    material: M.estrutura,
  });
  push({
    id: "lateral-dir",
    kind: "lateral",
    label: "Lateral direita",
    pos: [W / 2 - t / 2, H / 2, 0],
    size: [t, H, D],
    material: M.estrutura,
  });

  const innerW = W - 2 * t;
  push({ id: "tampo", kind: "tampo", label: "Tampo", pos: [0, H - t / 2, 0], size: [innerW, t, D], material: M.estrutura });
  push({ id: "base", kind: "base", label: "Base", pos: [0, t / 2, 0], size: [innerW, t, D], material: M.estrutura });
  push({
    id: "fundo",
    kind: "fundo",
    label: "Fundo",
    pos: [0, H / 2, -D / 2 + BACK_T / 2],
    size: [W, H, BACK_T],
    material: M.fundo,
  });

  // ---- columns / dividers -------------------------------------------------
  const cols = Math.max(1, Math.round(cfg.columns));
  const colW = (innerW - (cols - 1) * t) / cols;
  const colCenter = (i: number) => -innerW / 2 + colW / 2 + i * (colW + t);

  for (let i = 1; i < cols; i++) {
    push({
      id: `divisoria-${i}`,
      kind: "divisoria",
      label: `Divisória ${i}`,
      pos: [colCenter(i) - colW / 2 - t / 2, H / 2, 0],
      size: [t, H - 2 * t, D],
      material: M.interior,
      removable: true,
    });
  }

  const innerH = H - 2 * t;
  const innerBottom = t;

  // ---- drawers (stacked at the bottom of column 0) ------------------------
  const drawers = Math.max(0, Math.round(cfg.drawers));
  const drawerH =
    cfg.drawerHeight && cfg.drawerHeight > 0
      ? Math.min(cfg.drawerHeight, innerH / 2)
      : Math.min(22, Math.max(12, innerH / Math.max(drawers, 1) / 1.6));
  let drawerStackTop = innerBottom;
  const drawerTravel = Math.max(10, D - t - 4);
  for (let i = 0; i < drawers; i++) {
    const col = i % cols;
    const idx = Math.floor(i / cols);
    const y = innerBottom + idx * (drawerH + 0.4) + drawerH / 2;
    if (y + drawerH / 2 > innerBottom + innerH) break;
    drawerStackTop = Math.max(drawerStackTop, y + drawerH / 2 + 0.4);
    const front: Part = {
      id: `gaveta-${i}`,
      kind: "gaveta",
      label: `Gaveta ${i + 1}`,
      pos: [colCenter(col), y, D / 2 - t / 2],
      size: [colW - 0.6, drawerH, t],
      material: cfg.drawerGlassFront ? "vidro" : M.portas,
      drawer: true,
      interactive: true,
      travel: drawerTravel,
      removable: true,
    };
    push(front);
    pushHandle(front, "gaveta");
  }

  // ---- shelves ------------------------------------------------------------
  const shelfMat = cfg.shelfMaterial === "vidro" ? "vidro" : M.interior;
  const shelves = Math.max(0, Math.round(cfg.shelves));
  const perCol = Math.ceil(shelves / cols);
  const shelfYs: [number, number][] = []; // [x, y] for LED strips
  let placed = 0;
  for (let c = 0; c < cols && placed < shelves; c++) {
    const zoneBottom = drawers > 0 ? drawerStackTop : innerBottom;
    const zoneTop = innerBottom + innerH - (cfg.hanger && c === cols - 1 ? 110 : 0);
    const zoneH = Math.max(zoneTop - zoneBottom, 20);
    const n = Math.min(perCol, shelves - placed);
    for (let s = 0; s < n; s++) {
      const y = zoneBottom + ((s + 1) * zoneH) / (n + 1);
      push({
        id: `prateleira-${c}-${s}`,
        kind: "prateleira",
        label: `Prateleira ${placed + 1}`,
        pos: [colCenter(c), y, BACK_T / 2],
        size: [colW - 0.4, cfg.shelfMaterial === "vidro" ? 0.8 : t, D - BACK_T - 2],
        material: shelfMat,
        removable: true,
      });
      shelfYs.push([colCenter(c), y]);
      placed++;
    }
  }

  // ---- niches (open frames on the top row) --------------------------------
  const niches = Math.max(0, Math.round(cfg.niches));
  for (let i = 0; i < niches; i++) {
    const y = innerBottom + innerH - 18 - i * 26;
    if (y < innerBottom + 20) break;
    push({
      id: `nicho-${i}`,
      kind: "nicho",
      label: `Nicho ${i + 1}`,
      pos: [colCenter(i % cols), y, BACK_T / 2],
      size: [colW - 0.4, t, D - BACK_T - 6],
      material: M.interior,
      removable: true,
    });
    shelfYs.push([colCenter(i % cols), y]);
  }

  // ---- hanger rod + hangers ----------------------------------------------
  if (cfg.hanger) {
    const rodY = innerBottom + innerH - 8;
    const rodX = colCenter(cols - 1);
    push({
      id: "cabideiro",
      kind: "cabideiro",
      label: "Cabideiro",
      pos: [rodX, rodY, 0],
      size: [colW - 1.5, 2.5, 2.5],
      removable: true,
    });
    const hangerW = Math.max(26, Math.min(D - 14, 44)); // along Z
    const hangerH = Math.min(34, innerH * 0.22);
    const usableSpan = Math.max(colW - 10, 6);
    const count = Math.max(2, Math.min(8, Math.floor(usableSpan / 7)));
    const step = usableSpan / count;
    for (let i = 0; i < count; i++) {
      push({
        id: `cabide-${i}`,
        kind: "cabide",
        label: `Cabide ${i + 1}`,
        pos: [rodX - usableSpan / 2 + step / 2 + i * step, rodY - hangerH / 2 - 1, 0],
        size: [1.2, hangerH, hangerW],
      });
    }
  }

  // ---- accessories --------------------------------------------------------
  const accCol = (i: number) => colCenter(Math.min(cols - 1, i));
  if (has("sapateira")) {
    for (let i = 0; i < 3; i++) {
      push({
        id: `acc-sapateira-${i}`,
        kind: "acessorio",
        label: `Sapateira ${i + 1}`,
        pos: [accCol(0), innerBottom + 24 + i * 22, BACK_T / 2 + 2],
        size: [colW - 1, 1.6, Math.min(D - 8, 30)],
        material: M.interior,
        shape: "inclinada",
        removable: true,
      });
    }
  }
  if (has("calceiro")) {
    push({
      id: "acc-calceiro",
      kind: "acessorio",
      label: "Calceiro",
      pos: [accCol(cols - 1), innerBottom + innerH * 0.45, 0],
      size: [colW - 4, 2, 2],
      shape: "tubo",
      removable: true,
    });
  }
  if (has("cabideiro-retratil")) {
    push({
      id: "acc-cabideiro-retratil",
      kind: "acessorio",
      label: "Cabideiro retrátil",
      pos: [accCol(0), innerBottom + innerH * 0.72, 0],
      size: [colW - 4, 2, 2],
      shape: "tubo",
      removable: true,
    });
  }
  if (has("divisorias")) {
    push({
      id: "acc-divisoria",
      kind: "acessorio",
      label: "Divisória interna",
      pos: [accCol(0), innerBottom + innerH * 0.55, BACK_T / 2],
      size: [1.2, Math.min(innerH * 0.35, 60), D - BACK_T - 4],
      material: M.interior,
      shape: "placa",
      removable: true,
    });
  }
  if (has("gavetas-internas")) {
    for (let i = 0; i < 2; i++) {
      push({
        id: `acc-gaveta-interna-${i}`,
        kind: "acessorio",
        label: `Gaveta interna ${i + 1}`,
        pos: [accCol(1), innerBottom + innerH * 0.35 + i * 16, D / 2 - t - 6],
        size: [colW - 4, 13, Math.max(D - 12, 20)],
        material: M.interior,
        shape: "caixa",
        removable: true,
      });
    }
  }
  if (has("organizador")) {
    push({
      id: "acc-organizador",
      kind: "acessorio",
      label: "Organizador",
      pos: [accCol(1), innerBottom + innerH * 0.2, D / 2 - t - 8],
      size: [Math.min(colW - 4, 40), 9, Math.max(D - 16, 18)],
      material: M.interior,
      shape: "caixa",
      removable: true,
    });
  }
  if (has("porta-temperos")) {
    push({
      id: "acc-temperos",
      kind: "acessorio",
      label: "Porta-temperos",
      pos: [accCol(0), innerBottom + innerH * 0.6, D / 2 - t - 5],
      size: [Math.min(colW - 6, 25), 10, 10],
      material: M.interior,
      shape: "caixa",
      removable: true,
    });
  }
  if (has("lixeira")) {
    push({
      id: "acc-lixeira",
      kind: "acessorio",
      label: "Lixeira embutida",
      pos: [accCol(cols - 1), innerBottom + 16, 0],
      size: [Math.min(colW - 6, 30), 32, Math.min(D - 14, 34)],
      shape: "caixa",
      material: "cinza",
      removable: true,
    });
  }
  if (has("torre-tomadas")) {
    push({
      id: "acc-tomadas",
      kind: "acessorio",
      label: "Torre de tomadas",
      pos: [colCenter(cols - 1), H + 7, 0],
      size: [8, 14, 8],
      shape: "tubo",
      material: "preto",
      removable: true,
    });
  }
  if (has("painel-ripado")) {
    push({
      id: "acc-ripado",
      kind: "acessorio",
      label: "Painel ripado",
      pos: [0, H / 2, -D / 2 - 1],
      size: [W, H * 0.9, 2],
      shape: "ripado",
      material: M.portas,
      removable: true,
    });
  }
  if (has("suporte-tv")) {
    push({
      id: "acc-suporte-tv",
      kind: "acessorio",
      label: "Suporte para TV",
      pos: [0, H + 45, -D / 2 + 2],
      size: [Math.min(W * 0.75, 120), 70, 3],
      shape: "placa",
      material: "preto",
      removable: true,
    });
  }
  if (has("passagem-cabos")) {
    push({
      id: "acc-cabos",
      kind: "acessorio",
      label: "Passagem de cabos",
      pos: [colCenter(cols - 1), H - t - 1, -D / 2 + 6],
      size: [8, 1, 8],
      shape: "placa",
      material: "preto",
      removable: true,
    });
  }
  if (has("suporte-monitor")) {
    push({
      id: "acc-monitor",
      kind: "acessorio",
      label: "Suporte para monitor",
      pos: [0, H + 6, -D / 4],
      size: [Math.min(W * 0.5, 60), 12, Math.min(D * 0.5, 22)],
      shape: "caixa",
      material: M.estrutura,
      removable: true,
    });
  }

  // ---- internal mirror ----------------------------------------------------
  if (cfg.mirrorInside) {
    push({
      id: "espelho-interno",
      kind: "espelho",
      label: "Espelho interno",
      pos: [colCenter(0), innerBottom + innerH / 2, -D / 2 + BACK_T + 0.4],
      size: [Math.max(colW - 6, 10), Math.min(innerH - 10, 150), 0.5],
      removable: true,
    });
  }

  // ---- LED ----------------------------------------------------------------
  if (cfg.led?.on) {
    const strips: [number, number, number, number][] = []; // x, y, z, width
    strips.push([0, H - t - 1.2, D / 2 - 6, innerW - 2]);
    shelfYs.slice(0, 6).forEach(([x, y]) => strips.push([x, y - 1.2, D / 2 - 6, colW - 4]));
    strips.forEach(([x, y, z, w], i) =>
      push({
        id: `led-${i}`,
        kind: "led",
        label: `LED ${i + 1}`,
        pos: [x, y, z],
        size: [Math.max(w, 6), 1, 1.4],
        led: { intensity: cfg.led.intensity, temp: cfg.led.temp },
      }),
    );
  }

  // ---- doors --------------------------------------------------------------
  const doors = Math.max(0, Math.round(cfg.doors));
  const sliding = cfg.doorStyle === "correr";
  const tilt = cfg.doorStyle === "basculante";
  const doorMat = cfg.doorFace === "vidro" ? "vidro" : cfg.doorFace === "espelho" ? "espelho" : M.portas;
  let frontDoor: Part | null = null;
  if (doors > 0 && sliding) {
    const panels = Math.max(2, doors);
    const overlap = 2;
    const panelW = (W + overlap * (panels - 1)) / panels;
    const doorH = H - 1;
    const half = (W - panelW) / 2;
    for (let i = 0; i < panels; i++) {
      const track = i % 2;
      const closedX = -W / 2 + panelW / 2 + i * (panelW - overlap);
      const dir = i < panels / 2 ? 1 : -1;
      const openX = Math.max(-half, Math.min(half, closedX + dir * (panelW - overlap)));
      const p: Part = {
        id: `porta-${i}`,
        kind: "porta",
        label: `Porta de correr ${i + 1}`,
        pos: [closedX, doorH / 2 + 0.5, D / 2 + 1.4 + track * (t + 0.8)],
        size: [panelW, doorH, t],
        material: doorMat,
        face: cfg.doorFace,
        sliding: true,
        slideTo: openX,
        interactive: true,
        removable: true,
      };
      push(p);
      pushHandle(p, "porta");
      if (!frontDoor) frontDoor = p;
    }
  } else if (doors > 0) {
    const doorW = W / doors - 0.3;
    const startY = drawers > 0 ? drawerStackTop : 0;
    const topY = H;
    const usableH = topY - startY - 0.3;
    for (let i = 0; i < doors; i++) {
      const x = -W / 2 + W / doors / 2 + i * (W / doors);
      const hinge: -1 | 1 =
        cfg.doorStyle === "dupla" ? (i % 2 === 0 ? -1 : 1) : i < doors / 2 ? -1 : 1;
      // opening limit: never past 110°, and reduced when doors sit side by side
      const openLimit = tilt ? 85 : doors > 1 ? 100 : 110;
      const p: Part = {
        id: `porta-${i}`,
        kind: "porta",
        label: tilt ? `Porta basculante ${i + 1}` : `Porta ${i + 1}`,
        pos: [x, startY + usableH / 2 + 0.15, D / 2 + t / 2],
        size: [doorW, usableH, t],
        material: doorMat,
        face: cfg.doorFace,
        hinge,
        tilt,
        bifold: cfg.doorStyle === "camarao",
        openLimit,
        interactive: true,
        removable: true,
      };
      push(p);
      pushHandle(p, "porta");
      if (!frontDoor) frontDoor = p;
    }
  }

  // ---- mirror -------------------------------------------------------------
  if (cfg.mirror) {
    if (frontDoor) {
      const [dw, dh] = frontDoor.size;
      push({
        id: "espelho",
        kind: "espelho",
        label: "Espelho",
        parent: frontDoor.id,
        pos: [0, 0, frontDoor.size[2] / 2 + 0.3],
        size: [Math.max(dw - 8, 10), Math.max(dh - 10, 10), 0.5],
        removable: true,
      });
    } else {
      push({
        id: "espelho",
        kind: "espelho",
        label: "Espelho",
        pos: [0, H / 2, D / 2 + 0.6],
        size: [Math.min(W - 12, 70), Math.min(H - 20, 140), 0.6],
        removable: true,
      });
    }
  }

  return parts;

  /** handles are mounted on their door/drawer so they follow the animation */
  function pushHandle(host: Part, kind: "porta" | "gaveta") {
    const h = cfg.handle;
    if (!h || h.model === "nenhum") return;
    const [hw, hh, ht] = host.size;
    const vertical = kind === "porta" ? h.orientation === "vertical" : false;
    const len = Math.max(6, Math.min(h.size || 20, vertical ? hh - 8 : hw - 6));
    const edge = kind === "porta" ? (host.hinge === 1 ? -1 : 1) : 0;
    const px = kind === "porta" ? edge * (hw / 2 - 4) : 0;
    const py = kind === "porta" ? (vertical ? 0 : -hh / 2 + 8) : 0;
    push({
      id: `puxador-${host.id}`,
      kind: "puxador",
      label: `Puxador · ${host.label}`,
      parent: host.id,
      pos: [px, py, ht / 2 + 0.2],
      size: vertical ? [2.4, len, 3.2] : [len, 2.4, 3.2],
      handle: { model: h.model, finish: h.finish, orientation: vertical ? "vertical" : "horizontal" },
    });
  }
}

export interface ValidationIssue {
  level: "error" | "warning";
  message: string;
}

export function validate(cfg: FurnitureConfig): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const def = typeDef(cfg.type);
  const [wMin, wMax] = def.limits.width;
  const [hMin, hMax] = def.limits.height;
  const [dMin, dMax] = def.limits.depth;

  if (cfg.width < wMin || cfg.width > wMax)
    issues.push({ level: "error", message: `A largura deve ficar entre ${wMin} e ${wMax} cm.` });
  if (cfg.height < hMin || cfg.height > hMax)
    issues.push({ level: "error", message: `A altura deve ficar entre ${hMin} e ${hMax} cm.` });
  if (cfg.depth < dMin || cfg.depth > dMax)
    issues.push({ level: "error", message: `A profundidade deve ficar entre ${dMin} e ${dMax} cm.` });

  if (cfg.drawers > 0 && cfg.depth < def.minDrawerDepth)
    issues.push({
      level: "error",
      message: `Essa configuração não é possível com a profundidade atual: gavetas precisam de pelo menos ${def.minDrawerDepth} cm.`,
    });

  const doorW = cfg.doors > 0 ? cfg.width / cfg.doors : 0;
  if (cfg.doors > 0 && doorW > 70)
    issues.push({
      level: "warning",
      message: `Cada porta ficaria com ${Math.round(doorW)} cm. Acima de 70 cm recomendamos mais portas.`,
    });
  if (cfg.doors > 0 && doorW < 25)
    issues.push({ level: "error", message: "Muitas portas para essa largura — reduza a quantidade." });

  const innerW = cfg.width - 2 * cfg.panelThickness;
  const colW = (innerW - (cfg.columns - 1) * cfg.panelThickness) / cfg.columns;
  if (colW < 25)
    issues.push({ level: "error", message: "Muitos módulos para essa largura — cada módulo ficaria estreito demais." });

  const innerH = cfg.height - 2 * cfg.panelThickness;
  if (cfg.shelves > 0 && innerH / (cfg.shelves / cfg.columns + 1) < 18)
    issues.push({ level: "warning", message: "As prateleiras ficariam muito próximas para essa altura." });

  if (cfg.hanger && cfg.height < 120)
    issues.push({ level: "warning", message: "O cabideiro precisa de pelo menos 120 cm de altura para ser útil." });

  if (cfg.doorStyle === "correr" && cfg.doors > 0 && cfg.width / Math.max(2, cfg.doors) < 40)
    issues.push({ level: "warning", message: "Portas de correr muito estreitas — reduza a quantidade de folhas." });

  return issues;
}
