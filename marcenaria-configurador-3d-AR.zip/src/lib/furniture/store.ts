import { useCallback, useMemo, useState } from "react";
import type { FurnitureConfig, FurnitureType } from "./types";
import { typeDef } from "./types";
import { buildFurniture, normalizeConfig, validate } from "./builder";
import { computePrice, DEFAULT_PRICES } from "./pricing";

export const BASE_CONFIG: FurnitureConfig = normalizeConfig({
  type: "guarda-roupa",
  width: 240,
  height: 220,
  depth: 60,
  columns: 3,
  doors: 4,
  doorStyle: "simples",
  drawers: 3,
  shelves: 6,
  niches: 0,
  hanger: true,
  mirror: false,
  material: "carvalho",
  panelThickness: 1.8,
  showDimensions: false,
  openDoors: false,
});

export interface SavedProject {
  id: string;
  code: string;
  createdAt: string;
  config: FurnitureConfig;
  price: number;
  customer?: { name: string; phone: string; email: string; city: string; notes: string };
  status: string;
}

const STORAGE_KEY = "marcenaria.projects";

export function loadProjects(): SavedProject[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "[]") as SavedProject[];
  } catch {
    return [];
  }
}

export function persistProject(project: SavedProject) {
  const all = loadProjects();
  const next = [project, ...all.filter((p) => p.id !== project.id)];
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return project;
}

export function nextProjectCode() {
  return `Projeto #${String(loadProjects().length + 1).padStart(4, "0")}`;
}

export function useConfigurator(initial: FurnitureConfig = BASE_CONFIG) {
  const [config, setConfig] = useState<FurnitureConfig>(initial);
  const [selected, setSelected] = useState<string | null>(null);

  const set = useCallback(<K extends keyof FurnitureConfig>(key: K, value: FurnitureConfig[K]) => {
    setConfig((c) => ({ ...c, [key]: value }));
  }, []);

  const setType = useCallback((type: FurnitureType) => {
    setConfig((c) => {
      const d = typeDef(type);
      const next = { ...BASE_CONFIG, ...c, type, niches: 0, ...d.defaults };
      // keep dimensions inside the new type's limits
      const clamp = (v: number, [a, b]: [number, number]) => Math.min(b, Math.max(a, v));
      next.width = clamp(next.width, d.limits.width);
      next.height = clamp(next.height, d.limits.height);
      next.depth = clamp(next.depth, d.limits.depth);
      return next;
    });
  }, []);

  const parts = useMemo(() => buildFurniture(config), [config]);
  const issues = useMemo(() => validate(config), [config]);
  const price = useMemo(() => computePrice(config, parts, DEFAULT_PRICES), [config, parts]);

  const removePart = useCallback(
    (id: string) => {
      setSelected(null);
      setConfig((c) => {
        if (id.startsWith("porta")) return { ...c, doors: Math.max(0, c.doors - 1) };
        if (id.startsWith("gaveta")) return { ...c, drawers: Math.max(0, c.drawers - 1) };
        if (id.startsWith("prateleira")) return { ...c, shelves: Math.max(0, c.shelves - 1) };
        if (id.startsWith("divisoria")) return { ...c, columns: Math.max(1, c.columns - 1) };
        if (id.startsWith("nicho")) return { ...c, niches: Math.max(0, c.niches - 1) };
        if (id === "cabideiro") return { ...c, hanger: false };
        if (id === "espelho") return { ...c, mirror: false };
        return c;
      });
    },
    [],
  );

  return { config, setConfig, set, setType, parts, issues, price, selected, setSelected, removePart };
}

export type Configurator = ReturnType<typeof useConfigurator>;
