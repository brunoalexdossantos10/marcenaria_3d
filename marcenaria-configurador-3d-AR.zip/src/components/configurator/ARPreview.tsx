import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import type { FurnitureConfig, Part } from "@/lib/furniture/types";
import { material as materialDef } from "@/lib/furniture/materials";
import { X, Move3D, RotateCw, ScanLine, Smartphone } from "lucide-react";

const S = 0.01;

type ARStatus = "checking" | "unsupported" | "ready" | "placing" | "placed" | "error";

function colorForPart(part: Part, fallback: string) {
  if (part.kind === "espelho") return "#dce6ec";
  if (part.kind === "cabideiro" || part.kind === "cabide") return "#9da5ad";
  if (part.kind === "puxador") {
    const finish = part.handle?.finish;
    return finish === "dourado" ? "#d5a74d" : finish === "bronze" ? "#815a3b" : finish === "preto" ? "#222222" : "#bfc5ca";
  }
  if (part.material) return materialDef(part.material).color;
  return materialDef(fallback).color;
}

function ARFurniture({ parts, config, placed, furnitureRef }: { parts: Part[]; config: FurnitureConfig; placed: boolean; furnitureRef: RefObject<THREE.Group | null> }) {
  const group = useRef<THREE.Group>(null);
  const visibleParts = useMemo(() => parts.filter((p) => !p.parent), [parts]);

  useEffect(() => {
    if (group.current) group.current.visible = placed;
  }, [placed]);

  return (
    <group ref={group}>
      <group ref={(node) => { group.current = node; furnitureRef.current = node; }} visible={placed} position={[0, 0, 0]}>
        {visibleParts.map((part) => (
          <ARPart key={part.id} part={part} config={config} parts={parts} />
        ))}
      </group>
    </group>
  );
}

function ARPart({ part, config, parts }: { part: Part; config: FurnitureConfig; parts: Part[] }) {
  const [w, h, d] = part.size.map((v) => v * S);
  const [x, y, z] = part.pos.map((v) => v * S);
  const color = colorForPart(part, config.material);
  const children = parts.filter((p) => p.parent === part.id);

  const material = part.kind === "espelho" ? (
    <meshPhysicalMaterial color="#eef3f5" roughness={0.02} metalness={1} reflectivity={1} />
  ) : (
    <meshStandardMaterial color={color} roughness={0.42} metalness={part.kind === "puxador" ? 0.8 : 0.04} />
  );

  if (part.kind === "cabideiro") {
    return (
      <group position={[x, y, z]} rotation={[0, 0, Math.PI / 2]}>
        <mesh castShadow>
          <cylinderGeometry args={[Math.max(h / 2, 0.008), Math.max(h / 2, 0.008), w, 16]} />
          <meshStandardMaterial color="#aeb5bc" roughness={0.24} metalness={0.9} />
        </mesh>
      </group>
    );
  }

  if (part.kind === "cabide") {
    return (
      <group position={[x, y, z]}>
        <mesh>
          <boxGeometry args={[Math.max(w, 0.008), h, Math.max(d, 0.008)]} />
          <meshStandardMaterial color="#8b6b47" roughness={0.6} />
        </mesh>
      </group>
    );
  }

  if (part.kind === "puxador") {
    return (
      <mesh position={[x, y, z]} castShadow>
        <boxGeometry args={[Math.max(w, 0.012), Math.max(h, 0.012), Math.max(d, 0.012)]} />
        {material}
      </mesh>
    );
  }

  if (part.kind === "led") {
    const temp = part.led?.temp ?? 3000;
    const t = Math.max(0, Math.min(1, (temp - 2200) / 3800));
    const led = new THREE.Color(1, 0.72 + t * 0.24, 0.45 + t * 0.5);
    return (
      <mesh position={[x, y, z]}>
        <boxGeometry args={[w, Math.max(h, 0.006), Math.max(d, 0.006)]} />
        <meshStandardMaterial color={led} emissive={led} emissiveIntensity={1.8} toneMapped={false} />
      </mesh>
    );
  }

  return (
    <group position={[x, y, z]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[Math.max(w, 0.006), Math.max(h, 0.006), Math.max(d, 0.006)]} />
        {material}
      </mesh>
      {children.map((child) => (
        <ARChild key={child.id} part={child} parent={part} />
      ))}
    </group>
  );
}

function ARChild({ part, parent }: { part: Part; parent: Part }) {
  const [w, h, d] = part.size.map((v) => v * S);
  const [x, y, z] = part.pos.map((v) => v * S);
  const color = colorForPart(part, parent.material ?? "carvalho");
  return (
    <mesh position={[x, y, z]}>
      <boxGeometry args={[Math.max(w, 0.006), Math.max(h, 0.006), Math.max(d, 0.006)]} />
      <meshStandardMaterial color={color} roughness={part.kind === "espelho" ? 0.02 : 0.42} metalness={part.kind === "espelho" ? 1 : 0.04} />
    </mesh>
  );
}

function ARScene({ parts, config, onStatus, onClose }: { parts: Part[]; config: FurnitureConfig; onStatus: (s: ARStatus) => void; onClose: () => void }) {
  const { gl, scene, camera } = useThree();
  const hitTestSource = useRef<any>(null);
  const viewerSpace = useRef<any>(null);
  const localSpace = useRef<any>(null);
  const reticle = useRef<THREE.Mesh>(null);
  const furniture = useRef<THREE.Group>(null);
  const [placed, setPlaced] = useState(false);

  useEffect(() => {
    let disposed = false;
    gl.xr.enabled = true;
    gl.setClearColor(0x000000, 0);
    gl.xr.setReferenceSpaceType("local-floor");

    const start = async () => {
      try {
        const xr = (navigator as Navigator & { xr?: any }).xr;
        if (!xr) {
          onStatus("unsupported");
          return;
        }
        const supported = await xr.isSessionSupported("immersive-ar");
        if (!supported || disposed) {
          onStatus("unsupported");
          return;
        }
        const session = await xr.requestSession("immersive-ar", {
          requiredFeatures: ["hit-test"],
          optionalFeatures: ["local-floor", "dom-overlay"],
          domOverlay: { root: document.body },
        });
        await gl.xr.setSession(session);
        localSpace.current = await session.requestReferenceSpace("local-floor").catch(() => session.requestReferenceSpace("local"));
        viewerSpace.current = await session.requestReferenceSpace("viewer");
        hitTestSource.current = await session.requestHitTestSource({ space: viewerSpace.current });
        onStatus("placing");

        session.addEventListener("end", () => {
          hitTestSource.current?.cancel?.();
          hitTestSource.current = null;
          if (!disposed) onClose();
        });
      } catch (error) {
        console.error("AR session error", error);
        onStatus("error");
      }
    };
    void start();

    return () => {
      disposed = true;
      hitTestSource.current?.cancel?.();
      hitTestSource.current = null;
      if (gl.xr.isPresenting) void gl.xr.getSession()?.end();
      scene.background = null;
      camera.position.set(0, 0, 0);
    };
  }, [camera, gl, onClose, onStatus, scene]);

  useFrame((_, __, frame) => {
    if (!frame || !hitTestSource.current || !localSpace.current || !reticle.current) return;
    const hits = frame.getHitTestResults(hitTestSource.current);
    const hit = hits[0];
    if (!hit) {
      reticle.current.visible = false;
      return;
    }
    const pose = hit.getPose(localSpace.current);
    if (!pose) return;
    reticle.current.visible = !placed;
    reticle.current.matrix.fromArray(pose.transform.matrix);
    reticle.current.matrixAutoUpdate = false;
    if (!placed && furniture.current) {
      furniture.current.position.setFromMatrixPosition(reticle.current.matrix);
    }
  });

  const place = () => {
    if (!reticle.current?.visible || !furniture.current) return;
    furniture.current.position.setFromMatrixPosition(reticle.current.matrix);
    furniture.current.visible = true;
    setPlaced(true);
    onStatus("placed");
  };

  return (
    <>
      <ambientLight intensity={1.4} />
      <directionalLight position={[2, 5, 2]} intensity={2} />
      <ARFurniture parts={parts} config={config} placed={placed} furnitureRef={furniture} />
      <mesh ref={reticle} rotation={[-Math.PI / 2, 0, 0]} visible={false}>
        <ringGeometry args={[0.08, 0.1, 32]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.9} side={THREE.DoubleSide} />
      </mesh>
      <ARInteraction furniture={furniture} placed={placed} onPlace={place} />
    </>
  );
}

function ARInteraction({ furniture, placed, onPlace }: { furniture: RefObject<THREE.Group | null>; placed: boolean; onPlace: () => void }) {
  const start = useRef<{ x: number; y: number } | null>(null);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    const down = (e: PointerEvent) => (start.current = { x: e.clientX, y: e.clientY });
    const move = (e: PointerEvent) => {
      if (!placed || !furniture.current || !start.current) return;
      const dx = e.clientX - start.current.x;
      if (Math.abs(dx) > 2) {
        const next = rotation + dx * 0.008;
        furniture.current.rotation.y = next;
        setRotation(next);
        start.current = { x: e.clientX, y: e.clientY };
      }
    };
    const up = () => (start.current = null);
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, [furniture, placed, rotation]);

  useEffect(() => {
    const click = (e: MouseEvent) => {
      if (!placed && !(e.target as HTMLElement)?.closest?.("[data-ar-ui]")) onPlace();
    };
    window.addEventListener("click", click);
    return () => window.removeEventListener("click", click);
  }, [onPlace, placed]);

  return null;
}

export default function ARPreview({ parts, config, onClose }: { parts: Part[]; config: FurnitureConfig; onClose: () => void }) {
  const [status, setStatus] = useState<ARStatus>("checking");

  const statusText = {
    checking: "Verificando suporte de realidade aumentada…",
    unsupported: "Seu dispositivo/navegador não oferece WebAR compatível. Abra este projeto em um celular Android compatível com AR ou use o modo 3D.",
    ready: "",
    placing: "Aponte a câmera para o chão e toque para posicionar o móvel.",
    placed: "Móvel posicionado em tamanho real. Arraste para girar.",
    error: "Não foi possível iniciar a câmera/AR. Verifique a permissão da câmera e tente novamente.",
  }[status];

  return (
    <div className="fixed inset-0 z-[100] bg-black">
      <Canvas
        camera={{ position: [0, 0, 0], fov: 60 }}
        gl={{ alpha: true, antialias: true }}
        onCreated={({ gl }) => {
          gl.xr.enabled = true;
          gl.setClearColor(0x000000, 0);
        }}
      >
        <ARScene parts={parts} config={config} onStatus={setStatus} onClose={onClose} />
      </Canvas>

      <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-between p-4 text-white">
        <div data-ar-ui className="pointer-events-auto max-w-[calc(100%-60px)] rounded-2xl bg-black/55 px-4 py-3 backdrop-blur">
          <div className="mb-1 flex items-center gap-2 text-sm font-medium"><ScanLine className="size-4" /> Ver no meu ambiente</div>
          <p className="text-xs leading-5 text-white/80">{statusText}</p>
        </div>
        <button data-ar-ui type="button" onClick={onClose} className="pointer-events-auto flex size-10 shrink-0 items-center justify-center rounded-full bg-black/55 backdrop-blur" aria-label="Fechar AR">
          <X className="size-5" />
        </button>
      </div>

      {status === "placing" && (
        <div className="pointer-events-none absolute inset-x-0 bottom-10 flex justify-center">
          <div className="rounded-full bg-black/55 px-5 py-3 text-xs text-white backdrop-blur">Toque no chão para colocar o móvel</div>
        </div>
      )}

      {status === "placed" && (
        <div className="pointer-events-none absolute inset-x-0 bottom-6 flex justify-center gap-2">
          <div className="flex items-center gap-2 rounded-full bg-black/55 px-4 py-2 text-xs text-white backdrop-blur"><RotateCw className="size-3.5" /> Arraste para girar</div>
          <div className="flex items-center gap-2 rounded-full bg-black/55 px-4 py-2 text-xs text-white backdrop-blur"><Move3D className="size-3.5" /> Escala real: {config.width} × {config.height} × {config.depth} cm</div>
        </div>
      )}

      {(status === "unsupported" || status === "error") && (
        <div className="absolute inset-x-5 bottom-8 rounded-2xl bg-white p-5 text-center shadow-2xl">
          <Smartphone className="mx-auto mb-3 size-7 text-neutral-700" />
          <p className="text-sm font-medium text-neutral-900">AR indisponível neste dispositivo</p>
          <p className="mt-1 text-xs leading-5 text-neutral-500">Você ainda pode fechar e continuar usando o configurador 3D normalmente.</p>
          <button data-ar-ui type="button" onClick={onClose} className="mt-4 w-full rounded-xl bg-neutral-900 px-4 py-3 text-sm font-medium text-white">Voltar ao configurador</button>
        </div>
      )}
    </div>
  );
}
