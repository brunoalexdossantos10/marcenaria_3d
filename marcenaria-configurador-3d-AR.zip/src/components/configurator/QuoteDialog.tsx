import { useState } from "react";
import { X, Check } from "lucide-react";
import type { Configurator, SavedProject } from "@/lib/furniture/store";
import { nextProjectCode, persistProject } from "@/lib/furniture/store";
import { typeDef } from "@/lib/furniture/types";
import { material } from "@/lib/furniture/materials";
import { brl } from "@/lib/furniture/pricing";

type Step = "form" | "resumo" | "enviado";

export function QuoteDialog({ c, onClose }: { c: Configurator; onClose: () => void }) {
  const [step, setStep] = useState<Step>("form");
  const [form, setForm] = useState({ name: "", phone: "", email: "", city: "", notes: "" });
  const [code, setCode] = useState("");

  const field = (key: keyof typeof form, label: string, type = "text") => (
    <label className="block">
      <span className="mb-1.5 block text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        type={type}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        className="h-11 w-full rounded-lg border border-border bg-card px-3 outline-none focus:border-ring"
      />
    </label>
  );

  const send = () => {
    const project: SavedProject = {
      id: crypto.randomUUID(),
      code: nextProjectCode(),
      createdAt: new Date().toISOString(),
      config: c.config,
      price: c.price.total,
      customer: form,
      status: "Orçamento",
    };
    persistProject(project);
    setCode(project.code);
    setStep("enviado");
  };

  const summary = [
    ["Tipo", typeDef(c.config.type).label],
    ["Dimensões", `${c.config.width} × ${c.config.height} × ${c.config.depth} cm`],
    ["Material", material(c.config.material).label],
    ["Portas", String(c.config.doors)],
    ["Gavetas", String(c.config.drawers)],
    ["Prateleiras", String(c.config.shelves)],
    ["Preço estimado", brl(c.price.total)],
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-0 backdrop-blur-sm sm:items-center sm:p-6">
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-border bg-background p-6 shadow-2xl sm:rounded-2xl">
        <div className="mb-5 flex items-start justify-between">
          <h2 className="font-display text-2xl">
            {step === "form" ? "Solicitar orçamento" : step === "resumo" ? "Seu projeto" : "Projeto enviado"}
          </h2>
          <button type="button" onClick={onClose} aria-label="Fechar" className="step-btn">
            <X className="size-4" />
          </button>
        </div>

        {step === "form" && (
          <form
            className="space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              setStep("resumo");
            }}
          >
            {field("name", "Nome")}
            {field("phone", "Telefone", "tel")}
            {field("email", "E-mail", "email")}
            {field("city", "Cidade")}
            <label className="block">
              <span className="mb-1.5 block text-xs uppercase tracking-widest text-muted-foreground">Observações</span>
              <textarea
                rows={3}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="w-full rounded-lg border border-border bg-card p-3 outline-none focus:border-ring"
              />
            </label>
            <button type="submit" className="btn-primary w-full">
              Ver resumo do projeto
            </button>
          </form>
        )}

        {step === "resumo" && (
          <div className="space-y-4">
            <dl className="divide-y divide-border rounded-xl border border-border bg-card">
              {summary.map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 px-4 py-3 text-sm">
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="text-right font-medium">{v}</dd>
                </div>
              ))}
            </dl>
            <button type="button" onClick={send} className="btn-primary w-full">
              Enviar projeto para a marcenaria
            </button>
            <button type="button" onClick={() => setStep("form")} className="btn-ghost w-full">
              Voltar
            </button>
          </div>
        )}

        {step === "enviado" && (
          <div className="space-y-4 text-center">
            <span className="mx-auto flex size-14 items-center justify-center rounded-full bg-secondary text-primary">
              <Check className="size-7" />
            </span>
            <p className="text-sm text-muted-foreground">
              Recebemos seu projeto <strong className="text-foreground">{code}</strong>. Nossa equipe entra em contato para
              confirmar medidas e enviar o orçamento final.
            </p>
            <button type="button" onClick={onClose} className="btn-primary w-full">
              Continuar editando
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default QuoteDialog;
