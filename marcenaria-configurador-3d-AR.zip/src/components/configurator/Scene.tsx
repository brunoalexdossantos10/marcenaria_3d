import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, OrbitControls, Html, ContactShadows } from "@react-three/drei";
import * as THREE from "three";
import type { Part } from "@/lib/furniture/types";
import type { FurnitureConfig } from "@/lib/furniture/types";
import { material as materialDef } from "@/lib/furniture/materials";
import { HANDLE_FINISHES } from "@/lib/furniture/types";

const finishDef = (id?: string) => HANDLE_FINISHES.find((f) => f.id === id) ?? HANDLE_FINISHES[1]!;
const ledColor = (temp: number) => {
  const t = Math.max(2200, Math.min(6000, temp));
  const k = (t - 2200) / 3800;
  return new THREE.Color().setRGB(1, 0.72 + k * 0.24, 0.45 + k * 0.5);
};

const S = 0.01; // cm -> m

/** The dev/build tooling injects `data-tsd-source` attributes into JSX.
 *  react-three-fiber walks them as `object.data.tsd.source` and throws when a
 *  level is missing. A self-nesting bag absorbs writes at any depth. */
function makeBag(): Record<string, unknown> {
  const target: Record<string, unknown> = {};
  return new Proxy(target, {
    get(t, key: string) {
      if (!(key in t)) t[key] = makeBag();
      return t[key];
    },
  });
}

if (!("data" in THREE.Object3D.prototype)) {
  const bag = {
    get(this: object) {
      const v = makeBag();
      Object.defineProperty(this, "data", { value: v, writable: true, configurable: true });
      return v;
    },
    configurable: true,
  } as const;
  Object.defineProperty(THREE.Object3D.prototype, "data", bag);
  Object.defineProperty(THREE.Material.prototype, "data", bag);
  Object.defineProperty(THREE.BufferGeometry.prototype, "data", bag);
}



/** Procedural wood-grain texture, cached per color+grain so panels share one
 *  GPU texture instead of allocating a canvas per mesh. */
const TEX_CACHE = new Map<string, THREE.CanvasTexture>();

function woodTexture(color: string, grain: number) {
  if (typeof document === "undefined") return null;
  const key = `${color}|${grain}`;
  const cached = TEX_CACHE.get(key);
  if (cached) return cached;
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, 512, 512);
  const base = new THREE.Color(color);
  for (let i = 0; i < 260; i++) {
    const y = Math.random() * 512;
    const dark = Math.random() > 0.5;
    const shade = base.clone().offsetHSL(0, 0, (dark ? -1 : 1) * 0.06 * Math.random());
    ctx.strokeStyle = `rgba(${(shade.r * 255) | 0},${(shade.g * 255) | 0},${(shade.b * 255) | 0},${0.12 + grain * 0.5})`;
    ctx.lineWidth = 0.6 + Math.random() * 2.4;
    ctx.beginPath();
    ctx.moveTo(0, y);
    for (let x = 0; x <= 512; x += 32) ctx.lineTo(x, y + Math.sin((x + y) / 60) * 4 * grain);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  TEX_CACHE.set(key, tex);
  return tex;
}

/** Realistic mirror: physical material, near-zero roughness, full metalness and
 *  a strong environment contribution so it reflects the scene HDRI. */
function MirrorMaterial() {
  return (
    <meshPhysicalMaterial
      color="#eef3f5"
      roughness={0.015}
      metalness={1}
      envMapIntensity={3.2}
      clearcoat={1}
      clearcoatRoughness={0.02}
      reflectivity={1}
    />
  );
}

/** Realistically thin clothes hanger built from slim bars. Sizes come from the
 *  builder, which derives them from the cabinet's inner space. */
function Hanger({ size }: { size: [number, number, number] }) {
  const [, hRaw, dRaw] = size.map((v) => v * S) as [number, number, number];
  const bar = 0.011; // 1.1 cm
  const shoulder = dRaw; // spans the depth axis
  const bodyH = hRaw * 0.55;
  const hookH = hRaw * 0.3;
  return (
    <group>
      {/* hook */}
      <mesh position={[0, bodyH / 2 + hookH / 2, 0]}>
        <cylinderGeometry args={[bar * 0.35, bar * 0.35, hookH, 8]} />
        <meshStandardMaterial color="#b9bec4" roughness={0.3} metalness={0.9} />
      </mesh>
      {/* shoulders */}
      <mesh position={[0, bodyH * 0.18, shoulder * 0.25]} rotation={[Math.atan2(bodyH * 0.6, shoulder * 0.5), 0, 0]}>
        <boxGeometry args={[bar, bar, Math.hypot(bodyH * 0.6, shoulder * 0.5)]} />
        <meshStandardMaterial color="#8b6b47" roughness={0.6} />
      </mesh>
      <mesh position={[0, bodyH * 0.18, -shoulder * 0.25]} rotation={[-Math.atan2(bodyH * 0.6, shoulder * 0.5), 0, 0]}>
        <boxGeometry args={[bar, bar, Math.hypot(bodyH * 0.6, shoulder * 0.5)]} />
        <meshStandardMaterial color="#8b6b47" roughness={0.6} />
      </mesh>
      {/* bottom bar */}
      <mesh position={[0, -bodyH * 0.12, 0]}>
        <boxGeometry args={[bar * 0.8, bar * 0.8, shoulder]} />
        <meshStandardMaterial color="#8b6b47" roughness={0.6} />
      </mesh>
    </group>
  );
}

function PartMesh({
  part,
  children,
  materialId,
  selected,
  onSelect,
  openDoors,
}: {
  part: Part;
  children?: Part[];
  materialId: string;
  selected: boolean;
  onSelect: (id: string) => void;
  openDoors: boolean;
}) {
  const def = materialDef(part.material ?? materialId);
  const isMirror = part.kind === "espelho";
  const isRod = part.kind === "cabideiro";
  const isHanger = part.kind === "cabide";
  const tex = useMemo(
    () => (isMirror || isRod || isHanger || def.finish === "vidro" ? null : woodTexture(def.color, def.grain)),
    [def.color, def.grain, def.finish, isMirror, isRod, isHanger],
  );
  const group = useRef<THREE.Group>(null);
  const [hover, setHover] = useState(false);

  const [w, h, d] = part.size.map((v) => v * S) as [number, number, number];
  const [x, y, z] = part.pos.map((v) => v * S) as [number, number, number];

  const isDoor = part.kind === "porta";
  const isSliding = isDoor && !!part.sliding;
  const isSwing = isDoor && !isSliding;
  const isDrawer = part.kind === "gaveta";

  const isTilt = isDoor && !!part.tilt;
  const interactive = isSwing || isSliding || isDrawer;
  // 0..1 opening driven either by the global toggle or by dragging with the mouse
  const manual = useRef<number | null>(null);
  const drag = useRef<{ x: number; y: number; from: number } | null>(null);
  const [grabbing, setGrabbing] = useState(false);
  const target = manual.current ?? (openDoors ? 1 : 0);

  useEffect(() => {
    manual.current = null;
  }, [openDoors]);

  const onDragDown = (e: { stopPropagation: () => void; clientX: number; clientY: number }) => {
    if (!interactive) return;
    e.stopPropagation();
    const from = manual.current ?? (openDoors ? 1 : 0);
    drag.current = { x: e.clientX, y: e.clientY, from };
    setGrabbing(true);
    const move = (ev: PointerEvent) => {
      const d = drag.current;
      if (!d) return;
      const dx = ev.clientX - d.x;
      const dy = ev.clientY - d.y;
      let v = d.from;
      if (isSwing) v = d.from + ((part.hinge === 1 ? -dx : dx) + (isTilt ? -dy : 0)) / 220;
      else if (isSliding) v = d.from + dx / 260;
      else v = d.from + (dy + dx * 0.3) / 190;
      manual.current = Math.max(0, Math.min(1, v));
    };
    const up = () => {
      drag.current = null;
      setGrabbing(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  useFrame((_, delta) => {
    const g = group.current;
    if (!g) return;
    const goal = manual.current ?? (openDoors ? 1 : 0);
    const k = drag.current ? 1 : 1 - Math.exp(-8 * Math.min(delta, 0.05));
    if (isSwing) {
      if (isTilt) {
        // basculante: rotates up around the top edge, limited by openLimit
        const OPEN = ((part.openLimit ?? 85) * Math.PI) / 180;
        g.rotation.x += (goal * OPEN - g.rotation.x) * k;
      } else {
        // hinge on the left (-1) swings the free edge forward with a NEGATIVE
        // y rotation; hinge on the right (1) with a positive one.
        const OPEN = ((part.openLimit ?? 100) * Math.PI) / 180;
        const rot = goal * (part.hinge === 1 ? OPEN : -OPEN);
        g.rotation.y += (rot - g.rotation.y) * k;
      }
    } else if (isSliding) {
      const dx = goal * (((part.slideTo ?? part.pos[0]) - part.pos[0]) * S);
      g.position.x += (dx - g.position.x) * k;
    } else if (isDrawer) {
      // never leaves the runners: travel is capped by the builder
      const out = goal * ((part.travel ?? part.size[2] * 0.85) * S);
      g.position.z += (out - g.position.z) * k;
    }
  });

  const emphasis = selected || hover;

  const handlers = {
    onPointerDown: onDragDown,
    onPointerOver: (e: { stopPropagation: () => void }) => {
      e.stopPropagation();
      setHover(true);
      if (interactive && typeof document !== "undefined") document.body.style.cursor = "grab";
    },
    onPointerOut: () => {
      setHover(false);
      if (typeof document !== "undefined") document.body.style.cursor = "";
    },
    onClick: (e: { stopPropagation: () => void }) => {
      e.stopPropagation();
      if (grabbing) return;
      onSelect(part.id);
    },
  };

  if (isHanger) {
    return (
      <group position={[x, y, z]}>
        <Hanger size={part.size} />
      </group>
    );
  }

  if (part.kind === "puxador") {
    const f = finishDef(part.handle?.finish);
    const model = part.handle?.model ?? "reto";
    const vertical = part.handle?.orientation === "vertical";
    const mat = <meshStandardMaterial color={f.color} metalness={f.metalness} roughness={f.roughness} />;
    if (model === "botao")
      return (
        <mesh position={[x, y, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.016, 0.013, 0.03, 20]} />
          {mat}
        </mesh>
      );
    if (model === "cava" || model === "embutido")
      return (
        <mesh position={[x, y, z - d / 2]} castShadow>
          <boxGeometry args={[vertical ? 0.02 : w, vertical ? h : 0.02, 0.012]} />
          {mat}
        </mesh>
      );
    const bar = 0.014;
    const off = model === "perfil" ? 0.008 : 0.028;
    return (
      <group position={[x, y, z]}>
        <mesh position={[0, 0, off]} castShadow>
          <boxGeometry args={[vertical ? bar : w, vertical ? h : bar, model === "perfil" ? 0.022 : bar]} />
          {mat}
        </mesh>
        {model !== "perfil" &&
          [-1, 1].map((s2) => (
            <mesh key={s2} position={[vertical ? 0 : (s2 * w) / 2.6, vertical ? (s2 * h) / 2.6 : 0, off / 2]}>
              <boxGeometry args={[bar * 0.7, bar * 0.7, off]} />
              {mat}
            </mesh>
          ))}
      </group>
    );
  }

  if (part.kind === "led") {
    const col = ledColor(part.led?.temp ?? 3000);
    const power = part.led?.intensity ?? 1;
    return (
      <group position={[x, y, z]}>
        <mesh>
          <boxGeometry args={[w, h, d]} />
          <meshStandardMaterial color={col} emissive={col} emissiveIntensity={1.4 * power} toneMapped={false} />
        </mesh>
        <pointLight color={col} intensity={power * 1.6} distance={1.5} decay={2} position={[0, -0.05, 0]} />
      </group>
    );
  }

  const mesh = (
    <mesh castShadow={!isMirror} receiveShadow {...handlers}>
      {isRod ? <cylinderGeometry args={[h / 2, h / 2, w, 16]} /> : <boxGeometry args={[w, h, d]} />}
      {isMirror ? (
        <MirrorMaterial />
      ) : isRod ? (
        <meshStandardMaterial color="#b9bec4" roughness={0.25} metalness={0.9} />
      ) : def.finish === "vidro" ? (
        <meshPhysicalMaterial
          color={def.color}
          roughness={def.roughness}
          metalness={0}
          transmission={0.85}
          thickness={0.02}
          transparent
          opacity={def.opacity ?? 0.4}
          envMapIntensity={1.6}
        />
      ) : (
        <meshStandardMaterial
          color={emphasis ? new THREE.Color(def.color).offsetHSL(0, 0.05, 0.06) : def.color}
          map={tex ?? null}
          roughness={def.roughness}
          metalness={def.metalness ?? 0.04}
          emissive={selected ? "#c98a3c" : "#000000"}
          emissiveIntensity={selected ? 0.22 : 0}
        />
      )}
    </mesh>
  );

  const mounted = children?.map((child) => {
    const [cw, ch, cd] = child.size.map((v) => v * S) as [number, number, number];
    const [cx, cy, cz] = child.pos.map((v) => v * S) as [number, number, number];
    return (
      <mesh
        key={child.id}
        position={[cx, cy, cz]}
        receiveShadow
        onClick={(e) => {
          e.stopPropagation();
          onSelect(child.id);
        }}
      >
        <boxGeometry args={[cw, ch, cd]} />
        {child.kind === "espelho" ? <MirrorMaterial /> : <meshStandardMaterial color={def.color} />}
      </mesh>
    );
  });

  if (isRod) {
    return (
      <group position={[x, y, z]} rotation={[0, 0, Math.PI / 2]}>
        {mesh}
      </group>
    );
  }

  if (isSwing && isTilt) {
    return (
      <group position={[x, y + h / 2, z - d / 2]} ref={group}>
        <group position={[0, -h / 2, d / 2]}>
          {mesh}
          {mounted}
        </group>
      </group>
    );
  }

  if (isSwing) {
    const hingeX = x + (part.hinge === 1 ? w / 2 : -w / 2);
    // pivot sits on the hinge edge, at the BACK face of the door so the leaf
    // sweeps in front of the carcass and never crosses it.
    return (
      <group position={[hingeX, y, z - d / 2]} ref={group}>
        <group position={[part.hinge === 1 ? -w / 2 : w / 2, 0, d / 2]}>
          {mesh}
          {mounted}
        </group>
      </group>
    );
  }

  if (isSliding) {
    return (
      <group position={[x, y, z]}>
        <group ref={group}>
          {mesh}
          {mounted}
        </group>
      </group>
    );
  }

  if (isDrawer) {
    return (
      <group position={[x, y, z]}>
        <group ref={group}>
          {mesh}
        </group>
      </group>
    );
  }

  return (
    <group position={[x, y, z]}>
      {mesh}
      {mounted}
    </group>
  );
}



/** Simple realistic room: wooden floor, painted walls, baseboard and a rug.
 *  Sized around the furniture so it always sits against the back wall. */
function Room({ depth, width }: { depth: number; width: number }) {
  const w = Math.max(6, width * S * 2.4);
  const back = -depth * S / 2 - 0.02;
  const floorTex = useMemo(() => {
    const t = woodTexture("#b98f62", 0.7);
    if (t) {
      t.repeat.set(10, 10);
      t.needsUpdate = true;
    }
    return t;
  }, []);
  const H = 2.7;
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.002, 0]} receiveShadow>
        <planeGeometry args={[w, w]} />
        <meshStandardMaterial color="#c19a6b" map={floorTex ?? null} roughness={0.55} metalness={0.02} />
      </mesh>
      {/* back wall */}
      <mesh position={[0, H / 2, back]} receiveShadow>
        <planeGeometry args={[w, H]} />
        <meshStandardMaterial color="#efe9e0" roughness={0.95} />
      </mesh>
      {/* side wall */}
      <mesh position={[-w / 2, H / 2, back + w / 2]} rotation-y={Math.PI / 2} receiveShadow>
        <planeGeometry args={[w, H]} />
        <meshStandardMaterial color="#e7e0d5" roughness={0.95} />
      </mesh>
      {/* baseboards */}
      <mesh position={[0, 0.05, back + 0.012]}>
        <boxGeometry args={[w, 0.1, 0.024]} />
        <meshStandardMaterial color="#f7f4ef" roughness={0.7} />
      </mesh>
      <mesh position={[-w / 2 + 0.012, 0.05, back + w / 2]}>
        <boxGeometry args={[0.024, 0.1, w]} />
        <meshStandardMaterial color="#f7f4ef" roughness={0.7} />
      </mesh>
      {/* rug */}
      <mesh rotation-x={-Math.PI / 2} position={[0.2, 0.004, back + 2.1]} receiveShadow>
        <planeGeometry args={[2.4, 1.6]} />
        <meshStandardMaterial color="#9a8f80" roughness={1} />
      </mesh>
    </group>
  );
}

function Dimensions({ cfg }: { cfg: FurnitureConfig }) {
  const w = cfg.width * S;
  const h = cfg.height * S;
  const d = cfg.depth * S;
  const label = (text: string, pos: [number, number, number]) => (
    <Html position={pos} center distanceFactor={4} zIndexRange={[10, 0]}>
      <span className="dim-badge">{text}</span>
    </Html>
  );
  return (
    <group>
      {label(`${cfg.width} cm`, [0, -0.06, d / 2 + 0.12])}
      {label(`${cfg.height} cm`, [-w / 2 - 0.16, h / 2, d / 2])}
      {label(`${cfg.depth} cm`, [w / 2 + 0.14, 0.04, 0])}
      <lineSegments position={[0, 0.001, d / 2 + 0.08]}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([-w / 2, 0, 0, w / 2, 0, 0]), 3]}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#c98a3c" />
      </lineSegments>
    </group>
  );
}

export type CameraView = "frente" | "lateral" | "topo" | "reset";

function CameraRig({ view, size }: { view: { name: CameraView; n: number }; size: number }) {
  const { camera } = useThree();
  const controls = useThree((s) => s.controls) as unknown as { target: THREE.Vector3; update: () => void } | null;
  const goal = useRef<THREE.Vector3 | null>(null);

  useEffect(() => {
    const r = size * S * 1.9 + 0.8;
    const map: Record<CameraView, THREE.Vector3> = {
      frente: new THREE.Vector3(0, size * S * 0.55, r),
      lateral: new THREE.Vector3(r, size * S * 0.55, 0.001),
      topo: new THREE.Vector3(0.001, r * 1.1, 0.001),
      reset: new THREE.Vector3(r * 0.75, size * S * 0.7, r * 0.8),
    };
    goal.current = map[view.name];
  }, [view, size]);

  useFrame((_, delta) => {
    if (!goal.current) return;
    const k = 1 - Math.exp(-6 * Math.min(delta, 0.05));
    camera.position.lerp(goal.current, k);
    if (camera.position.distanceTo(goal.current) < 0.01) goal.current = null;
    controls?.target.lerp(new THREE.Vector3(0, size * S * 0.45, 0), k);
    controls?.update();
  });
  return null;
}

export function Scene({
  parts,
  config,
  selected,
  onSelect,
  view,
}: {
  parts: Part[];
  config: FurnitureConfig;
  selected: string | null;
  onSelect: (id: string | null) => void;
  view: { name: CameraView; n: number };
}) {
  // framing size follows every dimension so the furniture stays in frame
  const frame = Math.max(config.width, config.height, config.depth * 1.6);
  return (

    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [3, 1.6, 3.2], fov: 42 }}
      onPointerMissed={() => onSelect(null)}
      gl={{ antialias: true }}
    >
      <color attach="background" args={["#efece6"]} />
      <fog attach="fog" args={["#efece6", 9, 22]} />
      <hemisphereLight args={["#fff6e8", "#c9c2b6", 0.55]} />
      <ambientLight intensity={0.35} />
      <directionalLight
        position={[3.2, 5, 3.6]}
        intensity={2.1}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[-4, 2.5, -2]} intensity={0.5} color="#dfe6ef" />

      <Environment resolution={128}>
        <Lightformer intensity={2.2} position={[0, 4, 1]} scale={[8, 8, 1]} />
        <Lightformer intensity={1} color="#cddbe6" position={[-5, 1.5, -1]} rotation-y={Math.PI / 2} scale={[16, 3, 1]} />
        <Lightformer intensity={0.8} color="#f6e2c6" position={[5, 1, 2]} rotation-y={-Math.PI / 2} scale={[16, 3, 1]} />
      </Environment>

      <group position={[0, 0, 0]}>
        {parts
          .filter((p) => !p.parent)
          .map((p) => (
            <PartMesh
              key={p.id}
              part={p}
              children={parts.filter((c) => c.parent === p.id)}
              materialId={config.material}
              selected={selected === p.id}
              onSelect={onSelect}
              openDoors={config.openDoors}
            />
          ))}
        {config.showDimensions && <Dimensions cfg={config} />}
      </group>

      <Room depth={config.depth} width={config.width} />
      <ContactShadows position={[0, 0.002, 0]} opacity={0.42} scale={12} blur={2.4} far={4} />

      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={Math.max(0.6, frame * S * 0.5)}
        maxDistance={Math.max(6, frame * S * 5)}
        maxPolarAngle={Math.PI / 2.02}
        target={[0, (config.height * S) / 2, 0]}
      />
      <CameraRig view={view} size={frame} />

    </Canvas>
  );
}

export default Scene;
