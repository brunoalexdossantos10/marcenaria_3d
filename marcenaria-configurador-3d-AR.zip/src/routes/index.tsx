import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Boxes, Hammer, Ruler, ShieldCheck, Sparkles, Truck } from "lucide-react";
import SiteLayout from "@/components/site/SiteLayout";
import Reveal, { CountUp } from "@/components/site/Reveal";
import { MATERIALS } from "@/lib/furniture/materials";
import { brl } from "@/lib/furniture/pricing";
import heroImg from "@/assets/hero-marcenaria.jpg";
import cozinhaImg from "@/assets/cozinha.jpg";
import officeImg from "@/assets/home-office.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ateliê Nogal · Marcenaria sob medida com configurador 3D" },
      {
        name: "description",
        content:
          "Marcenaria sob medida em São Paulo: guarda-roupas, cozinhas, estantes e home office. Monte seu móvel no configurador 3D e receba a estimativa na hora.",
      },
      { property: "og:title", content: "Ateliê Nogal · Marcenaria sob medida com configurador 3D" },
      {
        property: "og:description",
        content: "Projete seu móvel em 3D, escolha acabamentos e receba o orçamento estimado em tempo real.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const STEPS = [
  { icon: Ruler, title: "1. Meça o espaço", text: "Anote largura, altura e profundidade disponíveis no ambiente." },
  { icon: Boxes, title: "2. Monte em 3D", text: "Defina módulos, portas, gavetas, nichos e acabamento em MDF." },
  { icon: Sparkles, title: "3. Veja o preço", text: "A estimativa é recalculada a cada mudança, sem surpresa." },
  { icon: Hammer, title: "4. Aprovamos e produzimos", text: "Visita técnica, projeto executivo, produção e montagem." },
];

function Index() {
  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:py-24 lg:grid-cols-2">
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              <Sparkles className="size-3.5 text-primary" /> Configurador 3D em tempo real
            </p>
            <h1 className="mt-6 text-4xl leading-[1.05] md:text-6xl">
              Móveis sob medida
              <span className="block text-primary">desenhados por você.</span>
            </h1>
            <p className="mt-6 max-w-lg text-base text-muted-foreground md:text-lg">
              Escolha o tipo de móvel, ajuste cada centímetro, teste acabamentos em MDF e veja a
              estimativa de investimento na hora — antes de falar com um vendedor.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/configurador" className="btn-primary">
                Criar meu móvel em 3D <ArrowRight className="size-4" />
              </Link>
              <Link to="/portfolio" className="btn-ghost h-12">
                Ver projetos executados
              </Link>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-4">
              {[
                { n: 18, s: " anos", l: "de ateliê" },
                { n: 1240, s: "+", l: "móveis entregues" },
                { n: 30, s: " dias", l: "prazo médio" },
              ].map((s) => (
                <div key={s.l}>
                  <dd className="font-display text-2xl md:text-3xl">
                    <CountUp to={s.n} suffix={s.s} />
                  </dd>
                  <dt className="text-xs text-muted-foreground">{s.l}</dt>
                </div>
              ))}
            </dl>
          </Reveal>

          <Reveal delay={120} className="relative">
            <div className="overflow-hidden rounded-3xl border border-border shadow-soft">
              <img
                src={heroImg}
                alt="Guarda-roupa sob medida em nogueira instalado em quarto claro"
                width={1600}
                height={1100}
                className="h-full w-full object-cover transition-transform duration-700 hover:scale-[1.03]"
              />
            </div>
            <div className="absolute -bottom-6 left-4 rounded-2xl border border-border bg-card/95 px-5 py-4 shadow-soft backdrop-blur md:left-8">
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Estimativa média</p>
              <p className="font-display text-2xl">{brl(7480)}</p>
              <p className="text-xs text-muted-foreground">guarda-roupa 220 × 250 × 60 cm</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Como funciona */}
      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-6xl px-5 py-16 md:py-20">
          <Reveal>
            <h2 className="text-3xl md:text-4xl">Do metro à montagem, em quatro passos</h2>
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <Reveal key={s.title} delay={i * 90}>
                <article className="card-lift h-full rounded-2xl border border-border bg-card p-6">
                  <s.icon className="size-6 text-primary" />
                  <h3 className="mt-4 text-lg">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Ambientes */}
      <section className="mx-auto max-w-6xl px-5 py-16 md:py-20">
        <Reveal>
          <h2 className="text-3xl md:text-4xl">Ambientes que projetamos</h2>
          <p className="mt-3 max-w-xl text-muted-foreground">
            Todos disponíveis no configurador, com limites de medida e ferragens já calculados.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {[
            { img: cozinhaImg, title: "Cozinhas planejadas", text: "Torres, gaveteiros e aéreos calculados por módulo." },
            { img: officeImg, title: "Home office e estantes", text: "Nichos, prateleiras e bancadas com passagem de cabos." },
          ].map((a, i) => (
            <Reveal key={a.title} delay={i * 120}>
              <article className="group overflow-hidden rounded-3xl border border-border bg-card">
                <div className="overflow-hidden">
                  <img
                    src={a.img}
                    alt={a.title}
                    loading="lazy"
                    width={1200}
                    height={900}
                    className="h-64 w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl">{a.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{a.text}</p>
                  <Link to="/configurador" className="mt-4 inline-flex items-center gap-1.5 text-sm text-primary">
                    Configurar agora <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Acabamentos */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-6xl px-5 py-16 md:py-20">
          <Reveal>
            <h2 className="text-3xl md:text-4xl">Acabamentos em MDF</h2>
            <p className="mt-3 text-muted-foreground">Preços por m² usados na estimativa do configurador.</p>
          </Reveal>
          <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {MATERIALS.map((m, i) => (
              <Reveal as="li" key={m.id} delay={i * 60}>
                <div className="card-lift flex items-center gap-3 rounded-2xl border border-border bg-background p-4">
                  <span className="size-11 shrink-0 rounded-xl border border-black/10" style={{ background: m.color }} />
                  <span>
                    <span className="block text-sm font-medium">{m.label}</span>
                    <span className="text-xs text-muted-foreground">{brl(m.pricePerM2)}/m²</span>
                  </span>
                </div>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* Garantias + CTA */}
      <section className="mx-auto max-w-6xl px-5 py-16 md:py-20">
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            { icon: ShieldCheck, t: "5 anos de garantia", d: "Estrutura, ferragens e montagem cobertas em contrato." },
            { icon: Truck, t: "Entrega monitorada", d: "Logística própria em São Paulo e região metropolitana." },
            { icon: Hammer, t: "Produção própria", d: "Corte CNC, fitagem e usinagem no nosso ateliê." },
          ].map((g, i) => (
            <Reveal key={g.t} delay={i * 90}>
              <article className="h-full rounded-2xl border border-border bg-card p-6">
                <g.icon className="size-6 text-primary" />
                <h3 className="mt-4 text-lg">{g.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{g.d}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <div className="mt-12 overflow-hidden rounded-3xl border border-border bg-secondary/60 px-6 py-12 text-center md:px-16">
            <h2 className="text-3xl md:text-4xl">Pronto para desenhar o seu?</h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Leva menos de dois minutos: ajuste as medidas, escolha as peças e envie para orçamento.
            </p>
            <Link to="/configurador" className="btn-primary mt-8">
              Abrir configurador 3D <ArrowRight className="size-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </SiteLayout>
  );
}
