import { createFileRoute, Link } from "@tanstack/react-router";
import { lazy, Suspense, useState } from "react";
import { ArrowLeft, RotateCcw, SlidersHorizontal, Share2, Download, ScanLine } from "lucide-react";
import { useConfigurator, nextProjectCode, persistProject } from "@/lib/furniture/store";
import ControlPanel from "@/components/configurator/ControlPanel";
import QuoteDialog from "@/components/configurator/QuoteDialog";
import ARPreview from "@/components/configurator/ARPreview";
import type { CameraView } from "@/components/configurator/Scene";

const Scene = lazy(() => import("@/components/configurator/Scene"));

export const Route = createFileRoute("/configurador")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Configurador 3D de móveis sob medida | Ateliê Nogal" },
      {
        name: "description",
        content:
          "Monte seu móvel sob medida em 3D: escolha dimensões, portas, gavetas, prateleiras e acabamentos em MDF com preço estimado em tempo real.",
      },
      { property: "og:title", content: "Configurador 3D de móveis sob medida" },
      { property: "og:description", content: "Personalize dimensões, peças e acabamentos e veja o preço na hora." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ConfiguradorPage,
});

const VIEWS: { key: CameraView; label: string }[] = [
  { key: "frente", label: "Frente" },
  { key: "lateral", label: "Lateral" },
  { key: "topo", label: "Topo" },
];

function ConfiguradorPage() {
  const c = useConfigurator();
  const [view, setView] = useState<{ name: CameraView; n: number }>({ name: "reset", n: 0 });
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [arOpen, setArOpen] = useState(false);

  const go = (name: CameraView) => setView((v) => ({ name, n: v.n + 1 }));

  const notify = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2600);
  };

  const save = () => {
    const project = persistProject({
      id: crypto.randomUUID(),
      code: nextProjectCode(),
      createdAt: new Date().toISOString(),
      config: c.config,
      price: c.price.total,
      status: "Novo projeto",
    });
    notify(`${project.code} salvo. Você pode retomá-lo em "Meus projetos".`);
  };

  const share = async () => {
    const url = `${window.location.origin}/configurador?c=${btoa(JSON.stringify(c.config))}`;
    try {
      await navigator.clipboard.writeText(url);
      notify("Link do projeto copiado.");
    } catch {
      notify(url);
    }
  };

  const download = () => {
    const blob = new Blob([JSON.stringify({ config: c.config, price: c.price, parts: c.parts }, null, 2)], {
      type: "application/json",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "projeto-marcenaria.json";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <main className="flex h-[100dvh] flex-col overflow-hidden bg-background lg:flex-row">
      <section className="relative min-h-0 flex-1">
        <Suspense
          fallback={
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              Preparando o ambiente 3D…
            </div>
          }
        >
          <Scene parts={c.parts} config={c.config} selected={c.selected} onSelect={c.setSelected} view={view} />
        </Suspense>

        <header className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between gap-3 p-4">
          <Link to="/" className="btn-ghost pointer-events-auto h-10">
            <ArrowLeft className="size-4" /> Início
          </Link>
          <div className="pointer-events-auto flex gap-2">
            <button type="button" onClick={share} className="btn-ghost h-10 px-3" aria-label="Compartilhar projeto">
              <Share2 className="size-4" />
            </button>
            <button type="button" onClick={() => setArOpen(true)} className="btn-primary h-10 px-3" aria-label="Ver no meu ambiente">
              <ScanLine className="size-4" />
              <span className="hidden xl:inline">Ver no ambiente</span>
            </button>
            <button type="button" onClick={download} className="btn-ghost h-10 px-3" aria-label="Baixar projeto">
              <Download className="size-4" />
            </button>
          </div>
        </header>

        <div className="absolute inset-x-0 bottom-20 flex flex-wrap justify-center gap-2 px-4 lg:bottom-6">
          {VIEWS.map((v) => (
            <button key={v.key} type="button" onClick={() => go(v.key)} className="chip bg-card/85 backdrop-blur">
              {v.label}
            </button>
          ))}
          <button type="button" onClick={() => go("reset")} className="chip bg-card/85 backdrop-blur">
            <RotateCcw className="mr-1.5 inline size-3.5" /> Resetar câmera
          </button>
        </div>

        {toast && (
          <div className="absolute inset-x-4 top-20 mx-auto max-w-sm rounded-xl border border-border bg-card px-4 py-3 text-center text-sm shadow-soft">
            {toast}
          </div>
        )}

        <button
          type="button"
          onClick={() => setArOpen(true)}
          className="btn-primary absolute bottom-16 right-4 z-10 lg:hidden"
          aria-label="Ver no meu ambiente"
        >
          <ScanLine className="size-4" /> AR
        </button>

        <button
          type="button"
          onClick={() => setPanelOpen(true)}
          className="btn-primary absolute inset-x-4 bottom-4 lg:hidden"
        >
          <SlidersHorizontal className="size-4" /> Personalizar móvel
        </button>
      </section>

      <aside className="hidden w-[380px] shrink-0 border-l border-border bg-background lg:block">
        <ControlPanel c={c} onQuote={() => setQuoteOpen(true)} onSave={save} />
      </aside>

      {panelOpen && (
        <div className="fixed inset-0 z-40 flex flex-col justify-end bg-foreground/30 backdrop-blur-sm lg:hidden">
          <div className="h-[82vh] rounded-t-2xl border-t border-border bg-background">
            <div className="flex items-center justify-between px-5 pt-4">
              <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Personalizar</span>
              <button type="button" className="btn-ghost h-9" onClick={() => setPanelOpen(false)}>
                Ver em 3D
              </button>
            </div>
            <div className="h-[calc(82vh-3.5rem)]">
              <ControlPanel c={c} onQuote={() => setQuoteOpen(true)} onSave={save} />
            </div>
          </div>
        </div>
      )}

      {quoteOpen && <QuoteDialog c={c} onClose={() => setQuoteOpen(false)} />}
      {arOpen && <ARPreview parts={c.parts} config={c.config} onClose={() => setArOpen(false)} />}
    </main>
  );
}
